"""
Card and Deck primitives.

A Card holds rank/suit plus runtime state (position, selected, animation
targets). It also caches its rendered surface so the UI can blit it cheaply.

The Deck shuffles, deals, and supports add/remove for shop upgrades.
"""

import random
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from game.constants import (
    SUITS, RANKS, RANK_VALUES, RANK_CHIP_VALUES, FACE_RANKS, LOW_RANKS, HIGH_RANKS
)


@dataclass
class Card:
    """A single playing card.

    The bottom half of the fields are pure UI state — motion mode, hover
    interpolation, pulse animation, etc. They are reset between blinds so
    the gameplay logic stays clean.
    """
    rank: str                       # '2'..'10', 'J', 'Q', 'K', 'A'
    suit: str                       # 'spades', 'hearts', 'diamonds', 'clubs'

    # ----- Game-relevant state ----- #
    selected: bool = False
    in_hand: bool = True
    face_up: bool = True
    # Optional modifier (Reinforced / Fragile / Energized / etc.). See
    # game/modifiers.py — gets applied during scoring via on_card_score.
    modifier: Optional[object] = None

    # ----- Position / target ----- #
    pos: Tuple[float, float] = (0.0, 0.0)
    target: Tuple[float, float] = (0.0, 0.0)

    # ----- Transform applied at draw time ----- #
    scale: float = 1.0
    rotation: float = 0.0           # degrees, positive = clockwise
    fan_rotation: float = 0.0       # target gentle tilt for hand fanning
    hover_tilt: float = 0.0         # extra tilt when hovered, points toward mouse
    glow: float = 0.0               # legacy highlight intensity, 0..1
    hover_t: float = 0.0            # 0..1, hovered animation progress
    pulse_t: float = 1.0            # <1 = pulsing, 1 = idle
    pulse_duration: float = 0.35    # seconds for a full pulse

    # ----- Motion mode + per-mode state ----- #
    # 'smooth' | 'arc' | 'fling'
    motion_mode: str = "smooth"
    deal_delay: float = 0.0         # delay before this card starts moving

    # arc mode
    arc_start: Tuple[float, float] = (0.0, 0.0)
    arc_t: float = 0.0
    arc_duration: float = 0.45

    # fling mode (discard)
    velocity: Tuple[float, float] = (0.0, 0.0)
    spin: float = 0.0               # degrees/sec
    fade_t: float = 0.0             # 0..1 fade out progress
    dead: bool = False              # set True when a fling completes

    surface: object = field(default=None, repr=False)  # cached pygame.Surface

    # ----- Identity helpers ----- #
    @property
    def rank_value(self) -> int:
        """Numeric rank for ordering / straight detection (2..14)."""
        return RANK_VALUES[self.rank]

    @property
    def chip_value(self) -> int:
        """Chips contributed to score when this card is part of the hand."""
        return RANK_CHIP_VALUES[self.rank]

    @property
    def is_face(self) -> bool:
        return self.rank in FACE_RANKS

    @property
    def is_low(self) -> bool:
        return self.rank in LOW_RANKS

    @property
    def is_high(self) -> bool:
        return self.rank in HIGH_RANKS

    @property
    def is_ace(self) -> bool:
        return self.rank == 'A'

    def to_dict(self) -> dict:
        """Serialise (just the identity + modifier, not UI state)."""
        out = {"rank": self.rank, "suit": self.suit}
        if self.modifier is not None:
            out["modifier"] = self.modifier.to_dict()
        return out

    @classmethod
    def from_dict(cls, d: dict) -> "Card":
        c = cls(rank=d["rank"], suit=d["suit"])
        mod_data = d.get("modifier")
        if mod_data:
            from game.modifiers import CardModifier
            c.modifier = CardModifier.from_dict(mod_data)
        return c

    def __str__(self):
        return f"{self.rank}{self.suit[0].upper()}"


class Deck:
    """A 52-card deck. Supports shuffle / draw / discard / add / remove."""

    def __init__(self, cards: Optional[List[Card]] = None):
        if cards is None:
            cards = self._build_standard()
        self.cards: List[Card] = cards     # cards left to draw
        self.discard: List[Card] = []      # face-up discards (used and broken cards)
        self.played: List[Card] = []       # cards locked away after scoring this round

    @staticmethod
    def _build_standard() -> List[Card]:
        """Returns a fresh 52-card deck in canonical order (caller shuffles)."""
        return [Card(rank=r, suit=s) for s in SUITS for r in RANKS]

    # ----- Manipulation ----- #
    def shuffle(self, rng: Optional[random.Random] = None) -> None:
        rng = rng or random
        # Combine all piles back into the draw pile, then shuffle in place.
        self.cards.extend(self.discard)
        self.cards.extend(self.played)
        self.discard.clear()
        self.played.clear()
        rng.shuffle(self.cards)

    def draw(self, n: int) -> List[Card]:
        """Draw up to n cards. If deck empties mid-draw, reshuffle the discard."""
        out: List[Card] = []
        for _ in range(n):
            if not self.cards:
                if not self.discard:
                    break
                # Reshuffle discards back in
                self.cards = self.discard
                self.discard = []
                random.shuffle(self.cards)
            out.append(self.cards.pop())
        return out

    def add_card(self, card: Card) -> None:
        """Add a card to the deck (shop upgrade)."""
        self.cards.append(card)

    def remove_card(self, card: Card) -> bool:
        """Permanently remove a card. Returns True if a matching card was found."""
        for pile in (self.cards, self.discard, self.played):
            if card in pile:
                pile.remove(card)
                return True
        return False

    def all_cards(self) -> List[Card]:
        """Every card belonging to this deck regardless of pile."""
        return self.cards + self.discard + self.played

    @property
    def size(self) -> int:
        return len(self.all_cards())

    # ----- Serialisation ----- #
    def to_list(self) -> List[dict]:
        return [c.to_dict() for c in self.all_cards()]

    @classmethod
    def from_list(cls, data: List[dict]) -> "Deck":
        return cls([Card.from_dict(d) for d in data])
