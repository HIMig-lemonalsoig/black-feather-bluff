"""
Poker hand evaluation and scoring.

`evaluate_hand` looks at 1..5 cards and returns the best hand type plus the
specific cards that *score* (matter for chips). For example, with a Pair of
sevens and three kickers, only the two sevens score.

`score_hand` applies the base chips/multiplier, sums each scoring card's chip
value, and lets jokers hook in.
"""

from typing import List, Tuple
from collections import Counter

from game.cards import Card
from game.constants import HAND_BASE_SCORES, HAND_DISPLAY_NAMES


# --------------------------------------------------------------------------- #
# Hand detection
# --------------------------------------------------------------------------- #
def _is_straight(rank_values: List[int]) -> bool:
    """True if 5 distinct ranks form a consecutive run (Ace can be low or high)."""
    if len(set(rank_values)) != 5:
        return False
    rvals = sorted(rank_values)
    if max(rvals) - min(rvals) == 4:
        return True
    # Wheel: A-2-3-4-5 -> Ace acts as 1
    if set(rvals) == {2, 3, 4, 5, 14}:
        return True
    return False


def evaluate_hand(cards: List[Card]) -> Tuple[str, List[Card]]:
    """
    Identify the best poker hand among the given cards.
    Returns (hand_type, scoring_cards).

    scoring_cards is the subset of `cards` that actually contributes chips.
    """
    if not cards:
        return ("high_card", [])

    rank_values = [c.rank_value for c in cards]
    suits = [c.suit for c in cards]
    rank_counts = Counter(rank_values)
    counts_desc = sorted(rank_counts.values(), reverse=True)

    is_flush    = len(cards) == 5 and len(set(suits)) == 1
    is_straight = len(cards) == 5 and _is_straight(rank_values)

    # Royal flush = straight flush whose top card is an Ace and bottom is 10.
    if is_flush and is_straight:
        if max(rank_values) == 14 and min(rank_values) == 10:
            return ("royal_flush", list(cards))
        return ("straight_flush", list(cards))

    if counts_desc[:1] == [4]:
        rv = next(rv for rv, c in rank_counts.items() if c == 4)
        return ("four_kind", [c for c in cards if c.rank_value == rv])

    if counts_desc[:2] == [3, 2]:
        return ("full_house", list(cards))

    if is_flush:
        return ("flush", list(cards))

    if is_straight:
        return ("straight", list(cards))

    if counts_desc[:1] == [3]:
        rv = next(rv for rv, c in rank_counts.items() if c == 3)
        return ("three_kind", [c for c in cards if c.rank_value == rv])

    if counts_desc[:2] == [2, 2]:
        pair_rvs = {rv for rv, c in rank_counts.items() if c == 2}
        return ("two_pair", [c for c in cards if c.rank_value in pair_rvs])

    if counts_desc[:1] == [2]:
        rv = next(rv for rv, c in rank_counts.items() if c == 2)
        return ("pair", [c for c in cards if c.rank_value == rv])

    # High card: only the single highest card scores
    high = max(cards, key=lambda c: c.rank_value)
    return ("high_card", [high])


def hand_display_name(hand_type: str) -> str:
    return HAND_DISPLAY_NAMES.get(hand_type, hand_type)


# --------------------------------------------------------------------------- #
# Scoring
# --------------------------------------------------------------------------- #
class ScoreContext:
    """
    Mutable scoring state passed through joker hooks.

    Jokers can mutate `chips` and `mult` (the running totals) and inspect
    `scoring_cards`, `played_cards`, and `hand_type` to decide their effect.
    """
    def __init__(self, hand_type: str, played_cards: List[Card], scoring_cards: List[Card]):
        base_chips, base_mult = HAND_BASE_SCORES.get(hand_type, (0, 1))
        self.hand_type = hand_type
        self.played_cards = played_cards
        self.scoring_cards = scoring_cards
        self.chips = float(base_chips)
        self.mult = float(base_mult)
        # For UI: list of (text, chips_delta, mult_delta) entries to animate.
        self.log: List[Tuple[str, float, float]] = []

    def add_chips(self, n: float, label: str = ""):
        self.chips += n
        if label:
            self.log.append((label, n, 0.0))

    def add_mult(self, n: float, label: str = ""):
        self.mult += n
        if label:
            self.log.append((label, 0.0, n))

    def mult_mult(self, n: float, label: str = ""):
        before = self.mult
        self.mult *= n
        if label:
            self.log.append((label, 0.0, self.mult - before))

    def total(self) -> int:
        return int(self.chips * self.mult)


def score_hand(played: List[Card], jokers, boss=None) -> ScoreContext:
    """
    Full scoring pipeline:
      1. Detect hand type
      2. Filter scoring cards (with possible boss adjustments)
      3. Add base chips/mult
      4. Add each scoring card's chip value
      5. Apply each joker's `on_score` callback (left-to-right slot order)
      6. Boss modifiers tweak the final result if needed
    """
    hand_type, scoring = evaluate_hand(played)

    # Boss "suit lock" only counts cards of the locked suit
    if boss is not None:
        scoring = boss.filter_scoring(scoring)

    ctx = ScoreContext(hand_type, played, scoring)
    # Side-channel for modifiers — populated by Fragile (cards to remove),
    # Burst (consumed modifiers), etc. PlayScreen reads + cleans up.
    ctx._break_cards = []
    ctx._consumed_modifier_cards = []

    # Each scoring card contributes its chip value, then its modifier (if any).
    for c in scoring:
        ctx.add_chips(c.chip_value)
        if getattr(c, "modifier", None) is not None:
            c.modifier.on_card_score(ctx, c)
            if c.modifier.is_consumed():
                ctx._consumed_modifier_cards.append(c)

    # Jokers
    for j in jokers:
        j.on_score(ctx, jokers)

    # Boss final multiplier modifier
    if boss is not None:
        boss.modify_final(ctx)

    return ctx
