"""
Token system — BLACKFEATHER BLUFF's Balatro-tag equivalent.

A Token is a one-shot bonus earned by **skipping a blind** at the blind-select
screen. Tokens hang in the run's inventory until their trigger condition fires
(start of next blind, end of round, entering shop, etc.), at which point they
apply their effect and consume themselves.

Lifecycle hooks every token can override:
    on_blind_start(run)   — fires when the next blind begins
    on_round_end(run)     — fires after a round completes (after end_blind)
    on_shop_enter(run)    — fires when the shop screen opens
    on_boss_seen(run)     — fires once when the boss-blind row is first shown

The token is consumed (removed from `run.tokens`) when its `consumed` flag is
set to True by its hook.

To add a new token: subclass Token, set the class attrs, override one hook,
and register it in TOKEN_DEFS.
"""

import random
from typing import Dict, List, Optional, Type


# Visual: gold-bordered chip with a single-char glyph.
TOKEN_COLOR = (212, 175, 55)


class Token:
    token_id: str = "base"
    name: str = "Base Token"
    description: str = ""
    icon_glyph: str = "?"

    def __init__(self):
        self.consumed = False

    # ----- Lifecycle hooks (override as needed) ----- #
    def on_blind_start(self, run) -> None:
        pass

    def on_round_end(self, run) -> None:
        pass

    def on_shop_enter(self, run) -> None:
        pass

    def on_boss_seen(self, run) -> None:
        pass

    # ----- Serialisation ----- #
    def to_dict(self) -> dict:
        return {"id": self.token_id}

    @classmethod
    def from_dict(cls, d: dict) -> Optional["Token"]:
        return make_token(d.get("id", ""))


# --------------------------------------------------------------------------- #
# Concrete tokens
# --------------------------------------------------------------------------- #
class EmberToken(Token):
    token_id = "ember"
    name = "Ember Token"
    description = "+$15 when the next blind starts."
    icon_glyph = "E"

    def on_blind_start(self, run):
        run.money += 15
        self.consumed = True


class CoinToken(Token):
    token_id = "coin"
    name = "Coin Token"
    description = "+$8 immediately, then +$8 at next round end."
    icon_glyph = "$"

    def __init__(self):
        super().__init__()
        self._given_immediate = False

    def on_blind_start(self, run):
        # First fire: instant cash
        if not self._given_immediate:
            run.money += 8
            self._given_immediate = True

    def on_round_end(self, run):
        if self._given_immediate:
            run.money += 8
            self.consumed = True


class CrowToken(Token):
    token_id = "crow"
    name = "Crow Token"
    description = "+$1 per hand played in this run, paid at next round end."
    icon_glyph = "C"

    def on_round_end(self, run):
        # `run.hands_left` was decremented as hands were played; the total
        # hands-played-so-far equals (total reset hands × rounds) - hands_left
        # at the moment of end. Simpler approximation: number of rounds beaten
        # times an average of 2 hands played.
        # We use a stored `_hands_played` counter on the run if available.
        played = getattr(run, "_total_hands_played", run.ante * 2)
        run.money += int(played)
        self.consumed = True


class WingToken(Token):
    token_id = "wing"
    name = "Wing Token"
    description = "+$2 per unspent discard at end of next round."
    icon_glyph = "W"

    def on_round_end(self, run):
        run.money += 2 * max(0, run.discards_left)
        self.consumed = True


class VultureToken(Token):
    token_id = "vulture"
    name = "Vulture Token"
    description = "Removes the rule of the next Boss Blind."
    icon_glyph = "V"

    def on_blind_start(self, run):
        # Only fires for boss blinds — neutralises their boss modifier.
        if run.current_blind is not None and run.current_blind.kind == "boss":
            run.current_blind.boss = None
            run.current_blind.score_target = run.current_blind._compute_target()
            self.consumed = True


class BlackToken(Token):
    token_id = "black"
    name = "Black Token"
    description = "+$10 when the next shop opens."
    icon_glyph = "B"

    def on_shop_enter(self, run):
        run.money += 10
        self.consumed = True


# --------------------------------------------------------------------------- #
# Registry + helpers
# --------------------------------------------------------------------------- #
TOKEN_DEFS: Dict[str, Type[Token]] = {
    cls.token_id: cls for cls in [
        EmberToken, CoinToken, CrowToken, WingToken, VultureToken, BlackToken,
    ]
}


def make_token(token_id: str) -> Optional[Token]:
    cls = TOKEN_DEFS.get(token_id)
    if cls is None:
        return None
    return cls()


def random_token(rng: random.Random) -> Token:
    return rng.choice(list(TOKEN_DEFS.values()))()


def fire_tokens(run, event: str) -> List[Token]:
    """
    Dispatch the named lifecycle event to every active token in `run.tokens`.
    Removes any token whose `consumed` flag becomes True.

    Returns the list of consumed tokens (for visual feedback).
    """
    consumed = []
    for tok in list(run.tokens):
        method = getattr(tok, f"on_{event}", None)
        if method is not None:
            try:
                method(run)
            except Exception:
                continue
        if tok.consumed:
            consumed.append(tok)
            if tok in run.tokens:
                run.tokens.remove(tok)
    return consumed


ALL_TOKEN_IDS = list(TOKEN_DEFS.keys())
