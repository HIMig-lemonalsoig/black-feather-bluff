"""
Card modifier system.

A card can carry **at most one** modifier (Optional[CardModifier]) that
changes how it scores or behaves over the run. Modifiers are split across
three thematic categories so the player can read them at a glance:

  * material — durability/quality modifiers (Reinforced, Enhanced,
               Fragile, Corrupted). Gold-bordered.
  * seal     — trigger modifiers (Energized, Persistent, Burst). Purple-bordered.
  * edition  — finish modifiers (Gilded, Mirrored, Iridescent). Cyan-bordered.

Each modifier is a small subclass of `CardModifier`. The base class defines
clean hook points:

  on_card_score(ctx, card)   — fired by score_hand when this card scores
  post_round(run, card)      — fired by RunState.end_blind for every deck card
                                Return True to have the card removed.
  is_consumed()              — return True once a one-shot modifier has fired

Adding a new modifier means dropping in another subclass and registering it.
Card-side and scoring-side code stays unchanged.

Serialisation: each modifier knows how to round-trip itself via to_dict /
from_dict, preserving any per-instance state (e.g. Energized's charge or
Corrupted's remaining-rounds counter).
"""

import random
from typing import Dict, Optional, Type


# --------------------------------------------------------------------------- #
# Category colors — surfaced to the UI for borders + corner badges
# --------------------------------------------------------------------------- #
CATEGORY_COLORS: Dict[str, tuple] = {
    "material": (218, 175, 55),    # gold
    "seal":     (175, 95, 215),    # purple
    "edition":  (60, 200, 240),    # cyan
}


# --------------------------------------------------------------------------- #
# Base class
# --------------------------------------------------------------------------- #
class CardModifier:
    """
    Subclass and set the class attrs to register a new modifier.

    Override `on_card_score` (and optionally `post_round` / `is_consumed`)
    to define the effect. Mutate `self.state` for per-instance counters that
    need to persist across rounds and save/load cycles.
    """
    # Identity
    mod_id: str = "base"
    name: str = "Base"
    description: str = ""
    category: str = "material"     # 'material' | 'seal' | 'edition'
    icon_glyph: str = "?"           # single character drawn on the corner badge
    rarity: str = "common"          # 'common' | 'uncommon' | 'rare'

    # Default behavior
    def __init__(self):
        self.state: Dict[str, float] = {}

    def on_card_score(self, ctx, card) -> None:
        """Called once each time this card scores. Mutate ctx."""
        pass

    def post_round(self, run, card) -> bool:
        """
        Called at end of each blind for every card in the deck.
        Return True to have the card removed from the deck.
        """
        return False

    def is_consumed(self) -> bool:
        """Return True when a one-shot modifier should be stripped from its card."""
        return False

    def effect_summary(self) -> str:
        """Short hint shown inline next to the card name."""
        return self.description

    # ----- Serialisation ----- #
    def to_dict(self) -> dict:
        return {"id": self.mod_id, "state": dict(self.state)}

    @classmethod
    def from_dict(cls, d: dict) -> Optional["CardModifier"]:
        m = make_modifier(d.get("id", ""))
        if m is None:
            return None
        m.state.update(d.get("state", {}))
        return m


# --------------------------------------------------------------------------- #
# Material category — durability / quality
# --------------------------------------------------------------------------- #
class ReinforcedModifier(CardModifier):
    mod_id = "reinforced"
    name = "REINFORCED"
    description = "+30 chips when this card scores."
    category = "material"
    icon_glyph = "R"
    rarity = "common"

    def on_card_score(self, ctx, card):
        ctx.add_chips(30, "Reinforced +30")


class EnhancedModifier(CardModifier):
    mod_id = "enhanced"
    name = "ENHANCED"
    description = "+6 Mult when this card scores."
    category = "material"
    icon_glyph = "E"
    rarity = "common"

    def on_card_score(self, ctx, card):
        ctx.add_mult(6, "Enhanced +6 Mult")


class FragileModifier(CardModifier):
    mod_id = "fragile"
    name = "FRAGILE"
    description = "+45 chips, but 25% chance to shatter (be removed from deck) each time it scores."
    category = "material"
    icon_glyph = "F"
    rarity = "uncommon"

    def on_card_score(self, ctx, card):
        ctx.add_chips(45, "Fragile +45")
        # Mark for breakage — the PlayScreen removes any card listed here
        # from the deck after the scoring sequence resolves.
        if random.random() < 0.25:
            existing = getattr(ctx, "_break_cards", None) or []
            existing.append(card)
            ctx._break_cards = existing


class CorruptedModifier(CardModifier):
    mod_id = "corrupted"
    name = "CORRUPTED"
    description = "+90 chips. Card decays after 3 rounds."
    category = "material"
    icon_glyph = "C"
    rarity = "uncommon"

    def __init__(self):
        super().__init__()
        self.state["rounds_left"] = 3

    def on_card_score(self, ctx, card):
        ctx.add_chips(90, "Corrupted +90")

    def post_round(self, run, card) -> bool:
        self.state["rounds_left"] = self.state.get("rounds_left", 3) - 1
        return self.state["rounds_left"] <= 0


# --------------------------------------------------------------------------- #
# Seal category — triggers
# --------------------------------------------------------------------------- #
class EnergizedModifier(CardModifier):
    mod_id = "energized"
    name = "ENERGIZED"
    description = "Builds +1 Mult per round of waiting. Discharges when scored."
    category = "seal"
    icon_glyph = "Z"
    rarity = "uncommon"

    def __init__(self):
        super().__init__()
        self.state["charge"] = 0

    def on_card_score(self, ctx, card):
        charge = int(self.state.get("charge", 0))
        if charge > 0:
            ctx.add_mult(charge, f"Energized +{charge} Mult")
            self.state["charge"] = 0

    def post_round(self, run, card) -> bool:
        # Build charge while sitting unused
        self.state["charge"] = self.state.get("charge", 0) + 1
        return False

    def effect_summary(self) -> str:
        charge = int(self.state.get("charge", 0))
        if charge > 0:
            return f"Energized — discharges +{charge} Mult when scored."
        return self.description


class PersistentModifier(CardModifier):
    mod_id = "persistent"
    name = "PERSISTENT"
    description = "This card retriggers — scores twice."
    category = "seal"
    icon_glyph = "2"
    rarity = "rare"

    def on_card_score(self, ctx, card):
        # Effective retrigger — add another instance of the card's chip value
        ctx.add_chips(card.chip_value, "Persistent retrigger")


class BurstModifier(CardModifier):
    mod_id = "burst"
    name = "BURST"
    description = "ONE-TIME: +80 chips and +12 Mult when scored. Then consumed."
    category = "seal"
    icon_glyph = "B"
    rarity = "rare"

    def __init__(self):
        super().__init__()
        self.state["used"] = 0

    def on_card_score(self, ctx, card):
        if not self.state.get("used"):
            ctx.add_chips(80, "Burst +80")
            ctx.add_mult(12, "Burst +12 Mult")
            self.state["used"] = 1

    def is_consumed(self) -> bool:
        return bool(self.state.get("used"))


# --------------------------------------------------------------------------- #
# Edition category — finishes (passive boosts when scored)
# --------------------------------------------------------------------------- #
class GildedModifier(CardModifier):
    mod_id = "gilded"
    name = "GILDED"
    description = "+15 chips when this card scores."
    category = "edition"
    icon_glyph = "G"
    rarity = "common"

    def on_card_score(self, ctx, card):
        ctx.add_chips(15, "Gilded +15")


class MirroredModifier(CardModifier):
    mod_id = "mirrored"
    name = "MIRRORED"
    description = "+3 Mult when this card scores."
    category = "edition"
    icon_glyph = "M"
    rarity = "uncommon"

    def on_card_score(self, ctx, card):
        ctx.add_mult(3, "Mirrored +3 Mult")


class IridescentModifier(CardModifier):
    mod_id = "iridescent"
    name = "IRIDESCENT"
    description = "x1.5 Mult when this card scores."
    category = "edition"
    icon_glyph = "I"
    rarity = "rare"

    def on_card_score(self, ctx, card):
        ctx.mult_mult(1.5, "Iridescent x1.5 Mult")


# --------------------------------------------------------------------------- #
# Registry + helpers
# --------------------------------------------------------------------------- #
MODIFIER_DEFS: Dict[str, Type[CardModifier]] = {
    cls.mod_id: cls for cls in [
        # Material
        ReinforcedModifier, EnhancedModifier, FragileModifier, CorruptedModifier,
        # Seal
        EnergizedModifier, PersistentModifier, BurstModifier,
        # Edition
        GildedModifier, MirroredModifier, IridescentModifier,
    ]
}


def make_modifier(mod_id: str) -> Optional[CardModifier]:
    cls = MODIFIER_DEFS.get(mod_id)
    if cls is None:
        return None
    return cls()


# Rarity weights — used by random_modifier to pick a class.
_RARITY_WEIGHTS = {"common": 5, "uncommon": 3, "rare": 1}


def random_modifier(rng: random.Random) -> CardModifier:
    """Roll a random modifier instance, weighted toward common ones."""
    pool = []
    for cls in MODIFIER_DEFS.values():
        w = _RARITY_WEIGHTS.get(cls.rarity, 1)
        for _ in range(w):
            pool.append(cls)
    return rng.choice(pool)()


def maybe_modifier(rng: random.Random, chance: float) -> Optional[CardModifier]:
    """Return a random modifier with the given probability, otherwise None."""
    if rng.random() < chance:
        return random_modifier(rng)
    return None


def category_color(mod: CardModifier) -> tuple:
    return CATEGORY_COLORS.get(mod.category, CATEGORY_COLORS["material"])


# Convenience for screens that want to list all modifier types (e.g., stats UI)
ALL_MODIFIER_IDS = list(MODIFIER_DEFS.keys())
