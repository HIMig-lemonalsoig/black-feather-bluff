"""
Game-wide constants. Tweak these to retune the game without hunting through code.

Grouped by topic: window, paths, card dimensions, balance numbers, hand scoring,
and the canonical 52-card deck definitions.
"""

import os

# --------------------------------------------------------------------------- #
# Window
# --------------------------------------------------------------------------- #
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
WINDOW_TITLE = "BLACKFEATHER BLUFF"
FPS = 60

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS_DIR = os.path.join(PROJECT_ROOT, "assets")
SAVE_DIR = os.path.join(PROJECT_ROOT, "save")
SAVE_FILE = os.path.join(SAVE_DIR, "savegame.json")
STATS_FILE = os.path.join(SAVE_DIR, "stats.json")

# --------------------------------------------------------------------------- #
# Card display
# --------------------------------------------------------------------------- #
# Bumped from 72×104 to 84×118 for clearer suit symbols and bigger ranks.
# The hand of 8 still fits: 8*84 + 7*10 = 742 px, centred in a 1280 px window.
CARD_WIDTH = 84
CARD_HEIGHT = 118
CARD_GAP = 10
CARD_LIFT = 28                # pixels a selected card rises
CARD_DEAL_DURATION = 0.25     # seconds per card during deal animation
CARD_FLY_DURATION = 0.35      # seconds for a card to fly to play area

# Joker display
JOKER_WIDTH = 86
JOKER_HEIGHT = 116
MAX_JOKERS = 5

# --------------------------------------------------------------------------- #
# Round limits
# --------------------------------------------------------------------------- #
HAND_SIZE = 8
SELECT_MAX = 5
HANDS_PER_ROUND = 4
DISCARDS_PER_ROUND = 3

# --------------------------------------------------------------------------- #
# Difficulty / progression
# --------------------------------------------------------------------------- #
# Score required at each ante for the Small Blind (multiplied for Big/Boss).
ANTE_BASE_REQUIREMENTS = [300, 800, 2000, 5000, 11000, 20000, 35000, 50000]
SMALL_BLIND_MULT = 1.0
BIG_BLIND_MULT   = 1.5
BOSS_BLIND_MULT  = 2.0
MAX_ANTE = 8                  # beat the Ante 8 Boss to win

# --------------------------------------------------------------------------- #
# Economy
# --------------------------------------------------------------------------- #
STARTING_MONEY = 4
BLIND_BASE_REWARD = {"small": 3, "big": 4, "boss": 5}
INTEREST_PER_5 = 1            # +$1 per $5 banked at round end
INTEREST_CAP = 5
HAND_REWARD = 1               # $ per unspent hand at round end

# --------------------------------------------------------------------------- #
# Shop prices
# --------------------------------------------------------------------------- #
JOKER_PRICE_RANGE = (4, 7)
REROLL_BASE_PRICE = 2
REROLL_PRICE_GROWTH = 1       # +$1 per reroll within a single shop visit

# --------------------------------------------------------------------------- #
# Poker hand definitions
# --------------------------------------------------------------------------- #
HAND_TYPES = [
    "high_card", "pair", "two_pair", "three_kind",
    "straight", "flush", "full_house", "four_kind",
    "straight_flush", "royal_flush"
]

# (base_chips, base_multiplier) before card values and jokers
HAND_BASE_SCORES = {
    "high_card":      (5,   1),
    "pair":           (10,  2),
    "two_pair":       (20,  2),
    "three_kind":     (30,  3),
    "straight":       (30,  4),
    "flush":          (35,  4),
    "full_house":     (40,  4),
    "four_kind":      (60,  7),
    "straight_flush": (100, 8),
    "royal_flush":    (120, 9),
}

HAND_DISPLAY_NAMES = {
    "high_card":      "High Card",
    "pair":           "Pair",
    "two_pair":       "Two Pair",
    "three_kind":     "Three of a Kind",
    "straight":       "Straight",
    "flush":          "Flush",
    "full_house":     "Full House",
    "four_kind":      "Four of a Kind",
    "straight_flush": "Straight Flush",
    "royal_flush":    "Royal Flush",
}

# --------------------------------------------------------------------------- #
# Card definitions
# --------------------------------------------------------------------------- #
SUITS = ['spades', 'hearts', 'diamonds', 'clubs']
SUIT_SYMBOLS = {
    'spades':   '♠',  # ♠
    'hearts':   '♥',  # ♥
    'diamonds': '♦',  # ♦
    'clubs':    '♣',  # ♣
}
RED_SUITS = {'hearts', 'diamonds'}

RANKS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
# Numeric rank for straight detection (Ace high)
RANK_VALUES = {r: i + 2 for i, r in enumerate(RANKS)}
# Chip value contributed by the card when it scores
RANK_CHIP_VALUES = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
    'J': 10, 'Q': 10, 'K': 10, 'A': 11,
}
FACE_RANKS = {'J', 'Q', 'K'}
LOW_RANKS = {'2', '3', '4', '5'}
HIGH_RANKS = {'10', 'J', 'Q', 'K', 'A'}
