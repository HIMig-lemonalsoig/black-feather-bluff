"""
Omens system — BLACKFEATHER BLUFF's tarot equivalent.

An Omen is a consumable held in your inventory (max 2 slots by default). When
used, it applies an effect to the run — destroying cards, converting suits,
gaining money, applying a modifier, etc. Each omen is themed around a
bird/dark casino motif.

Some omens require **targets** (selected cards in your hand). The PlayScreen
handles the click-omen → select-target → confirm flow; omens whose
`needs_target` is True can't fire without a valid selection.

Data model:
    class Omen:
        omen_id, name, description, needs_target, max_targets, rarity, icon_glyph

        def can_use(self, run, targets) -> bool      # preconditions
        def apply(self, run, targets) -> bool        # mutate state, return True on success
        def to_dict() / from_dict()                  # save round-trip

Adding a new omen = one new subclass + register it in OMEN_DEFS.
"""

import random
from typing import Dict, List, Optional, Type


# Visual category — packs of "augury" cards have their own tint.
OMEN_COLOR = (175, 95, 215)        # purple, distinct from the modifier categories


class Omen:
    """Subclass and override apply()."""
    omen_id: str = "base"
    name: str = "Base Omen"
    description: str = ""
    icon_glyph: str = "?"
    rarity: str = "common"          # 'common' | 'uncommon' | 'rare'
    needs_target: bool = False      # if True, requires selected hand cards
    min_targets: int = 0
    max_targets: int = 0

    def can_use(self, run, targets: list) -> bool:
        """Return True if the omen can fire right now."""
        if self.needs_target:
            n = len(targets)
            return self.min_targets <= n <= self.max_targets
        return True

    def apply(self, run, targets: list) -> bool:
        """Apply the omen's effect. Returns True if it succeeded."""
        return False

    def to_dict(self) -> dict:
        return {"id": self.omen_id}

    @classmethod
    def from_dict(cls, d: dict) -> Optional["Omen"]:
        return make_omen(d.get("id", ""))


# --------------------------------------------------------------------------- #
# Concrete omens
# --------------------------------------------------------------------------- #
class CrowsEyeOmen(Omen):
    omen_id = "crows_eye"
    name = "Crow's Eye"
    description = "Destroy up to 2 selected cards from your hand."
    icon_glyph = "X"
    rarity = "common"
    needs_target = True
    min_targets = 1
    max_targets = 2

    def apply(self, run, targets):
        for card in targets:
            run.deck.remove_card(card)
            if card in run.hand:
                run.hand.remove(card)
        return True


class VulturesPickOmen(Omen):
    omen_id = "vultures_pick"
    name = "Vulture's Pick"
    description = "Convert up to 3 selected cards to Spades."
    icon_glyph = "S"
    rarity = "common"
    needs_target = True
    min_targets = 1
    max_targets = 3

    def apply(self, run, targets):
        for card in targets:
            card.suit = "spades"
        return True


class SwanSongOmen(Omen):
    omen_id = "swan_song"
    name = "Swan Song"
    description = "Convert up to 3 selected cards to Hearts."
    icon_glyph = "H"
    rarity = "common"
    needs_target = True
    min_targets = 1
    max_targets = 3

    def apply(self, run, targets):
        for card in targets:
            card.suit = "hearts"
        return True


class KingfisherOmen(Omen):
    omen_id = "kingfisher"
    name = "Kingfisher"
    description = "Convert up to 3 selected cards to Diamonds."
    icon_glyph = "D"
    rarity = "common"
    needs_target = True
    min_targets = 1
    max_targets = 3

    def apply(self, run, targets):
        for card in targets:
            card.suit = "diamonds"
        return True


class HummingbirdOmen(Omen):
    omen_id = "hummingbird"
    name = "Hummingbird"
    description = "Convert up to 3 selected cards to Clubs."
    icon_glyph = "L"   # L for leaf, since C is used elsewhere
    rarity = "common"
    needs_target = True
    min_targets = 1
    max_targets = 3

    def apply(self, run, targets):
        for card in targets:
            card.suit = "clubs"
        return True


class EaglesTalonOmen(Omen):
    omen_id = "eagles_talon"
    name = "Eagle's Talon"
    description = "Increase the rank of up to 2 selected cards by 1."
    icon_glyph = "^"
    rarity = "uncommon"
    needs_target = True
    min_targets = 1
    max_targets = 2

    # Rank progression — Aces wrap to nothing (they stay Ace).
    RANK_ORDER = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']

    def apply(self, run, targets):
        for card in targets:
            try:
                idx = self.RANK_ORDER.index(card.rank)
            except ValueError:
                continue
            if idx < len(self.RANK_ORDER) - 1:
                card.rank = self.RANK_ORDER[idx + 1]
        return True


class FalconsMarkOmen(Omen):
    omen_id = "falcons_mark"
    name = "Falcon's Mark"
    description = "Apply a random modifier to 1 selected card."
    icon_glyph = "!"
    rarity = "uncommon"
    needs_target = True
    min_targets = 1
    max_targets = 1

    def apply(self, run, targets):
        from game.modifiers import random_modifier
        if not targets:
            return False
        card = targets[0]
        card.modifier = random_modifier(run.rng)
        return True


class RavensBoonOmen(Omen):
    omen_id = "ravens_boon"
    name = "Raven's Boon"
    description = "Gain $8 instantly."
    icon_glyph = "$"
    rarity = "common"
    needs_target = False

    def apply(self, run, targets):
        run.money += 8
        return True


class OwlSightOmen(Omen):
    omen_id = "owl_sight"
    name = "Owl Sight"
    description = "Reveal the top 5 cards of your deck (briefly). Gain $4."
    icon_glyph = "O"
    rarity = "common"
    needs_target = False

    def apply(self, run, targets):
        # We can't open a true UI inspector here, so we settle for a money
        # bonus and let the existing Owl Joker peek mechanic do the reveal.
        # Players still benefit if they own Owl. (The omen is meant to be a
        # consolation buy when nothing better is in the shop.)
        run.money += 4
        return True


class HermitsCoinOmen(Omen):
    omen_id = "hermits_coin"
    name = "Hermit's Coin"
    description = "Double your money (capped at +$20)."
    icon_glyph = "C"
    rarity = "rare"
    needs_target = False

    def apply(self, run, targets):
        bonus = min(20, run.money)
        run.money += bonus
        return True


# --------------------------------------------------------------------------- #
# Registry + helpers
# --------------------------------------------------------------------------- #
OMEN_DEFS: Dict[str, Type[Omen]] = {
    cls.omen_id: cls for cls in [
        CrowsEyeOmen, VulturesPickOmen, SwanSongOmen, KingfisherOmen,
        HummingbirdOmen, EaglesTalonOmen, FalconsMarkOmen,
        RavensBoonOmen, OwlSightOmen, HermitsCoinOmen,
    ]
}

_RARITY_WEIGHTS = {"common": 5, "uncommon": 3, "rare": 1}


def make_omen(omen_id: str) -> Optional[Omen]:
    cls = OMEN_DEFS.get(omen_id)
    if cls is None:
        return None
    return cls()


def random_omen(rng: random.Random) -> Omen:
    """Roll a random omen, weighted toward common ones."""
    pool = []
    for cls in OMEN_DEFS.values():
        w = _RARITY_WEIGHTS.get(cls.rarity, 1)
        pool.extend([cls] * w)
    return rng.choice(pool)()


ALL_OMEN_IDS = list(OMEN_DEFS.keys())
