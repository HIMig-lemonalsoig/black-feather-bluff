"""
Bird Joker system.

Each joker has an `on_score(ctx, all_jokers)` hook called during hand scoring,
plus optional event hooks (`on_discard`, `on_round_start`) for stateful jokers
like Crow (which scales on discards).

Joker definitions live in JOKER_DEFS so we can list, instantiate, and serialise
them cleanly.
"""

import random
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional


# --------------------------------------------------------------------------- #
# Joker base class
# --------------------------------------------------------------------------- #
class Joker:
    """Base class. Subclasses override hook methods to apply effects."""
    joker_id: str = "base"
    name: str = "Base"
    description: str = ""
    rarity: str = "common"
    base_price: int = 5
    sell_value: int = 2

    def __init__(self):
        # Internal state (e.g. scaled multiplier). Cleared on round start
        # for some jokers, persistent for others.
        self.state: Dict[str, float] = {}

    # ----- Hook points ----- #
    def on_score(self, ctx, all_jokers: List["Joker"]) -> None:
        """Called once per played hand, AFTER base chips and card chips are added."""
        pass

    def on_discard(self, discarded_cards) -> None:
        """Called whenever the player discards (some jokers scale here)."""
        pass

    def on_round_start(self) -> None:
        """Called at the start of each blind (reset volatile state)."""
        pass

    def on_round_end(self) -> None:
        """Called at the end of each blind (cash out)."""
        pass

    # ----- Display helpers ----- #
    def status_text(self) -> str:
        """Optional small text drawn on the joker card (e.g. '+5 mult')."""
        return ""

    # ----- Serialisation ----- #
    def to_dict(self) -> dict:
        return {"id": self.joker_id, "state": dict(self.state)}

    @classmethod
    def from_dict(cls, d: dict) -> "Joker":
        j = make_joker(d["id"])
        j.state.update(d.get("state", {}))
        return j


# --------------------------------------------------------------------------- #
# Concrete bird jokers
# --------------------------------------------------------------------------- #
class RavenJoker(Joker):
    joker_id = "raven"
    name = "RAVEN"
    description = "+3 Mult for every High Card (10, J, Q, K, A) in scoring hand."
    rarity = "common"
    base_price = 4

    def on_score(self, ctx, all_jokers):
        bonus = sum(1 for c in ctx.scoring_cards if c.is_high) * 3
        if bonus:
            ctx.add_mult(bonus, f"Raven +{bonus} Mult")


class CrowJoker(Joker):
    joker_id = "crow"
    name = "CROW"
    description = "Gains +2 Mult permanently each time you discard."
    rarity = "uncommon"
    base_price = 6

    def on_score(self, ctx, all_jokers):
        scaled = self.state.get("mult", 0.0)
        if scaled:
            ctx.add_mult(scaled, f"Crow +{int(scaled)} Mult")

    def on_discard(self, discarded_cards):
        self.state["mult"] = self.state.get("mult", 0.0) + 2.0

    def status_text(self) -> str:
        m = int(self.state.get("mult", 0))
        return f"+{m} Mult" if m else ""


class OwlJoker(Joker):
    joker_id = "owl"
    name = "OWL"
    description = "Straights score x3 Mult. Peek at the next card in deck."
    rarity = "uncommon"
    base_price = 6

    def on_score(self, ctx, all_jokers):
        if ctx.hand_type in ("straight", "straight_flush", "royal_flush"):
            ctx.mult_mult(3.0, "Owl x3 Mult")

    # OwlJoker.peek_enabled is read by the UI to reveal the top card.
    peek_enabled = True


class PeacockJoker(Joker):
    joker_id = "peacock"
    name = "PEACOCK"
    description = "Flushes score x4 Mult and +40 chips."
    rarity = "rare"
    base_price = 7

    def on_score(self, ctx, all_jokers):
        if ctx.hand_type in ("flush", "straight_flush", "royal_flush"):
            ctx.add_chips(40, "Peacock +40 Chips")
            ctx.mult_mult(4.0, "Peacock x4 Mult")


class EagleJoker(Joker):
    joker_id = "eagle"
    name = "EAGLE"
    description = "Each scoring Ace gives +30 Chips and +5 Mult."
    rarity = "rare"
    base_price = 7

    def on_score(self, ctx, all_jokers):
        aces = sum(1 for c in ctx.scoring_cards if c.is_ace)
        if aces:
            ctx.add_chips(30 * aces, f"Eagle +{30*aces} Chips")
            ctx.add_mult(5 * aces, f"Eagle +{5*aces} Mult")


class VultureJoker(Joker):
    joker_id = "vulture"
    name = "VULTURE"
    description = "+15 Chips for every Low Card (2-5) in scoring hand."
    rarity = "common"
    base_price = 4

    def on_score(self, ctx, all_jokers):
        bonus = sum(1 for c in ctx.scoring_cards if c.is_low) * 15
        if bonus:
            ctx.add_chips(bonus, f"Vulture +{bonus} Chips")


class ParrotJoker(Joker):
    joker_id = "parrot"
    name = "PARROT"
    description = "Copies the on-score effect of the joker to its LEFT."
    rarity = "legendary"
    base_price = 8

    def on_score(self, ctx, all_jokers):
        # Find ourselves in the slot order, then trigger the left neighbour again.
        try:
            idx = all_jokers.index(self)
        except ValueError:
            return
        if idx == 0:
            return
        left = all_jokers[idx - 1]
        # Avoid infinite chains if someone parrots a parrot
        if isinstance(left, ParrotJoker):
            return
        left.on_score(ctx, all_jokers)


class FalconJoker(Joker):
    joker_id = "falcon"
    name = "FALCON"
    description = "Pairs and Three-of-a-Kinds gain +6 Mult."
    rarity = "uncommon"
    base_price = 5

    def on_score(self, ctx, all_jokers):
        if ctx.hand_type in ("pair", "two_pair", "three_kind", "four_kind", "full_house"):
            ctx.add_mult(6, "Falcon +6 Mult")


class SwanJoker(Joker):
    joker_id = "swan"
    name = "SWAN"
    description = "+25 Chips per face card (J, Q, K) in your hand on play."
    rarity = "common"
    base_price = 4

    def on_score(self, ctx, all_jokers):
        bonus = sum(25 for c in ctx.played_cards if c.is_face)
        if bonus:
            ctx.add_chips(bonus, f"Swan +{bonus} Chips")


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #
JOKER_DEFS: Dict[str, type] = {
    cls.joker_id: cls for cls in [
        RavenJoker, CrowJoker, OwlJoker, PeacockJoker, EagleJoker,
        VultureJoker, ParrotJoker, FalconJoker, SwanJoker,
    ]
}

# Jokers available from a fresh save (rest are unlock rewards).
STARTING_UNLOCKS = ["raven", "crow", "owl", "vulture", "swan"]
ALL_JOKER_IDS = list(JOKER_DEFS.keys())


def make_joker(joker_id: str) -> Joker:
    cls = JOKER_DEFS.get(joker_id)
    if cls is None:
        # Fallback to a safe no-op
        cls = RavenJoker
    return cls()


def joker_def(joker_id: str) -> Joker:
    """Return a fresh prototype instance to read static fields like name/desc."""
    return make_joker(joker_id)


def random_joker_ids(rng: random.Random, unlocked: List[str], n: int,
                     exclude: Optional[List[str]] = None) -> List[str]:
    """Pick `n` random unlocked joker IDs (with replacement protection)."""
    exclude = set(exclude or [])
    pool = [j for j in unlocked if j not in exclude]
    if not pool:
        return []
    out = []
    pool = pool.copy()
    rng.shuffle(pool)
    for jid in pool:
        out.append(jid)
        if len(out) >= n:
            break
    # If pool was smaller than n, allow repeats.
    while len(out) < n:
        out.append(rng.choice(unlocked))
    return out
