"""
Shop between blinds.

Two product lines:
  * Single items — jokers, utility cards. Bought directly.
  * Booster packs — pay once, reveal N options, choose 1 (Balatro-style).

Each shop visit rolls a fixed set of both. The player can buy, reroll the
whole shop, or leave. Reroll re-rolls both rows together.
"""

import random
from dataclasses import dataclass, field
from typing import List, Optional

from game.jokers import joker_def, random_joker_ids, make_joker, ALL_JOKER_IDS
from game.cards import Card
from game.modifiers import maybe_modifier
from game.constants import (
    JOKER_PRICE_RANGE, REROLL_BASE_PRICE, REROLL_PRICE_GROWTH,
    SUITS, RANKS,
)

# Probability of a generated card carrying a modifier.
SHOP_CARD_MODIFIER_CHANCE = 0.25
PACK_CARD_MODIFIER_CHANCE = 0.40
# Modifier-aware extras for description
MODIFIER_PRICE_BUMP = 2


# --------------------------------------------------------------------------- #
# Items — single-purchase shop entries
# --------------------------------------------------------------------------- #
@dataclass
class ShopItem:
    """A single shop entry the player can buy directly."""
    name: str
    price: int
    description: str
    sold: bool = False

    kind: str = "base"
    payload: object = None


# --------------------------------------------------------------------------- #
# Booster packs — pay once, reveal multiple options, pick a subset
# --------------------------------------------------------------------------- #
PACK_KIND_LABELS = {
    "card":       "STANDARD PACK",
    "mega_card":  "MEGA PACK",
    "joker":      "JOKER PACK",
    "mega_joker": "MEGA JOKER PACK",
    "face":       "TALON PACK",
    "ace":        "BLACK ACE PACK",
    "augury":     "AUGURY PACK",
}

PACK_KIND_HINTS = {
    "card":       "Reveals 3 cards. Choose 1.",
    "mega_card":  "Reveals 5 cards. Choose 1.",
    "joker":      "Reveals 2 jokers. Choose 1.",
    "mega_joker": "Reveals 4 jokers. Choose 1.",
    "face":       "Reveals 3 face cards. Choose 1.",
    "ace":        "Reveals 3 Aces. Choose 1.",
    "augury":     "Reveals 3 Omens. Choose 1.",
}


@dataclass
class BoosterPack:
    """A booster pack — pays once, reveals `reveal_count` items, takes `choose_count`."""
    name: str
    price: int
    pack_kind: str
    reveal_count: int
    choose_count: int = 1
    sold: bool = False
    rarity: str = "common"   # 'common' | 'rare' | 'legendary' — drives visuals

    @property
    def hint(self) -> str:
        return PACK_KIND_HINTS.get(self.pack_kind, "")


# --------------------------------------------------------------------------- #
# Shop
# --------------------------------------------------------------------------- #
class Shop:
    """A single shop visit. Items + packs both refresh on reroll."""

    ITEM_SLOTS = 4
    PACK_SLOTS = 2

    def __init__(self, rng: random.Random, unlocked_jokers: List[str], owned_joker_ids: List[str]):
        self.rng = rng
        self.unlocked = unlocked_jokers
        self.owned_ids = owned_joker_ids
        self.items: List[ShopItem] = []
        self.packs: List[BoosterPack] = []
        self.reroll_count = 0
        self._roll()

    def reroll_price(self) -> int:
        return REROLL_BASE_PRICE + REROLL_PRICE_GROWTH * self.reroll_count

    def reroll(self) -> None:
        self.reroll_count += 1
        self._roll()

    # ----- Roll ----- #
    def _roll(self) -> None:
        self.items.clear()
        self.packs.clear()

        # Single items: 2 jokers + 2 utility cards
        ids = random_joker_ids(self.rng, self.unlocked, 2, exclude=self.owned_ids)
        for jid in ids:
            self.items.append(self._make_joker_item(jid))
        for _ in range(self.ITEM_SLOTS - len(self.items)):
            self.items.append(self._make_utility_item())

        # Booster packs
        for _ in range(self.PACK_SLOTS):
            self.packs.append(self._make_pack())

    def _make_joker_item(self, jid: str) -> ShopItem:
        proto = joker_def(jid)
        price = self.rng.randint(*JOKER_PRICE_RANGE)
        rarity_bump = {"common": 0, "uncommon": 1, "rare": 2, "legendary": 3}.get(proto.rarity, 0)
        price += rarity_bump
        return ShopItem(
            name=proto.name,
            price=price,
            description=proto.description,
            kind="joker",
            payload=jid,
        )

    def _make_utility_item(self) -> ShopItem:
        """One of the small one-shot utility items (Crow's Eye, Ember, etc.)."""
        roll = self.rng.random()
        if roll < 0.40:
            return ShopItem(
                name="Crow's Eye",
                price=3,
                description="Remove the next card you discard, permanently.",
                kind="next_remove",
                payload=None,
            )
        if roll < 0.75:
            return ShopItem(
                name="Ember of Fortune",
                price=4,
                description="Gain $6 immediately.",
                kind="money",
                payload=6,
            )
        # Rare single-card item — drops a specific Ace into your deck.
        # The card may roll with a modifier (Reinforced, Foil, etc.) which
        # bumps the price slightly.
        suit = self.rng.choice(SUITS)
        card = Card(rank="A", suit=suit)
        mod = maybe_modifier(self.rng, SHOP_CARD_MODIFIER_CHANCE)
        if mod is not None:
            card.modifier = mod
            name = f"{mod.name} Ace of {suit.title()}"
            desc = f"Add an Ace of {suit.title()} with {mod.name} ({mod.description})"
            price = 5 + MODIFIER_PRICE_BUMP
        else:
            name = f"Lone Ace of {suit.title()}"
            desc = f"Add an Ace of {suit.title()} to your deck."
            price = 5
        return ShopItem(
            name=name, price=price, description=desc,
            kind="add_card", payload=card,
        )

    def _make_pack(self) -> BoosterPack:
        """Roll a random booster pack — weighted toward standard packs."""
        roll = self.rng.random()
        if roll < 0.36:
            return BoosterPack(
                name=PACK_KIND_LABELS["card"], price=4,
                pack_kind="card", reveal_count=3, choose_count=1,
                rarity="common",
            )
        if roll < 0.60:
            return BoosterPack(
                name=PACK_KIND_LABELS["joker"], price=6,
                pack_kind="joker", reveal_count=2, choose_count=1,
                rarity="common",
            )
        if roll < 0.78:
            return BoosterPack(
                name=PACK_KIND_LABELS["face"], price=5,
                pack_kind="face", reveal_count=3, choose_count=1,
                rarity="common",
            )
        if roll < 0.90:
            return BoosterPack(
                name=PACK_KIND_LABELS["mega_card"], price=7,
                pack_kind="mega_card", reveal_count=5, choose_count=1,
                rarity="rare",
            )
        if roll < 0.90:
            return BoosterPack(
                name=PACK_KIND_LABELS["ace"], price=7,
                pack_kind="ace", reveal_count=3, choose_count=1,
                rarity="rare",
            )
        if roll < 0.97:
            return BoosterPack(
                name=PACK_KIND_LABELS["augury"], price=6,
                pack_kind="augury", reveal_count=3, choose_count=1,
                rarity="rare",
            )
        return BoosterPack(
            name=PACK_KIND_LABELS["mega_joker"], price=9,
            pack_kind="mega_joker", reveal_count=4, choose_count=1,
            rarity="legendary",
        )

    # ----- Pack opening ----- #
    def open_pack(self, pack: BoosterPack) -> List[ShopItem]:
        """
        Roll fresh contents for a pack. Called when the player buys it.

        Returns a list of `pack.reveal_count` ShopItems with price=0 — the
        player has already paid for the pack itself, so the contents are
        "free" picks.
        """
        out: List[ShopItem] = []
        kind = pack.pack_kind

        if kind in ("card", "mega_card"):
            for _ in range(pack.reveal_count):
                rank = self.rng.choice(RANKS)
                suit = self.rng.choice(SUITS)
                out.append(self._free_card_item(rank, suit))

        elif kind == "face":
            for _ in range(pack.reveal_count):
                rank = self.rng.choice(["J", "Q", "K"])
                suit = self.rng.choice(SUITS)
                out.append(self._free_card_item(rank, suit))

        elif kind == "ace":
            # All 4 suits guaranteed if reveal_count >= 4, otherwise sample
            suits = list(SUITS)
            self.rng.shuffle(suits)
            for i in range(pack.reveal_count):
                suit = suits[i % len(suits)]
                out.append(self._free_card_item("A", suit))

        elif kind in ("joker", "mega_joker"):
            # Show jokers the player doesn't already own.
            ids = random_joker_ids(
                self.rng, self.unlocked, pack.reveal_count,
                exclude=self.owned_ids,
            )
            for jid in ids:
                proto = joker_def(jid)
                out.append(ShopItem(
                    name=proto.name,
                    price=0,
                    description=proto.description,
                    kind="joker",
                    payload=jid,
                ))

        elif kind == "augury":
            # Random omens — themed tarot equivalents.
            from game.omens import random_omen
            for _ in range(pack.reveal_count):
                omen = random_omen(self.rng)
                out.append(ShopItem(
                    name=omen.name,
                    price=0,
                    description=omen.description,
                    kind="omen",
                    payload=omen,
                ))

        return out

    def _free_card_item(self, rank: str, suit: str) -> ShopItem:
        """Card-content for a booster pack. May roll a modifier — packs are
        the most reliable source of modified cards in the game."""
        card = Card(rank=rank, suit=suit)
        mod = maybe_modifier(self.rng, PACK_CARD_MODIFIER_CHANCE)
        if mod is not None:
            card.modifier = mod
            name = f"{rank} of {suit.title()} ({mod.name})"
            desc = f"{mod.name}: {mod.description}"
        else:
            name = f"{rank} of {suit.title()}"
            desc = f"Add a {rank} of {suit.title()} to your deck."
        return ShopItem(
            name=name, price=0, description=desc,
            kind="add_card", payload=card,
        )

    # ----- Buying ----- #
    def buy(self, item: ShopItem, run_state) -> bool:
        """Apply a single-item purchase."""
        if item.sold:
            return False
        if item.kind == "joker":
            if len(run_state.jokers) >= run_state.max_joker_slots:
                return False
            j = make_joker(item.payload)
            run_state.jokers.append(j)
        elif item.kind == "add_card":
            run_state.deck.add_card(item.payload)
        elif item.kind == "next_remove":
            run_state.pending_remove = True
        elif item.kind == "money":
            run_state.money += int(item.payload)
        else:
            return False
        item.sold = True
        return True

    def take_pack_item(self, item: ShopItem, run_state) -> bool:
        """
        Apply a pack-content item. Same effects as `buy()` but always free
        and doesn't require checking item.sold or item.price.
        """
        if item.kind == "joker":
            if len(run_state.jokers) >= run_state.max_joker_slots:
                return False
            run_state.jokers.append(make_joker(item.payload))
        elif item.kind == "add_card":
            run_state.deck.add_card(item.payload)
        elif item.kind == "money":
            run_state.money += int(item.payload)
        elif item.kind == "omen":
            # Take an omen from an Augury Pack
            if len(run_state.omens) >= run_state.max_omen_slots:
                return False
            run_state.omens.append(item.payload)
        else:
            return False
        item.sold = True
        return True
