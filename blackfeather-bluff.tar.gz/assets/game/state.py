"""
Top-level Game state, RunState, and screen routing.

Game owns:
  - the active screen
  - persistent stats (loaded from stats.json)
  - the current RunState (None when between runs)
  - shared resources (assets, sounds)

Screens call `game.switch_to(name, **kwargs)` to navigate. They are responsible
for their own input/update/draw.
"""

import random
from typing import Dict, List, Optional

from game.constants import (
    HAND_SIZE, HANDS_PER_ROUND, DISCARDS_PER_ROUND,
    STARTING_MONEY, MAX_ANTE, INTEREST_PER_5, INTEREST_CAP, HAND_REWARD,
)
from game.cards import Deck, Card
from game.jokers import Joker, make_joker, ALL_JOKER_IDS
from game.blinds import Blind, make_blind
from game.save import save_run, load_run, clear_run, load_stats, save_stats


# --------------------------------------------------------------------------- #
# Run state
# --------------------------------------------------------------------------- #
class RunState:
    """Everything about a single roguelike run."""

    def __init__(self, seed: Optional[int] = None):
        self.seed = seed if seed is not None else random.randint(0, 2**31 - 1)
        self.rng = random.Random(self.seed)

        # Deck and jokers
        self.deck = Deck()
        self.deck.shuffle(self.rng)
        self.jokers: List[Joker] = []
        self.max_joker_slots = 5

        # Economy
        self.money = STARTING_MONEY

        # Progression
        self.ante = 1
        self.blind_kinds = ["small", "big", "boss"]
        self.blind_idx = 0           # 0..2 within current ante
        self.current_blind: Optional[Blind] = None
        self.round_score = 0
        self.hands_left = HANDS_PER_ROUND
        self.discards_left = DISCARDS_PER_ROUND

        # Misc
        self.hand_size = HAND_SIZE
        self.hand: List[Card] = []   # cards in player's hand right now
        self.pending_remove = False  # next discard removes those cards from the deck
        self.best_score_this_run = 0
        self.completed = False       # set True on full win

    # ----- Round lifecycle ----- #
    def start_blind(self, blind: Blind) -> None:
        self.current_blind = blind
        self.round_score = 0
        self.hands_left = max(1, HANDS_PER_ROUND + (blind.boss.hand_limit_delta() if blind.boss else 0))
        discard_delta = blind.boss.discard_limit_delta() if blind.boss else 0
        self.discards_left = max(0, DISCARDS_PER_ROUND + discard_delta)
        self.hand = []
        # Return any played/discarded cards to the deck
        self.deck.shuffle(self.rng)
        # Reset transient visual state so newly-dealt cards animate cleanly.
        for c in self.deck.all_cards():
            c.pos = (0.0, 0.0)
            c.target = (0.0, 0.0)
            c.selected = False
            c.glow = 0.0
            c.in_hand = False
            c.hover_t = 0.0
            c.pulse_t = 1.0
            c.rotation = 0.0
            c.fan_rotation = 0.0
            c.scale = 1.0
            c.motion_mode = "smooth"
            c.deal_delay = 0.0
            c.arc_t = 0.0
            c.fade_t = 0.0
            c.dead = False
        for j in self.jokers:
            j.on_round_start()

    def end_blind(self) -> dict:
        """
        Cash out the current blind. Returns a breakdown dict so callers
        (the round-result transition) can animate each component
        independently:

            {
              'base':           int,  # base blind reward
              'interest':       int,  # interest dollars earned
              'interest_count': int,  # number of $5 you held
              'hand_bonus':     int,  # $ from unspent hands
              'hands_left':     int,  # cached for display
              'total':          int,  # all combined
            }
        """
        if not self.current_blind:
            return {"base": 0, "interest": 0, "interest_count": 0,
                    "hand_bonus": 0, "hands_left": 0, "total": 0}
        base = self.current_blind.reward
        interest_count = min(INTEREST_CAP, self.money // 5)
        interest = interest_count * INTEREST_PER_5
        hand_bonus = self.hands_left * HAND_REWARD
        total = base + interest + hand_bonus
        self.money += total
        for j in self.jokers:
            j.on_round_end()
        # Run modifier post-round hooks on every deck card. Modifiers like
        # Energized accumulate charge here; Corrupted's timer ticks down and
        # may return True (remove card) when it expires.
        decayed = []
        for c in self.deck.all_cards():
            mod = getattr(c, "modifier", None)
            if mod is not None and mod.post_round(self, c):
                decayed.append(c)
        for c in decayed:
            self.deck.remove_card(c)
        return {
            "base": base,
            "interest": interest,
            "interest_count": interest_count,
            "hand_bonus": hand_bonus,
            "hands_left": self.hands_left,
            "total": total,
        }

    def advance_blind(self) -> bool:
        """Move to next blind in sequence. Returns True if the run continues."""
        self.blind_idx += 1
        if self.blind_idx >= len(self.blind_kinds):
            self.blind_idx = 0
            self.ante += 1
            if self.ante > MAX_ANTE:
                self.completed = True
                return False
        return True

    def current_blind_kind(self) -> str:
        return self.blind_kinds[self.blind_idx]

    def make_current_blind(self) -> Blind:
        return make_blind(self.ante, self.current_blind_kind(), self.rng)

    # ----- Deck access ----- #
    def deal_to_hand(self) -> List[Card]:
        """Top up the hand to hand_size from the deck. Returns the newly dealt cards."""
        need = self.hand_size - len(self.hand)
        drawn = self.deck.draw(need)
        # Newly dealt cards start as in-hand
        for c in drawn:
            c.in_hand = True
            c.selected = False
            c.face_up = True
        self.hand.extend(drawn)
        return drawn

    # ----- Serialisation ----- #
    def to_dict(self) -> dict:
        return {
            "seed": self.seed,
            "deck": self.deck.to_list(),
            "jokers": [j.to_dict() for j in self.jokers],
            "money": self.money,
            "ante": self.ante,
            "blind_idx": self.blind_idx,
            "best_score": self.best_score_this_run,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "RunState":
        r = cls(seed=d.get("seed"))
        r.deck = Deck.from_list(d["deck"])
        r.deck.shuffle(r.rng)
        r.jokers = [Joker.from_dict(jd) for jd in d.get("jokers", [])]
        r.money = d.get("money", STARTING_MONEY)
        r.ante = d.get("ante", 1)
        r.blind_idx = d.get("blind_idx", 0)
        r.best_score_this_run = d.get("best_score", 0)
        return r


# --------------------------------------------------------------------------- #
# Top-level Game
# --------------------------------------------------------------------------- #
class Game:
    """Owns the active screen and shared state."""

    def __init__(self, screen):
        self.screen = screen
        self.should_quit = False

        # Persistent stats
        self.stats = load_stats()

        # Active run (None when in menus)
        self.run: Optional[RunState] = None

        # Lazy-load screens so we don't have circular imports at module load.
        from ui.screens import (
            TitleScreen, BlindSelectScreen, PlayScreen, ShopScreen,
            GameOverScreen, WinScreen, StatsScreen, RoundResultScreen,
        )
        self.screen_classes = {
            "title":  TitleScreen,
            "blind":  BlindSelectScreen,
            "play":   PlayScreen,
            "shop":   ShopScreen,
            "result": RoundResultScreen,
            "over":   GameOverScreen,
            "win":    WinScreen,
            "stats":  StatsScreen,
        }
        self.current = None

        # Asset cache (shared)
        from ui.assets import AssetCache
        self.assets = AssetCache()

        # Audio: top-level coordinator owns music + SFX. `self.sounds` is
        # kept as a backwards-compat alias — existing `game.sounds.play(name)`
        # calls now route through the new SFXManager with extended library.
        from ui.audio_manager import AudioManager
        self.audio = AudioManager()
        self.sounds = self.audio.sfx

        # Switch to title last so the screen's __init__ can apply music
        # intensity once audio is initialised.
        self.switch_to("title")

    # ----- Navigation ----- #
    def switch_to(self, name: str, **kwargs) -> None:
        cls = self.screen_classes[name]
        self.current = cls(self, **kwargs)

    def quit(self) -> None:
        self.should_quit = True

    # ----- Pass-through to active screen ----- #
    def handle_events(self, events) -> None:
        if self.current is not None:
            self.current.handle_events(events)

    def update(self, dt: float) -> None:
        # Audio update first — music layer volumes lerp on a frame-rate-
        # independent clock so we want them updated even if the screen lags.
        if hasattr(self, "audio"):
            self.audio.update(dt)
        if self.current is not None:
            self.current.update(dt)

    def draw(self) -> None:
        if self.current is not None:
            self.current.draw(self.screen)

    # ----- Run lifecycle helpers ----- #
    def start_new_run(self) -> None:
        self.run = RunState()
        clear_run()
        self.stats["runs_played"] = self.stats.get("runs_played", 0) + 1
        save_stats(self.stats)
        self.switch_to("blind")

    def continue_run(self) -> bool:
        data = load_run()
        if not data:
            return False
        self.run = RunState.from_dict(data)
        self.switch_to("blind")
        return True

    def save_current_run(self) -> None:
        if self.run and not self.run.completed:
            save_run(self.run.to_dict())

    def end_run(self, won: bool) -> None:
        """Called when the run ends. Updates stats and unlocks."""
        if self.run is None:
            return
        if won:
            self.stats["wins"] = self.stats.get("wins", 0) + 1
            self._maybe_unlock_jokers()
        self.stats["best_ante"] = max(self.stats.get("best_ante", 1), self.run.ante)
        self.stats["highest_score"] = max(self.stats.get("highest_score", 0), self.run.best_score_this_run)
        save_stats(self.stats)
        clear_run()
        self.run = None

    def _maybe_unlock_jokers(self) -> None:
        """Unlock the next locked joker every time the player wins."""
        unlocked = self.stats.setdefault("unlocked_jokers", [])
        locked = [j for j in ALL_JOKER_IDS if j not in unlocked]
        if locked:
            unlocked.append(locked[0])
