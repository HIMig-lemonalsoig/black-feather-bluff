"""
Save / load utilities. JSON on disk under save/.

Two files:
  - savegame.json  -> in-progress run (deleted on game over / win)
  - stats.json     -> persistent meta data (unlocks, best run, etc.)
"""

import json
import os
from typing import Dict, Any, Optional

from game.constants import SAVE_FILE, STATS_FILE, SAVE_DIR
from game.jokers import STARTING_UNLOCKS


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _ensure_dir():
    os.makedirs(SAVE_DIR, exist_ok=True)


def _read_json(path: str) -> Optional[Dict[str, Any]]:
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def _write_json(path: str, data: Dict[str, Any]) -> None:
    _ensure_dir()
    # Write to a temp file then rename to avoid corrupting on crash mid-write.
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


# --------------------------------------------------------------------------- #
# Run save (current in-progress run)
# --------------------------------------------------------------------------- #
def save_run(run_dict: Dict[str, Any]) -> None:
    _write_json(SAVE_FILE, run_dict)


def load_run() -> Optional[Dict[str, Any]]:
    return _read_json(SAVE_FILE)


def clear_run() -> None:
    if os.path.exists(SAVE_FILE):
        try:
            os.remove(SAVE_FILE)
        except OSError:
            pass


# --------------------------------------------------------------------------- #
# Stats (persistent meta)
# --------------------------------------------------------------------------- #
DEFAULT_STATS = {
    "best_ante": 1,
    "highest_score": 0,
    "wins": 0,
    "runs_played": 0,
    "unlocked_jokers": list(STARTING_UNLOCKS),
    # UI preference — last sort applied to the hand. Persists across runs and
    # sessions. 'rank' | 'suit'. Defaults to rank.
    "sort_mode": "rank",
}


def load_stats() -> Dict[str, Any]:
    data = _read_json(STATS_FILE)
    if not data:
        data = dict(DEFAULT_STATS)
        data["unlocked_jokers"] = list(DEFAULT_STATS["unlocked_jokers"])
        return data
    # Backfill any missing fields from defaults (forward-compat).
    for k, v in DEFAULT_STATS.items():
        data.setdefault(k, v if not isinstance(v, list) else list(v))
    return data


def save_stats(stats: Dict[str, Any]) -> None:
    _write_json(STATS_FILE, stats)
