"""
Blind progression and boss modifiers.

A blind is a single fight: face a score target, beat it before running out of
hands. Bosses additionally apply a rule modifier ("no face cards", "halved
mult", etc.) that bites into the player's strategy.
"""

import random
from typing import List, Optional

from game.constants import (
    ANTE_BASE_REQUIREMENTS, SMALL_BLIND_MULT, BIG_BLIND_MULT, BOSS_BLIND_MULT,
    BLIND_BASE_REWARD, SUITS, MAX_ANTE,
)


# --------------------------------------------------------------------------- #
# Boss modifiers
# --------------------------------------------------------------------------- #
class BossModifier:
    """Base class. Bosses tweak the rules of a single round."""
    boss_id: str = "base"
    name: str = "Boss"
    description: str = "No rule change."

    def __init__(self):
        self.data = {}

    def filter_scoring(self, scoring_cards):
        """Optionally remove scoring cards (e.g. no face cards)."""
        return scoring_cards

    def filter_playable(self, cards):
        """Cards that the player is forbidden from playing (None = all allowed)."""
        return []

    def modify_final(self, ctx):
        """Apply a multiplier/chip tweak at the very end of scoring."""
        pass

    def hand_limit_delta(self) -> int:
        return 0

    def discard_limit_delta(self) -> int:
        return 0


class NoFaceCards(BossModifier):
    boss_id = "no_face"
    name = "THE STARLING"
    description = "Face cards (J, Q, K) do not score this round."

    def filter_scoring(self, scoring_cards):
        return [c for c in scoring_cards if not c.is_face]


class HalvedMult(BossModifier):
    boss_id = "halved"
    name = "THE COWBIRD"
    description = "Your final multiplier is halved this round."

    def modify_final(self, ctx):
        ctx.mult *= 0.5


class LimitedDiscards(BossModifier):
    boss_id = "no_discards"
    name = "THE MAGPIE"
    description = "You have ZERO discards this round."

    def discard_limit_delta(self) -> int:
        return -99   # clamped to >= 0 at use site


class SuitLock(BossModifier):
    boss_id = "suit_lock"
    name = "THE BLACKBIRD"
    description = "Only one suit scores. The locked suit changes each run."

    def __init__(self):
        super().__init__()
        # locked suit picked when boss is instantiated (per round)
        self.data["suit"] = random.choice(SUITS)
        self.description = f"Only {self.data['suit'].title()} cards score this round."

    def filter_scoring(self, scoring_cards):
        s = self.data["suit"]
        return [c for c in scoring_cards if c.suit == s]


class HighRollerOnly(BossModifier):
    boss_id = "high_only"
    name = "THE HARRIER"
    description = "Only High Cards (10, J, Q, K, A) score this round."

    def filter_scoring(self, scoring_cards):
        return [c for c in scoring_cards if c.is_high]


class FewerHands(BossModifier):
    boss_id = "fewer_hands"
    name = "THE NIGHTJAR"
    description = "You have 1 fewer hand this round."

    def hand_limit_delta(self) -> int:
        return -1


BOSS_MODIFIERS = [
    NoFaceCards, HalvedMult, LimitedDiscards, SuitLock, HighRollerOnly, FewerHands,
]


def random_boss(rng: random.Random) -> BossModifier:
    cls = rng.choice(BOSS_MODIFIERS)
    return cls()


# --------------------------------------------------------------------------- #
# Blind data
# --------------------------------------------------------------------------- #
class Blind:
    """A single blind fight: small / big / boss within a given ante."""

    def __init__(self, ante: int, kind: str, boss: Optional[BossModifier] = None):
        self.ante = ante
        self.kind = kind          # 'small' | 'big' | 'boss'
        self.boss = boss          # only set for boss blinds
        self.score_target = self._compute_target()
        self.reward = BLIND_BASE_REWARD[kind] + ante - 1  # scales modestly with ante

    def _compute_target(self) -> int:
        # Clamp ante to table; extrapolate after MAX_ANTE for fun.
        idx = min(self.ante - 1, len(ANTE_BASE_REQUIREMENTS) - 1)
        base = ANTE_BASE_REQUIREMENTS[idx]
        if self.ante > len(ANTE_BASE_REQUIREMENTS):
            base = int(base * (2 ** (self.ante - len(ANTE_BASE_REQUIREMENTS))))
        mult = {"small": SMALL_BLIND_MULT, "big": BIG_BLIND_MULT, "boss": BOSS_BLIND_MULT}[self.kind]
        return int(base * mult)

    @property
    def title(self) -> str:
        if self.kind == "boss" and self.boss:
            return self.boss.name
        return {"small": "SMALL BLIND", "big": "BIG BLIND", "boss": "BOSS BLIND"}[self.kind]

    @property
    def subtitle(self) -> str:
        if self.kind == "boss" and self.boss:
            return self.boss.description
        if self.kind == "small":
            return "A warm-up. The dealer's barely paying attention."
        if self.kind == "big":
            return "Stakes climb. The crowd leans in."
        return "Boss"


def make_blind(ante: int, kind: str, rng: random.Random) -> Blind:
    boss = random_boss(rng) if kind == "boss" else None
    return Blind(ante, kind, boss)
