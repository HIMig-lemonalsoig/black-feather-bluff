#!/usr/bin/env python3
"""
BLACKFEATHER BLUFF - entry point.

A noir casino roguelike inspired by Balatro, themed around bird-coded jokers.

Run natively:

    python main.py

Build for the web (any browser, including Chromebooks):

    pip install pygbag
    pygbag main.py
    # then upload the contents of build/web/ to GitHub Pages or itch.io

The main loop is async + awaits asyncio.sleep(0) each frame so pygbag's
WASM runtime can yield control back to the browser. The same code runs
natively on Python — asyncio.run() ignores the cooperative yield when not
in a browser context.
"""

import asyncio
import os
import sys

# Allow `python main.py` to find the game/ and ui/ packages even when launched
# from a different working directory.
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import pygame

from game.constants import WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, FPS
from game.state import Game
from ui.assets import ensure_assets


async def main() -> int:
    # Smaller mixer buffer = lower audio latency for clicky SFX.
    pygame.mixer.pre_init(22050, -16, 2, 512)
    pygame.init()

    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption(WINDOW_TITLE)

    # Make sure the save/ and assets/ directories exist before the Game tries to
    # write to them. (On the web build, this still works — pygbag mounts a
    # virtual filesystem and persists to IndexedDB.)
    ensure_assets()

    clock = pygame.time.Clock()
    game = Game(screen)

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        events = pygame.event.get()

        # Always honour quit events
        for event in events:
            if event.type == pygame.QUIT:
                running = False
                break

        if not running:
            break

        # Drive the active screen
        game.handle_events(events)
        game.update(dt)
        game.draw()
        pygame.display.flip()

        if game.should_quit:
            running = False

        # Cooperative yield: required for pygbag/WASM, no-op overhead natively.
        await asyncio.sleep(0)

    # Best-effort: persist any in-progress run so the player can continue later.
    try:
        game.save_current_run()
    except Exception:
        pass

    pygame.quit()
    return 0


# Run main unconditionally. We deliberately don't guard this with
# `if __name__ == "__main__":` because in pygbag's WASM runtime the script
# is executed in a context where __name__ is something like 'builtins',
# not '__main__', so the guard would silently skip the entire game loop
# (leaving the canvas grey and the tab title stuck at "idle").
# Native Python doesn't care — running main.py runs the loop either way.
asyncio.run(main())
