"""
Card-drawing pipeline.

Pulled out of screens.py so the rendering details for a single playing card
live in one place. The PlayScreen owns layout (where each card goes); this
module owns *how* a card looks once you have a Card object with all its
animation state filled in.

Adds the Balatro-style "mouse-tilt": a hovered card subtly rotates toward
the cursor so the interaction feels reactive.
"""

import math

import pygame

from game.constants import CARD_WIDTH, CARD_HEIGHT
from game.modifiers import CATEGORY_COLORS
from ui import colors as C
from ui.animations import card_display_transform
from ui.assets import render_text


def compute_hover_tilt(card_center, mouse_pos, max_deg: float = 9.0) -> float:
    """
    Returns the target tilt angle (degrees) when this card is hovered.

    Mapping: horizontal distance from the card center to the mouse,
    clamped and scaled. Vertical distance damps the magnitude — cards
    only tilt strongly when the cursor is at a similar height.
    """
    cx, cy = card_center
    dx = mouse_pos[0] - cx
    dy = mouse_pos[1] - cy
    # Soften by vertical distance — far above/below doesn't tilt much
    vert_damp = max(0.0, 1.0 - abs(dy) / 80.0)
    raw = (dx / 6.0) * vert_damp
    return max(-max_deg, min(max_deg, raw))


# --------------------------------------------------------------------------- #
# Halo shaping per suit (matches SUIT_PALETTES entries)
# --------------------------------------------------------------------------- #
def _draw_suit_halo(surface, rect, suit, alpha: int = 200) -> None:
    pal = C.SUIT_PALETTES[suit]
    halo_pad = 10
    halo = pygame.Surface((rect.width + halo_pad * 2,
                           rect.height + halo_pad * 2), pygame.SRCALPHA)
    pygame.draw.rect(halo, (*pal['glow'], alpha), halo.get_rect(),
                     pal['halo_thickness'], border_radius=pal['halo_radius'])
    # Spades: add a dark inner ring for the "sharp dark edge" accent.
    if suit == 'spades':
        pygame.draw.rect(halo, (40, 40, 60, 220),
                         halo.get_rect().inflate(-6, -6),
                         2, border_radius=max(2, pal['halo_radius'] - 2))
    surface.blit(halo, (rect.x - halo_pad, rect.y - halo_pad))


# --------------------------------------------------------------------------- #
# Public draw entry
# --------------------------------------------------------------------------- #
def draw_card(surface, card, assets, selected: bool = False) -> None:
    """
    Draw a single Card with all its layered transforms and effects.

    Order of layers (back-to-front):
      1. Suit-colored selection halo (if selected)
      2. Soft gold hover glow (if hover_t > 0)
      3. Yellow scoring pulse (if pulse_t < 1)
      4. The card sprite itself, transformed with rotation+scale
      5. Premium gold inner-highlight overlay
    """
    img = assets.get_card(card.rank, card.suit)
    scale, offset_y, rotation = card_display_transform(card)

    # Apply transform only when needed; otherwise reuse the cached surface.
    if scale != 1.0 or rotation != 0.0:
        img = pygame.transform.rotozoom(img, -rotation, scale)

    if card.fade_t > 0:
        alpha = int(255 * (1.0 - card.fade_t))
        img = img.copy()
        img.set_alpha(alpha)

    cx = card.pos[0] + CARD_WIDTH / 2
    cy = card.pos[1] + CARD_HEIGHT / 2 + offset_y
    rect = img.get_rect(center=(int(cx), int(cy)))

    # 1. Selected halo (suit-themed)
    if selected:
        _draw_suit_halo(surface, rect, card.suit, alpha=210)

    # 2. Hover glow — warm gold (focus signal)
    if card.hover_t > 0.05:
        pad = 28
        glow = pygame.Surface((rect.width + pad * 2,
                               rect.height + pad * 2), pygame.SRCALPHA)
        # Layered glows for a richer falloff
        for i, layer in enumerate(((34, 14), (22, 24), (12, 40))):
            radius, alpha_mul = layer
            a = int(alpha_mul * card.hover_t)
            pygame.draw.rect(glow, (255, 215, 90, a), glow.get_rect(),
                             border_radius=radius + i * 2)
        surface.blit(glow, (rect.x - pad, rect.y - pad),
                     special_flags=pygame.BLEND_RGBA_ADD)

    # 3. Scoring pulse
    if card.pulse_t < 1.0:
        pulse_amt = math.sin(card.pulse_t * math.pi)
        pad = 32
        glow = pygame.Surface((rect.width + pad * 2,
                               rect.height + pad * 2), pygame.SRCALPHA)
        a = int(220 * pulse_amt)
        pygame.draw.rect(glow, (255, 220, 110, a), glow.get_rect(),
                         border_radius=20)
        surface.blit(glow, (rect.x - pad, rect.y - pad),
                     special_flags=pygame.BLEND_RGBA_ADD)

    # 4. Card sprite itself
    surface.blit(img, rect)

    # 5. Premium inner gold rim — very subtle, gives "expensive" feel.
    if scale > 0.95 and card.fade_t <= 0:
        rim = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        pygame.draw.rect(rim, (255, 215, 90, 18),
                         rim.get_rect().inflate(-4, -4),
                         1, border_radius=8)
        surface.blit(rim, rect.topleft)

    # 6. Modifier overlay (if any): tinted border + corner badge + faint wash.
    mod = getattr(card, "modifier", None)
    if mod is not None and card.fade_t <= 0:
        draw_card_modifier_overlay(surface, rect, mod)


def draw_card_modifier_overlay(surface, rect, modifier) -> None:
    """
    Render a modifier's visual identity on top of an already-drawn card.

    Three layers, kept subtle:
      1. A faint tint wash so the whole card reads as "different"
      2. A 2px colored border in the modifier's category color
      3. A small filled badge in the top-right corner carrying the glyph
    """
    col = CATEGORY_COLORS.get(getattr(modifier, "category", "material"), (212, 175, 55))

    # 1. Faint full-card tint
    tint = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.rect(tint, (*col, 26), tint.get_rect(), border_radius=8)
    surface.blit(tint, rect.topleft)

    # 2. Tinted border on top of the card's existing border
    pygame.draw.rect(surface, col, rect, 3, border_radius=10)

    # 3. Corner badge — square in the top-right with the modifier glyph
    badge_size = 22
    bx = rect.right - badge_size - 3
    by = rect.top + 3
    badge_rect = pygame.Rect(bx, by, badge_size, badge_size)
    pygame.draw.rect(surface, (10, 8, 14), badge_rect, border_radius=5)
    pygame.draw.rect(surface, col, badge_rect, 2, border_radius=5)
    glyph = render_text(getattr(modifier, "icon_glyph", "?"), 18, col, bold=True)
    surface.blit(glyph, glyph.get_rect(center=badge_rect.center))
