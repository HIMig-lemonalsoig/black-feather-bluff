"""
Compatibility shim + card-motion update loop.

The juicy bits live in the new modules:
  - ui/tweening.py          easing curves, NumberTween, Pulse
  - ui/particle_system.py   Particle and ParticleSystem
  - ui/animation_manager.py AnimationManager (shake, popups, particles)

This file just re-exports the symbols that screens.py and other callers used
before the polish pass, plus the per-card motion update logic — which is the
one piece tightly bound to the Card model and not the manager.
"""

import math
import random

import pygame

# Re-exports kept for backwards-compatibility with the original import paths.
from ui.tweening import Tween, lerp  # noqa: F401
from ui.animation_manager import AnimationManager, FloatingText  # noqa: F401

from game.constants import CARD_WIDTH, CARD_HEIGHT


# --------------------------------------------------------------------------- #
# Card motion update
# --------------------------------------------------------------------------- #
def update_card_motion(card, dt: float, snap_speed: float = 14.0,
                       hover_target: bool = False) -> None:
    """
    Update one card's position, rotation, scale, and lifecycle per frame.

    Cards expose a `motion_mode` string:
      - 'smooth' (default): exponential lerp toward `target`
      - 'arc':    parabolic Bezier from `arc_start` to `target` over `arc_duration`
      - 'fling':  free-fly with velocity + gravity, fades + spins (discard)

    Also honours `card.deal_delay` (seconds) before the card starts moving —
    used for staggered deal animations.

    `hover_target` toggles a hover lift/scale that the card animates toward
    independently of its motion mode.
    """
    # Stagger delay — the card holds still until its delay elapses.
    if getattr(card, "deal_delay", 0.0) > 0.0:
        card.deal_delay = max(0.0, card.deal_delay - dt)
        # Still tick hover/pulse decays so a hovered hidden card doesn't snap.
        target_hover = 1.0 if hover_target else 0.0
        k = 1.0 - math.exp(-18.0 * dt)
        card.hover_t += (target_hover - card.hover_t) * k
        if getattr(card, "pulse_t", 1.0) < 1.0:
            card.pulse_t = min(1.0, card.pulse_t + dt / max(card.pulse_duration, 0.001))
        return

    mode = getattr(card, "motion_mode", "smooth")

    # ----- Position update by mode ----- #
    if mode == "arc":
        # Drive arc_t with a fixed duration.
        card.arc_t = min(1.0, card.arc_t + dt / max(card.arc_duration, 0.0001))
        t = _ease_out_cubic(card.arc_t)
        sx, sy = card.arc_start
        ex, ey = card.target
        # Peak rises above the midpoint by a tuned amount.
        peak_y = min(sy, ey) - 110
        mx = (sx + ex) * 0.5
        # Quadratic Bezier through (sx,sy), (mx,peak_y), (ex,ey)
        omt = 1 - t
        nx = omt * omt * sx + 2 * omt * t * mx + t * t * ex
        ny = omt * omt * sy + 2 * omt * t * peak_y + t * t * ey
        card.pos = (nx, ny)
        # Slight tilt while traveling
        card.rotation = math.sin(card.arc_t * math.pi) * 8.0
        if card.arc_t >= 1.0:
            card.motion_mode = "smooth"
            card.rotation = 0.0

    elif mode == "fling":
        # Velocity + gravity + spin + fade.
        vx, vy = card.velocity
        x, y = card.pos
        card.pos = (x + vx * dt, y + vy * dt)
        card.velocity = (vx, vy + 1200.0 * dt)
        card.rotation += card.spin * dt
        card.fade_t = min(1.0, card.fade_t + dt * 1.6)
        if card.fade_t >= 1.0:
            card.dead = True

    else:
        # Smooth — exponential damping to target
        tx, ty = card.target
        x, y = card.pos
        k = 1.0 - math.exp(-snap_speed * dt)
        card.pos = (x + (tx - x) * k, y + (ty - y) * k)
        # Hand auto-fan: gently relax toward target rotation
        target_rot = getattr(card, "fan_rotation", 0.0)
        card.rotation += (target_rot - card.rotation) * k

    # ----- Hover lift + scale (always active) ----- #
    target_hover = 1.0 if hover_target else 0.0
    k = 1.0 - math.exp(-18.0 * dt)
    card.hover_t += (target_hover - card.hover_t) * k

    # Pulse decays
    if getattr(card, "pulse_t", 1.0) < 1.0:
        card.pulse_t = min(1.0, card.pulse_t + dt / max(card.pulse_duration, 0.001))

    # Glow decay (kept for backwards compat — pulse_t supersedes this)
    if card.glow > 0:
        card.glow = max(0.0, card.glow - dt * 1.6)


def _ease_out_cubic(t: float) -> float:
    return 1 - (1 - t) ** 3


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def card_display_transform(card):
    """
    Compute (display_scale, display_offset_y, display_rotation) including all
    layered effects (idle wobble, hover, hover-tilt, pulse, scoring lift,
    motion-mode-driven rotation).
    """
    import pygame
    scale = 1.0
    offset_y = 0.0
    rot = card.rotation

    # Idle wobble — the table is never quite still. Only applies when the card
    # is at rest in the hand (smooth motion mode, not pulsing or fading).
    pulse_t = getattr(card, "pulse_t", 1.0)
    motion_mode = getattr(card, "motion_mode", "smooth")
    fade_t = getattr(card, "fade_t", 0.0)
    in_hand = getattr(card, "in_hand", True)
    if motion_mode == "smooth" and pulse_t >= 1.0 and fade_t <= 0 and in_hand:
        t = pygame.time.get_ticks() / 1000.0
        # Different phase per card so the hand doesn't wobble in unison.
        phase = (hash((card.rank, card.suit)) & 0xff) * 0.025
        rot += math.sin(t * 1.4 + phase) * 0.7
        offset_y += math.sin(t * 1.0 + phase * 1.3) * 1.4

    # Mouse-follow tilt when hovered (added on top of motion rotation)
    if getattr(card, "hover_tilt", 0.0):
        rot += card.hover_tilt

    # Hover effect — lift + scale
    if card.hover_t > 0:
        scale += 0.10 * card.hover_t
        offset_y -= 16.0 * card.hover_t

    # Pulse effect (set pulse_t < 1 to start a pulse) — also lifts during a pulse
    # so a scoring card visibly rises out of the hand row.
    if pulse_t < 1.0:
        pulse_amt = math.sin(pulse_t * math.pi)
        scale += 0.28 * pulse_amt
        offset_y -= 28.0 * pulse_amt   # Balatro-style scoring lift

    return scale, offset_y, rot
