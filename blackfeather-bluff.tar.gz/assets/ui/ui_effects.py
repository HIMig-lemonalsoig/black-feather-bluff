"""
Premium-feel post-processing effects and atmosphere layers.

Everything here is built to be cheap-per-frame: overlays are baked once into
cached Surfaces and blitted, not redrawn pixel-by-pixel. The goal is
Balatro-level mood without GPU shaders.

Effects:
  * VignetteOverlay     dark inner-corner falloff
  * ScanlineOverlay     subtle CRT scanlines (toggleable)
  * SpotLight           single radial light for the casino-table feel
  * GoldRim             warm bloomy ring near the top edge
  * AtmosphereLayer     continuous ember + dust particles drifting upward
  * NoiseGrain          baked film-grain dot pattern, blitted every frame
  * apply_chromatic_aberration  rare, expensive — used for big-hit reveals
"""

import math
import random
from typing import List, Optional, Tuple

import pygame

from ui import colors as C


# --------------------------------------------------------------------------- #
# Vignette
# --------------------------------------------------------------------------- #
class VignetteOverlay:
    """Soft dark vignette — corners get darker, center stays clear."""

    def __init__(self, width: int, height: int,
                 intensity: float = 0.85,
                 inner_ratio: float = 0.55):
        """
        intensity: 0..1 darkness at the corners
        inner_ratio: 0..1 portion of the radius that stays untouched
        """
        self.surface = self._build(width, height, intensity, inner_ratio)

    @staticmethod
    def _build(w, h, intensity, inner_ratio) -> pygame.Surface:
        # Build the vignette as concentric rounded rectangles fading inward.
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        max_alpha = int(255 * intensity)
        # 20 layered translucent rects from outside in
        steps = 22
        for i in range(steps):
            t = i / (steps - 1)
            inset = int(t * min(w, h) * 0.5)
            if inset >= min(w, h) // 2:
                break
            # Falloff curve — quadratic in (1-t)
            falloff = (1 - t) ** 2
            if t < inner_ratio:
                # Closer to edge -> darker. Skip extremely-low alphas.
                continue
            alpha = int(max_alpha * falloff * 0.10)
            if alpha <= 0:
                continue
            rect = pygame.Rect(inset, inset, w - inset * 2, h - inset * 2)
            pygame.draw.rect(s, (0, 0, 0, alpha), rect, border_radius=20)
        # Final outer "fill" frame to darken the absolute corners.
        edge = pygame.Surface((w, h), pygame.SRCALPHA)
        edge.fill((0, 0, 0, max_alpha))
        pygame.draw.rect(edge, (0, 0, 0, 0),
                         pygame.Rect(40, 40, w - 80, h - 80),
                         border_radius=40)
        s.blit(edge, (0, 0))
        return s

    def draw(self, surface) -> None:
        surface.blit(self.surface, (0, 0))


# --------------------------------------------------------------------------- #
# Scanlines (subtle CRT)
# --------------------------------------------------------------------------- #
class ScanlineOverlay:
    """Faint horizontal dim-lines. Toggle with `enabled`."""

    def __init__(self, width: int, height: int,
                 alpha: int = 22, gap: int = 3,
                 enabled: bool = True):
        self.enabled = enabled
        self.surface = self._build(width, height, alpha, gap)

    @staticmethod
    def _build(w, h, alpha, gap) -> pygame.Surface:
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        for y in range(0, h, gap):
            pygame.draw.line(s, (0, 0, 0, alpha), (0, y), (w, y))
        return s

    def draw(self, surface) -> None:
        if self.enabled:
            surface.blit(self.surface, (0, 0))


# --------------------------------------------------------------------------- #
# Spot light
# --------------------------------------------------------------------------- #
class SpotLight:
    """
    Warm pool of light over the table.

    Implementation chosen for cross-platform reliability:
      * Non-SRCALPHA RGB surface (24-bit), with black as the colorkey for
        transparency. Avoids any per-pixel alpha quirks on macOS pygame builds.
      * Soft gradient produced by stacking concentric circles painted in
        progressively brighter shades of the spotlight color (no smoothscale,
        no BLEND_RGBA_ADD).
      * Overall opacity controlled by `set_alpha` on the whole surface — the
        oldest, most widely supported pygame opacity API.

    Result: a subtle warm disc, hard-edged but at low enough total opacity
    (around 10%) that the edge reads as a gentle vignette rather than a circle.
    """

    def __init__(self, width: int, height: int,
                 cx: int, cy: int,
                 radius: int,
                 color=(255, 200, 110),
                 intensity: int = 32,
                 pulse_amount: float = 0.10):
        self.cx, self.cy = cx, cy
        self.radius = radius
        self.color = color
        self.intensity = intensity   # 0-255, peak overall opacity
        self.pulse_amount = pulse_amount
        self.t = 0.0
        self.surface = self._build(width, height)

    def _build(self, w, h) -> pygame.Surface:
        # 24-bit RGB surface (no per-pixel alpha — set_alpha controls opacity)
        s = pygame.Surface((w, h))
        s.fill((0, 0, 0))
        s.set_colorkey((0, 0, 0))
        # Concentric circles, outer (dim) to inner (bright). Each inner ring
        # overdraws the previous, giving a smooth-looking gradient with only
        # ~20 draws.
        rings = 22
        for i in range(rings):
            r = int(self.radius * (1 - i / rings))
            if r <= 0:
                break
            t = (i + 1) / rings    # 1/rings → 1.0 as we go inward
            col = (
                max(2, int(self.color[0] * t)),
                max(2, int(self.color[1] * t)),
                max(2, int(self.color[2] * t)),
            )
            pygame.draw.circle(s, col, (self.cx, self.cy), r)
        s.set_alpha(self.intensity)
        return s

    def update(self, dt: float) -> None:
        self.t += dt

    def draw(self, surface) -> None:
        # Gentle pulse around the configured intensity.
        pulse = 1.0 + math.sin(self.t * 1.4) * self.pulse_amount
        a = max(0, min(255, int(self.intensity * pulse)))
        self.surface.set_alpha(a)
        surface.blit(self.surface, (0, 0))


# --------------------------------------------------------------------------- #
# Gold rim — warm bloomy halo at the top edge
# --------------------------------------------------------------------------- #
class GoldRim:
    """
    Faint warm tint at the very top of the screen — like a casino's overhead
    lighting bleeding into the frame. Kept subtle on purpose; if you can
    notice it directly it's already too bright.
    """

    def __init__(self, width: int, height: int, intensity: int = 14):
        self.surface = self._build(width, height, intensity)

    @staticmethod
    def _build(w, h, intensity) -> pygame.Surface:
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        band = h // 6
        for y in range(band):
            t = y / max(1, band - 1)
            a = int(intensity * (1.0 - t) ** 3)
            pygame.draw.line(s, (255, 200, 100, a), (0, y), (w, y))
        return s

    def draw(self, surface) -> None:
        # Normal blit — adding made it blow out at any meaningful intensity.
        surface.blit(self.surface, (0, 0))


# --------------------------------------------------------------------------- #
# Noise grain — film-stock dots blitted every frame
# --------------------------------------------------------------------------- #
class NoiseGrain:
    """Pre-baked random dot pattern. Cheap to blit and keeps screen lively."""

    def __init__(self, width: int, height: int, density: float = 0.012,
                 alpha_range=(8, 22)):
        self.surface = self._build(width, height, density, alpha_range)

    @staticmethod
    def _build(w, h, density, alpha_range) -> pygame.Surface:
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        count = int(w * h * density)
        rng = random.Random(0xfeed)
        for _ in range(count):
            x = rng.randint(0, w - 1)
            y = rng.randint(0, h - 1)
            a = rng.randint(*alpha_range)
            tone = rng.choice([(240, 230, 200), (180, 60, 80), (90, 60, 30)])
            s.set_at((x, y), (*tone, a))
        return s

    def draw(self, surface) -> None:
        surface.blit(self.surface, (0, 0))


# --------------------------------------------------------------------------- #
# Atmosphere layer — continuously-spawning embers and dust motes
# --------------------------------------------------------------------------- #
class _AmbientParticle:
    """Lighter than a Particle — purpose-built for ambient atmosphere."""
    __slots__ = ("x", "y", "vx", "vy", "life", "max_life", "color", "size", "kind")

    def __init__(self, x, y, vx, vy, life, color, size, kind="ember"):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.life = life
        self.max_life = life
        self.color = color
        self.size = size
        self.kind = kind

    def update(self, dt):
        self.life -= dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        # Slight wobble for embers
        if self.kind == "ember":
            self.vx += math.sin(self.life * 4 + self.y * 0.01) * 8 * dt

    def alive(self) -> bool:
        return self.life > 0.0


class AtmosphereLayer:
    """Manages continuous low-density particles drifting across the screen."""

    EMBER_RATE = 6.0   # particles per second
    DUST_RATE  = 3.5
    MAX_PARTICLES = 90

    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.particles: List[_AmbientParticle] = []
        self._t = 0.0
        self._ember_accum = 0.0
        self._dust_accum = 0.0

    def update(self, dt: float) -> None:
        self._t += dt
        self._ember_accum += dt * self.EMBER_RATE
        self._dust_accum += dt * self.DUST_RATE
        # Spawn embers (rise from bottom)
        while self._ember_accum >= 1.0:
            self._ember_accum -= 1.0
            self._spawn_ember()
        # Spawn dust motes (drift across)
        while self._dust_accum >= 1.0:
            self._dust_accum -= 1.0
            self._spawn_dust()
        # Cap total
        if len(self.particles) > self.MAX_PARTICLES:
            self.particles = self.particles[-self.MAX_PARTICLES:]
        # Update + filter
        for p in self.particles:
            p.update(dt)
        self.particles = [p for p in self.particles if p.alive()]

    def _spawn_ember(self) -> None:
        x = random.uniform(0, self.width)
        y = self.height + 10
        vx = random.uniform(-12, 12)
        vy = random.uniform(-46, -22)
        life = random.uniform(4.5, 8.0)
        color = random.choice([
            (255, 170, 60),
            (255, 140, 50),
            (255, 200, 90),
        ])
        size = random.uniform(1.2, 2.6)
        self.particles.append(_AmbientParticle(x, y, vx, vy, life, color, size, "ember"))

    def _spawn_dust(self) -> None:
        x = -10
        y = random.uniform(0, self.height)
        vx = random.uniform(10, 28)
        vy = random.uniform(-4, 4)
        life = random.uniform(20.0, 30.0)
        color = random.choice([
            (200, 180, 130),
            (180, 160, 110),
            (220, 200, 150),
        ])
        size = random.uniform(0.8, 1.6)
        self.particles.append(_AmbientParticle(x, y, vx, vy, life, color, size, "dust"))

    def draw(self, surface) -> None:
        for p in self.particles:
            # Alpha fades at start and end of life
            t = 1.0 - (p.life / p.max_life)
            if t < 0.15:
                a = t / 0.15
            elif t > 0.85:
                a = (1.0 - t) / 0.15
            else:
                a = 1.0
            if p.kind == "ember":
                alpha = int(220 * a)
                size = max(1, int(p.size * 2))
                # Glowing ember = halo + core
                halo = pygame.Surface((size * 4, size * 4), pygame.SRCALPHA)
                pygame.draw.circle(halo, (*p.color, int(alpha * 0.18)),
                                   (size * 2, size * 2), size * 2)
                pygame.draw.circle(halo, (*p.color, alpha),
                                   (size * 2, size * 2), size)
                surface.blit(halo, (int(p.x - size * 2), int(p.y - size * 2)),
                             special_flags=pygame.BLEND_RGBA_ADD)
            else:  # dust
                alpha = int(80 * a)
                size = max(1, int(p.size))
                pygame.draw.circle(surface, (*p.color, alpha),
                                   (int(p.x), int(p.y)), size)


# --------------------------------------------------------------------------- #
# Cheap chromatic-aberration helper
# --------------------------------------------------------------------------- #
def apply_chromatic_aberration(surface: pygame.Surface, amount: int = 2) -> None:
    """
    In-place subtle channel split. Use sparingly — copies the scene twice.

    Trick: blit a red-channel-only copy slightly left and a blue-channel-only
    copy slightly right, both with low alpha and BLEND_ADD. Effect is most
    visible near high-contrast edges.
    """
    w, h = surface.get_size()
    base = surface.copy()
    red = base.copy()
    red.fill((255, 0, 0), special_flags=pygame.BLEND_RGB_MULT)
    red.set_alpha(80)
    blue = base.copy()
    blue.fill((0, 0, 255), special_flags=pygame.BLEND_RGB_MULT)
    blue.set_alpha(80)
    surface.blit(red, (-amount, 0), special_flags=pygame.BLEND_RGBA_ADD)
    surface.blit(blue, (amount, 0), special_flags=pygame.BLEND_RGBA_ADD)


# --------------------------------------------------------------------------- #
# Bloom-ish glow ring
# --------------------------------------------------------------------------- #
def draw_glow_ring(surface, center, radius: int, color, alpha: int = 80,
                   thickness: int = 8) -> None:
    """Soft outer-glow ring drawn with stacked translucent circles."""
    cx, cy = center
    size = (radius + thickness + 4) * 2
    s = pygame.Surface((size, size), pygame.SRCALPHA)
    sc = size // 2
    for i in range(thickness, 0, -1):
        a = int(alpha * (i / thickness) ** 2)
        pygame.draw.circle(s, (*color, a), (sc, sc), radius + i, 1)
    surface.blit(s, (cx - sc, cy - sc), special_flags=pygame.BLEND_RGBA_ADD)


# --------------------------------------------------------------------------- #
# Flash overlay — full-screen white flash that fades, for hit feedback
# --------------------------------------------------------------------------- #
class HitFlash:
    """Brief warm flash that decays. Trigger with .flash(intensity).

    On big hits (intensity > 0.5) the flash decays slower so it reads as a
    proper "celebration" beat rather than a one-frame blip.
    """

    def __init__(self, width: int, height: int, color=(255, 215, 110)):
        self.surface = pygame.Surface((width, height))
        self.surface.fill(color)
        self.alpha = 0.0

    def flash(self, intensity: float = 0.4) -> None:
        self.alpha = max(self.alpha, intensity)

    def update(self, dt: float) -> None:
        if self.alpha > 0:
            # Larger flashes decay slower (more impactful celebration).
            decay = 2.4 if self.alpha > 0.5 else 3.2
            self.alpha = max(0.0, self.alpha - dt * decay)

    def draw(self, surface) -> None:
        if self.alpha > 0:
            a = int(255 * self.alpha)
            self.surface.set_alpha(a)
            surface.blit(self.surface, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
