"""
All in-game screens — title, stats, blind select, play, shop, win, over.

Each screen:
  * Owns an AnimationManager (tweens + popups + particles + screen shake).
  * Fades in over ~0.35s on enter.
  * Draws onto a 'scene' sub-surface that is then blitted at the shake offset
    onto the real display, giving a free post-process screen shake.

The PlayScreen is the heart of the game; it runs a step-based scoring
sequence with rolling counters, joker triggers, and reactive screen shake.
"""

import math
import random
from typing import List, Optional, Tuple

import pygame

from game.constants import (
    WINDOW_WIDTH, WINDOW_HEIGHT, CARD_WIDTH, CARD_HEIGHT, CARD_GAP, CARD_LIFT,
    HAND_SIZE, SELECT_MAX, HANDS_PER_ROUND, DISCARDS_PER_ROUND,
    HAND_BASE_SCORES, HAND_DISPLAY_NAMES, MAX_JOKERS, JOKER_WIDTH, JOKER_HEIGHT,
    MAX_ANTE,
)
from game.cards import Card
from game.poker import evaluate_hand, score_hand, hand_display_name, ScoreContext
from game.shop import Shop, BoosterPack
from game.jokers import ALL_JOKER_IDS, joker_def
from ui import colors as C
from ui.assets import render_text, get_font
from ui.widgets import (
    Button, draw_panel, draw_stat, draw_joker_slots, draw_tooltip,
    draw_score_readout, joker_slot_position,
)
from ui.animations import update_card_motion, card_display_transform
from ui.animation_manager import AnimationManager, FloatingText
from ui.tweening import NumberTween, Pulse, ease_out_back, ease_out_cubic, damp
from ui.card_renderer import draw_card, compute_hover_tilt, draw_card_modifier_overlay
from ui.shaders import build_default_pipeline, PostFXPipeline
from ui.ui_effects import AtmosphereLayer, HitFlash, SpotLight, apply_chromatic_aberration


# ============================================================================ #
# Base Screen — owns animation manager, scene surface, enter fade.
# ============================================================================ #
class Screen:
    """Base for every screen. Owns an animation manager and a fade-in timer."""

    ENTER_DURATION = 0.35

    # Override in subclasses to opt into the table-spotlight overlay.
    USE_SPOTLIGHT = False
    # Override to enable/disable scanlines per-screen (default on).
    SCANLINES = True
    # Adaptive-music intensity profile applied on screen entry.
    # 'silent' | 'low' | 'medium' | 'high'
    MUSIC_INTENSITY = "low"

    def __init__(self, game):
        self.game = game
        # Lerp music toward this screen's chosen intensity.
        if hasattr(game, "audio"):
            game.audio.set_intensity(self.MUSIC_INTENSITY)
        self.anim = AnimationManager()
        self.enter_t = 0.0
        # Scene surface so we can shake everything as a unit.
        # Scene surface: don't call .convert() — pygbag/WASM's SDL has been
        # known to convert into a pixel format that blits back to the
        # display as solid black. Plain Surface works on both native + web.
        self.scene = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        # Decorative drift for animated bg (cheap silhouettes behind everything)
        self._bg_t = 0.0
        self._bg_drifters = self._make_drifters()
        # Continuous atmosphere — embers + dust, drifting across the scene.
        self.atmosphere = AtmosphereLayer(WINDOW_WIDTH, WINDOW_HEIGHT)
        # Post-process pipeline — vignette, scanlines, grain, optional spotlight.
        self.postfx: PostFXPipeline = build_default_pipeline(
            WINDOW_WIDTH, WINDOW_HEIGHT,
            scanlines_enabled=self.SCANLINES,
            with_spotlight=self.USE_SPOTLIGHT,
        )
        # Full-screen hit flash for big moments (final score reveal, etc.)
        self.hit_flash = HitFlash(WINDOW_WIDTH, WINDOW_HEIGHT)
        # When set > 0, chromatic aberration is applied for one frame.
        self._aberration_pulse = 0

    # ----- Lifecycle ----- #
    def handle_events(self, events):
        pass

    def update(self, dt: float) -> None:
        self.anim.update(dt)
        if self.enter_t < 1.0:
            self.enter_t = min(1.0, self.enter_t + dt / self.ENTER_DURATION)
        self._bg_t += dt
        for d in self._bg_drifters:
            d["x"] += d["vx"] * dt
            d["y"] += d["vy"] * dt
            if d["x"] < -60:
                d["x"] = WINDOW_WIDTH + 60
                d["y"] = random.uniform(0, WINDOW_HEIGHT)
        self.atmosphere.update(dt)
        self.postfx.update(dt)
        self.hit_flash.update(dt)

    def draw(self, surface) -> None:
        """Subclasses override draw_scene; we apply shake + post-FX + fade here."""
        # 1) Render the scene into our private surface so we can shake it.
        self._draw_bg(self.scene)
        self.draw_scene(self.scene)
        # 2) Atmosphere — embers/dust on top of scene content but below post-FX.
        self.atmosphere.draw(self.scene)
        # 3) Particles + popups still belong above scene content too.
        self.anim.draw_particles(self.scene)
        self.anim.draw_popups(self.scene)
        # 4) Apply optional chromatic aberration when triggered.
        if self._aberration_pulse > 0:
            apply_chromatic_aberration(self.scene, amount=self._aberration_pulse)
            self._aberration_pulse = max(0, self._aberration_pulse - 1)
        # 5) Hit flash sits *under* the post-FX so vignette still frames it.
        self.hit_flash.draw(self.scene)
        # 6) Post-FX (spotlight, gold rim, scanlines, vignette, grain).
        self.postfx.draw(self.scene)
        # 7) Apply screen shake offset when blitting to the real display.
        ox, oy, _ = self.anim.shake.offset()
        surface.fill((0, 0, 0))
        surface.blit(self.scene, (int(ox), int(oy)))
        # 8) Enter fade — over everything, including post-FX.
        if self.enter_t < 1.0:
            overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            a = int(255 * (1.0 - self.enter_t) ** 2)
            overlay.fill((0, 0, 0, a))
            surface.blit(overlay, (0, 0))

    # Helpers for big-moment effects
    def trigger_hit_flash(self, intensity: float = 0.35) -> None:
        self.hit_flash.flash(intensity)

    def trigger_aberration(self, frames: int = 6) -> None:
        self._aberration_pulse = max(self._aberration_pulse, frames)

    def draw_scene(self, surface) -> None:
        """Subclasses implement this."""
        pass

    # ----- Background ----- #
    def _draw_bg(self, surface):
        surface.blit(self.game.assets.get_bg(WINDOW_WIDTH, WINDOW_HEIGHT), (0, 0))
        # Subtle vertical pulse
        pulse = 8 + math.sin(self._bg_t * 0.6) * 6
        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        pygame.draw.rect(overlay, (60, 8, 14, int(pulse)),
                         overlay.get_rect())
        surface.blit(overlay, (0, 0))
        # Drift silhouettes (feathers floating across the background)
        for d in self._bg_drifters:
            self._draw_drifter(surface, d)

    def _make_drifters(self):
        rng = random.Random(0xfeed)
        out = []
        for _ in range(7):
            out.append({
                "x": rng.uniform(0, WINDOW_WIDTH),
                "y": rng.uniform(0, WINDOW_HEIGHT),
                "vx": -rng.uniform(8, 22),
                "vy": rng.uniform(-4, 4),
                "size": rng.uniform(6, 12),
                "alpha": rng.randint(18, 36),
                "rot": rng.uniform(0, math.tau),
            })
        return out

    def _draw_drifter(self, surface, d):
        s = int(d["size"])
        surf = pygame.Surface((s * 4, s * 6), pygame.SRCALPHA)
        col = (40, 20, 28, d["alpha"])
        pts_local = [(0, -s * 2), (s, 0), (0, s * 3), (-s, 0)]
        cos_r = math.cos(d["rot"])
        sin_r = math.sin(d["rot"])
        rotated = [
            (px * cos_r - py * sin_r + s * 2,
             px * sin_r + py * cos_r + s * 3)
            for px, py in pts_local
        ]
        pygame.draw.polygon(surf, col, rotated)
        surface.blit(surf, (int(d["x"] - s * 2), int(d["y"] - s * 3)))


# Card drawing now lives in ui/card_renderer.py — `draw_card` is imported above.

# ============================================================================ #
# Title screen
# ============================================================================ #
class TitleScreen(Screen):
    MUSIC_INTENSITY = "low"

    def __init__(self, game):
        super().__init__(game)
        self.buttons: List[Button] = []
        self._build_menu()
        self.t = 0.0

    def _build_menu(self):
        cx = WINDOW_WIDTH // 2
        y = 380
        gap = 60
        w, h = 280, 48
        self.buttons.append(Button(
            pygame.Rect(cx - w // 2, y, w, h),
            "NEW RUN", on_click=self._start_new_run, color_border=C.GOLD,
        ))
        y += gap
        has_save = self._has_save()
        self.buttons.append(Button(
            pygame.Rect(cx - w // 2, y, w, h),
            "CONTINUE", on_click=self._continue, disabled=not has_save,
        ))
        y += gap
        self.buttons.append(Button(
            pygame.Rect(cx - w // 2, y, w, h),
            "STATS", on_click=lambda: self.game.switch_to("stats"),
        ))
        y += gap
        self.buttons.append(Button(
            pygame.Rect(cx - w // 2, y, w, h),
            "QUIT", on_click=self.game.quit,
        ))

    def _has_save(self) -> bool:
        from game.save import load_run
        return load_run() is not None

    def _start_new_run(self):
        self.game.sounds.play("click")
        self.game.start_new_run()

    def _continue(self):
        self.game.sounds.play("click")
        self.game.continue_run()

    def handle_events(self, events):
        for e in events:
            for b in self.buttons:
                b.handle_event(e)

    def update(self, dt):
        super().update(dt)
        self.t += dt

    def draw_scene(self, surface):
        cx = WINDOW_WIDTH // 2

        # Layered crimson banner behind the title for dramatic framing.
        outer = pygame.Rect(0, 120, WINDOW_WIDTH, 170)
        inner = pygame.Rect(0, 130, WINDOW_WIDTH, 150)
        pygame.draw.rect(surface, (28, 6, 10), outer)
        pygame.draw.rect(surface, (52, 10, 18), inner)
        pygame.draw.line(surface, C.GOLD, (0, outer.top), (WINDOW_WIDTH, outer.top), 2)
        pygame.draw.line(surface, C.GOLD, (0, outer.bottom), (WINDOW_WIDTH, outer.bottom), 2)
        pygame.draw.line(surface, C.GOLD_DIM, (0, outer.top + 4),
                         (WINDOW_WIDTH, outer.top + 4), 1)
        pygame.draw.line(surface, C.GOLD_DIM, (0, outer.bottom - 4),
                         (WINDOW_WIDTH, outer.bottom - 4), 1)

        # Floating spade silhouettes flanking the title.
        spade_a = (cx - 360, 205)
        spade_b = (cx + 360, 205)
        from ui.assets import make_suit_surface
        sp = make_suit_surface('spades', 70, (180, 30, 38))
        sp.set_alpha(140)
        surface.blit(sp, sp.get_rect(center=spade_a))
        surface.blit(sp, sp.get_rect(center=spade_b))

        # Soft pulsing aura behind the title text — gentle, not saturating.
        pulse = (math.sin(self.t * 2.0) + 1) * 0.5
        aura_alpha = int(24 + 14 * pulse)
        aura = pygame.Surface((900, 200), pygame.SRCALPHA)
        for i in range(5, 0, -1):
            a = int(aura_alpha / i)
            pygame.draw.rect(aura, (200, 50, 60, a),
                             aura.get_rect().inflate(-i * 14, -i * 14),
                             border_radius=20)
        surface.blit(aura, aura.get_rect(center=(cx, 205)))

        # Title — layered shadows + scale pulse
        title_scale = 1.0 + math.sin(self.t * 1.6) * 0.012
        title_main = render_text("BLACKFEATHER BLUFF", 92, C.GOLD_BRIGHT, bold=True)
        w, h = title_main.get_size()
        title_main = pygame.transform.smoothscale(
            title_main, (int(w * title_scale), int(h * title_scale))
        )
        # Hard red shadow then soft black shadow under the gold.
        shadow_red = render_text("BLACKFEATHER BLUFF", 92, (110, 16, 22), bold=True)
        shadow_red = pygame.transform.smoothscale(
            shadow_red, (int(w * title_scale), int(h * title_scale))
        )
        shadow_dark = render_text("BLACKFEATHER BLUFF", 92, (0, 0, 0), bold=True)
        shadow_dark = pygame.transform.smoothscale(
            shadow_dark, (int(w * title_scale), int(h * title_scale))
        )
        title_y = 205
        surface.blit(shadow_dark, shadow_dark.get_rect(center=(cx + 6, title_y + 7)))
        surface.blit(shadow_red, shadow_red.get_rect(center=(cx + 3, title_y + 3)))
        surface.blit(title_main, title_main.get_rect(center=(cx, title_y)))

        # Subtitle (parchment-toned)
        sub = render_text("a noir bird-casino roguelike", 26, C.PARCHMENT, bold=True)
        sub_shadow = render_text("a noir bird-casino roguelike", 26, (0, 0, 0), bold=True)
        surface.blit(sub_shadow, sub_shadow.get_rect(center=(cx + 1, title_y + 73)))
        surface.blit(sub, sub.get_rect(center=(cx, title_y + 72)))

        # Buttons
        for b in self.buttons:
            b.draw(surface)

        # Pulsing hint footer
        hint_alpha = int(140 + math.sin(self.t * 3) * 80)
        hint = render_text("Click to play.   Esc quits anywhere.", 16, C.TEXT_FAINT)
        hint.set_alpha(hint_alpha)
        surface.blit(hint, hint.get_rect(center=(cx, WINDOW_HEIGHT - 28)))


# ============================================================================ #
# Stats screen
# ============================================================================ #
class StatsScreen(Screen):
    MUSIC_INTENSITY = "low"

    def __init__(self, game):
        super().__init__(game)
        self.back_btn = Button(
            pygame.Rect(40, WINDOW_HEIGHT - 70, 160, 44),
            "BACK", on_click=lambda: self.game.switch_to("title"),
        )

    def handle_events(self, events):
        for e in events:
            self.back_btn.handle_event(e)
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                self.game.switch_to("title")

    def draw_scene(self, surface):
        title = render_text("STATS", 56, C.GOLD, bold=True)
        surface.blit(title, title.get_rect(center=(WINDOW_WIDTH // 2, 60)))
        stats = self.game.stats
        panel = pygame.Rect(WINDOW_WIDTH // 2 - 250, 130, 500, 200)
        draw_panel(surface, panel, "RECORDS")
        y = panel.y + 40
        rows = [
            ("Best Ante Reached", str(stats.get("best_ante", 1))),
            ("Highest Single Hand", str(stats.get("highest_score", 0))),
            ("Total Wins", str(stats.get("wins", 0))),
            ("Runs Played", str(stats.get("runs_played", 0))),
        ]
        for label, value in rows:
            draw_stat(surface, (panel.x + 20, y), label, value, size=22)
            y += 30

        unlocked_panel = pygame.Rect(WINDOW_WIDTH // 2 - 400, 350, 800, 240)
        draw_panel(surface, unlocked_panel, "JOKER COLLECTION")
        unlocked = set(stats.get("unlocked_jokers", []))
        cell_w, cell_h = JOKER_WIDTH + 8, JOKER_HEIGHT + 30
        per_row = (unlocked_panel.width - 40) // cell_w
        start_x = unlocked_panel.x + 20
        start_y = unlocked_panel.y + 40
        for i, jid in enumerate(ALL_JOKER_IDS):
            r, c = i // per_row, i % per_row
            x = start_x + c * cell_w
            y = start_y + r * cell_h
            icon = self.game.assets.get_joker(jid)
            if jid in unlocked:
                surface.blit(icon, (x, y))
            else:
                grey = icon.copy()
                dark = pygame.Surface(grey.get_size(), pygame.SRCALPHA)
                dark.fill((10, 6, 10, 200))
                grey.blit(dark, (0, 0))
                surface.blit(grey, (x, y))
                q = render_text("?", 40, C.TEXT_FAINT, bold=True)
                surface.blit(q, q.get_rect(center=(x + JOKER_WIDTH // 2, y + JOKER_HEIGHT // 2)))
        self.back_btn.draw(surface)


# ============================================================================ #
# Blind select screen
# ============================================================================ #
class BlindSelectScreen(Screen):
    MUSIC_INTENSITY = "medium"

    def __init__(self, game):
        super().__init__(game)
        run = self.game.run
        self.blind = run.make_current_blind()
        run.current_blind = self.blind

        self.begin_btn = Button(
            pygame.Rect(WINDOW_WIDTH // 2 - 140, WINDOW_HEIGHT - 110, 280, 56),
            "BEGIN BLIND", on_click=self._begin, font_size=28,
            color_border=C.GOLD,
        )
        self.quit_btn = Button(
            pygame.Rect(WINDOW_WIDTH - 200, 20, 160, 36),
            "GIVE UP", on_click=self._give_up, font_size=18,
        )
        if self.blind.kind == "boss":
            # Boss entrance: stinger + boss SFX + shake + smoke
            self.game.audio.trigger_event("boss_intro")
            self.anim.add_shake(0.45)
            self.anim.particles.loss_smoke(WINDOW_WIDTH // 2, 360)
        self.game.save_current_run()

        # Big number tween for the target so it counts up dramatically
        self.target_tween = NumberTween(initial=0, speed=6.0)
        self.target_tween.set(self.blind.score_target)

    def _begin(self):
        self.game.sounds.play("click")
        run = self.game.run
        run.start_blind(self.blind)
        run.deal_to_hand()
        self.game.switch_to("play")

    def _give_up(self):
        self.game.end_run(False)
        self.game.switch_to("title")

    def handle_events(self, events):
        for e in events:
            self.begin_btn.handle_event(e)
            self.quit_btn.handle_event(e)
            if e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_SPACE):
                self._begin()

    def update(self, dt):
        super().update(dt)
        self.target_tween.update(dt)

    def draw_scene(self, surface):
        run = self.game.run
        _draw_top_hud(surface, run, self.game)

        ante_txt = render_text(f"ANTE {run.ante} / {MAX_ANTE}", 38, C.GOLD, bold=True)
        surface.blit(ante_txt, ante_txt.get_rect(center=(WINDOW_WIDTH // 2, 180)))

        # Slide-in: panel rises slightly during enter fade
        slide = (1.0 - self.enter_t) * 40
        panel = pygame.Rect(WINDOW_WIDTH // 2 - 320, 220 + int(slide), 640, 320)
        if self.blind.kind == "boss":
            pygame.draw.rect(surface, (60, 8, 14), panel, border_radius=10)
            pygame.draw.rect(surface, C.BLOOD, panel, 3, border_radius=10)
        else:
            draw_panel(surface, panel)

        title_color = C.BLOOD_BRIGHT if self.blind.kind == "boss" else C.GOLD
        title_surf = render_text(self.blind.title, 48, title_color, bold=True)
        surface.blit(title_surf, title_surf.get_rect(center=(panel.centerx, panel.y + 50)))

        for i, line in enumerate(_wrap(self.blind.subtitle, 50)):
            s = render_text(line, 22, C.TEXT_DIM)
            surface.blit(s, s.get_rect(center=(panel.centerx, panel.y + 100 + i * 26)))

        target_label = render_text("SCORE AT LEAST", 20, C.TEXT_DIM)
        surface.blit(target_label, target_label.get_rect(center=(panel.centerx, panel.y + 180)))
        target_size = 60
        target_str = f"{self.target_tween.display_int}"
        target = render_text(target_str, target_size, C.GOLD_BRIGHT, bold=True)
        surface.blit(target, target.get_rect(center=(panel.centerx, panel.y + 230)))

        reward_txt = render_text(f"Reward: ${self.blind.reward}", 20, C.GREEN_GOOD)
        surface.blit(reward_txt, reward_txt.get_rect(center=(panel.centerx, panel.y + 280)))

        self.begin_btn.draw(surface)
        self.quit_btn.draw(surface)


# ============================================================================ #
# Play screen — step-by-step scoring with full polish
# ============================================================================ #
class PlayPhase:
    IDLE       = "idle"
    PLAYING    = "playing"      # cards arc to center
    HAND_NAME  = "hand_name"    # hand name pops in
    SCORING    = "scoring"      # step through cards + jokers
    FINAL      = "final"        # final total pulse + shake
    DEALING    = "dealing"      # refill animation
    ROUND_WIN  = "round_win"
    ROUND_LOSE = "round_lose"


# A scoring step is a small dict produced by _build_steps()
#   {"kind": "card",  "card": Card, "chips": int}
#   {"kind": "joker", "joker_idx": int, "chips_delta": float,
#                     "mult_delta": float, "mult_factor": float, "label": str}
#   {"kind": "boss",  "label": str, "mult_factor": float}


class PlayScreen(Screen):
    # Casino-table look gets its own green felt via `_draw_bg`. The spotlight
    # post-FX would clash with the felt, so it's off here.
    USE_SPOTLIGHT = False
    MUSIC_INTENSITY = "medium"  # ramps to "high" mid-scoring, back when idle

    # --- Layout constants for the new Balatro-style table ---
    LEFT_PANEL_X = 14
    LEFT_PANEL_W = 244
    RIGHT_PANEL_X = WINDOW_WIDTH - 200
    RIGHT_PANEL_W = 186
    # Joker row sits across the top of the middle area
    JOKER_ROW_Y = 28
    JOKER_SLOT_W = 124
    JOKER_SLOT_H = 158
    JOKER_GAP = 10
    # Centered "Score at least" target display
    CENTER_DISPLAY_Y = 220
    # Bottom hand baseline
    PLAY_AREA_Y = 380

    def __init__(self, game):
        super().__init__(game)
        self.run = game.run

        # Card layout
        self.hand_y = WINDOW_HEIGHT - 200
        self.play_y = self.PLAY_AREA_Y

        # Right-sidebar action buttons (Play Hand red, Discard blue)
        right_x = self.RIGHT_PANEL_X + 6
        right_btn_w = self.RIGHT_PANEL_W - 12
        self.play_btn = Button(
            pygame.Rect(right_x, 380, right_btn_w, 54),
            "PLAY HAND", on_click=self._on_play_hand,
            color_border=C.BLOOD_BRIGHT, font_size=22,
        )
        self.discard_btn = Button(
            pygame.Rect(right_x, 444, right_btn_w, 54),
            "DISCARD", on_click=self._on_discard,
            color_border=C.BLUE_INFO, font_size=22,
        )
        # Sort buttons sit in the bottom-left of the left side panel
        left_btn_x = self.LEFT_PANEL_X + 14
        left_btn_w = self.LEFT_PANEL_W - 28
        self.sort_rank_btn = Button(
            pygame.Rect(left_btn_x, WINDOW_HEIGHT - 130, left_btn_w, 36),
            "SORT RANK", on_click=self._sort_by_rank, font_size=18,
        )
        self.sort_suit_btn = Button(
            pygame.Rect(left_btn_x, WINDOW_HEIGHT - 88, left_btn_w, 36),
            "SORT SUIT", on_click=self._sort_by_suit, font_size=18,
        )
        # Menu button — small, sits in the right panel above PLAY HAND
        self.menu_btn = Button(
            pygame.Rect(right_x, 28, right_btn_w, 36),
            "MENU", on_click=self._open_menu, font_size=18,
        )

        # Pause menu
        self.show_menu = False
        cx = WINDOW_WIDTH // 2
        py = WINDOW_HEIGHT // 2 - 80
        self.menu_buttons = [
            Button(pygame.Rect(cx - 120, py + 60, 240, 44), "RESUME",
                   on_click=lambda: self._set_menu(False)),
            Button(pygame.Rect(cx - 120, py + 120, 240, 44), "SAVE & QUIT",
                   on_click=self._save_and_quit),
            Button(pygame.Rect(cx - 120, py + 180, 240, 44), "ABANDON RUN",
                   on_click=self._abandon_run, color_border=C.BLOOD),
        ]

        # Scoring sequence state
        self.phase = PlayPhase.IDLE
        self.phase_timer = 0.0
        self.steps: List[dict] = []
        self.step_idx = 0
        self.hand_type: Optional[str] = None
        self.scoring_cards: List[Card] = []
        self.played_cards: List[Card] = []
        self.flinging_cards: List[Card] = []   # discarded / fading out
        self.last_total = 0

        # Smoothed counters
        self.chips_tween = NumberTween(0, speed=11.0)
        self.mult_tween  = NumberTween(0, speed=11.0)
        self.total_tween = NumberTween(0, speed=10.0)
        self.money_tween = NumberTween(self.run.money, speed=8.0)
        self.score_tween = NumberTween(self.run.round_score, speed=9.0)
        self.chips_pulse = Pulse(decay=0.45)
        self.mult_pulse  = Pulse(decay=0.45)
        self.total_pulse = Pulse(decay=0.55)

        # Per-joker pulses for visual highlight when triggered
        self.joker_pulses = [Pulse(decay=0.35) for _ in range(MAX_JOKERS)]

        # Working ctx during scoring (chips, mult tracked here for display)
        self.work_chips = 0.0
        self.work_mult = 0.0
        # Score context owned by `_build_steps`. Used by FINAL phase to clean
        # up Fragile breaks / Burst consumes. None outside the scoring sequence.
        self.score_ctx = None

        # Hand-name popup state (separate from generic popups so it's centered + sticky)
        self.hand_name_text: Optional[str] = None
        self.hand_name_t = 1.0  # 1.0 = idle

        # Persisted sort preference. Defaults to "rank" if no preference saved.
        self.sort_mode = self.game.stats.get("sort_mode", "rank")

        # Layout snapped on first frame — sort applied so opening hand respects pref.
        self._apply_sort()
        self._stagger_deal_initial()

    # ----- Hand layout ----- #
    def _layout_hand(self, snap: bool = False) -> None:
        """Compute target positions + fan rotation for each card in hand."""
        n = len(self.run.hand)
        if n == 0:
            return
        total_w = n * CARD_WIDTH + (n - 1) * CARD_GAP
        start_x = WINDOW_WIDTH // 2 - total_w // 2
        center_idx = (n - 1) / 2.0
        for i, c in enumerate(self.run.hand):
            x = start_x + i * (CARD_WIDTH + CARD_GAP)
            y = self.hand_y - (CARD_LIFT if c.selected else 0)
            c.target = (x, y)
            # Outer cards fan out slightly
            offset_from_center = i - center_idx
            c.fan_rotation = offset_from_center * 1.5
            if snap:
                c.pos = c.target
                c.rotation = c.fan_rotation

    def _stagger_deal_initial(self) -> None:
        """First deal: cards arrive from above with a per-card stagger delay.
        Honours the persistent sort preference."""
        self._apply_sort()
        self._layout_hand()
        for i, c in enumerate(self.run.hand):
            c.pos = (c.target[0], -CARD_HEIGHT - 20 - i * 6)
            c.deal_delay = i * 0.055
            c.rotation = c.fan_rotation
        self.game.sounds.play("deal")

    # ----- Helpers ----- #
    def _selected_cards(self) -> List[Card]:
        return [c for c in self.run.hand if c.selected]

    def _card_under_mouse(self, mouse_pos) -> Optional[Card]:
        # Iterate in reverse so visually-on-top cards win the hover.
        for c in reversed(self.run.hand):
            rect = pygame.Rect(int(c.pos[0]), int(c.pos[1]), CARD_WIDTH, CARD_HEIGHT)
            if rect.collidepoint(mouse_pos):
                return c
        return None

    def _open_menu(self):
        self.show_menu = not self.show_menu

    def _set_menu(self, v):
        self.show_menu = v

    def _save_and_quit(self):
        self.game.save_current_run()
        self.game.switch_to("title")

    def _abandon_run(self):
        self.game.end_run(False)
        self.game.switch_to("title")

    # ----- Sort ----- #
    # The chosen sort mode persists for the rest of the run *and* across game
    # restarts — it lives in stats.json under "sort_mode". Every time the
    # hand is dealt or refilled we call _apply_sort() so newly-drawn cards
    # slot into the right place automatically.
    def _sort_by_rank(self):
        if self.phase != PlayPhase.IDLE:
            return
        self.game.sounds.play("click")
        self._set_sort_mode("rank")

    def _sort_by_suit(self):
        if self.phase != PlayPhase.IDLE:
            return
        self.game.sounds.play("click")
        self._set_sort_mode("suit")

    def _set_sort_mode(self, mode: str) -> None:
        self.sort_mode = mode
        # Persist so the next run / session / blind starts with the same order
        if self.game.stats.get("sort_mode") != mode:
            self.game.stats["sort_mode"] = mode
            from game.save import save_stats
            save_stats(self.game.stats)
        self._apply_sort()
        self._layout_hand()

    def _apply_sort(self) -> None:
        """Reorder `run.hand` in place according to the current sort mode."""
        if not self.run.hand:
            return
        if self.sort_mode == "suit":
            suit_order = {"spades": 0, "hearts": 1, "diamonds": 2, "clubs": 3}
            self.run.hand.sort(key=lambda c: (suit_order[c.suit], -c.rank_value))
        else:  # default to rank
            self.run.hand.sort(key=lambda c: (-c.rank_value, c.suit))

    # ----- Card selection ----- #
    def _toggle_card(self, card: Card):
        if card.selected:
            card.selected = False
        else:
            if sum(1 for c in self.run.hand if c.selected) >= SELECT_MAX:
                return
            card.selected = True
            card.pulse_t = 0.0
        self.game.sounds.play("card_select")
        self._layout_hand()

    # ----- Action: play hand ----- #
    def _on_play_hand(self):
        if self.phase != PlayPhase.IDLE:
            return
        sel = self._selected_cards()
        if not sel or len(sel) > SELECT_MAX or self.run.hands_left <= 0:
            return
        # Adaptive music: ramp tension layer in for the scoring sequence
        self.game.audio.set_intensity("high")
        self.game.sounds.play("card_play")
        self.game.sounds.play("card_slap", volume=0.6)

        # Snapshot played cards and arc them to center
        self.played_cards = sel[:]
        for c in sel:
            self.run.hand.remove(c)
            c.selected = False
            c.arc_start = c.pos
            c.motion_mode = "arc"
            c.arc_t = 0.0
            c.arc_duration = 0.45

        # Compute play-area targets
        n = len(self.played_cards)
        total_w = n * CARD_WIDTH + (n - 1) * CARD_GAP
        start_x = WINDOW_WIDTH // 2 - total_w // 2
        for i, c in enumerate(self.played_cards):
            c.target = (start_x + i * (CARD_WIDTH + CARD_GAP), self.play_y)
            c.fan_rotation = 0.0

        # Build the step-by-step scoring sequence
        self._build_steps(self.played_cards)

        # Initialize live chip/mult counters
        base_c, base_m = HAND_BASE_SCORES.get(self.hand_type, (0, 1))
        self.work_chips = float(base_c)
        self.work_mult = float(base_m)
        self.chips_tween.snap(self.work_chips)
        self.mult_tween.snap(self.work_mult)
        self.total_tween.snap(self.work_chips * self.work_mult)
        self.chips_pulse.trigger(0.22)

        self._layout_hand()
        self.phase = PlayPhase.PLAYING
        self.phase_timer = 0.45  # arc travel
        self.step_idx = 0

        # Small kick to confirm the play
        self.anim.add_shake(0.12)

    # ----- Action: discard ----- #
    def _on_discard(self):
        if self.phase != PlayPhase.IDLE:
            return
        sel = self._selected_cards()
        if not sel or self.run.discards_left <= 0:
            return
        self.game.sounds.play("deal")

        # Joker on_discard hooks (Crow scaling)
        for j in self.run.jokers:
            j.on_discard(sel)
        # Briefly pulse jokers that care about discards (Crow)
        for i, j in enumerate(self.run.jokers):
            if j.joker_id == "crow":
                self.joker_pulses[i].trigger(0.32)
                cx, cy = joker_slot_position(i)
                self.anim.trigger_joker("crow", cx, cy)

        # Pending-remove from "Crow's Eye" pack: delete instead of discard
        if self.run.pending_remove:
            for c in sel:
                self.run.deck.remove_card(c)
            self.run.pending_remove = False
        else:
            self.run.deck.discard.extend(sel)

        # Visual: fling each selected card off-screen with random spin
        for c in sel:
            self.run.hand.remove(c)
            c.motion_mode = "fling"
            c.velocity = (random.uniform(-180, 180), random.uniform(-560, -380))
            c.spin = random.uniform(-720, 720)
            c.fade_t = 0.0
            self.flinging_cards.append(c)
            # Dark mist from the card center
            self.anim.particles.burst_smoke(
                c.pos[0] + CARD_WIDTH / 2, c.pos[1] + CARD_HEIGHT / 2,
                (60, 30, 38), count=3, speed=40, lifetime=0.7,
            )

        self.run.discards_left -= 1

        # Refill hand with drop-in animation. Re-apply the persistent sort
        # mode so new cards slot into their proper position rather than
        # tacking on at the end.
        new_cards = self.run.deal_to_hand()
        self._apply_sort()
        self._layout_hand()
        for i, c in enumerate(new_cards):
            c.pos = (c.target[0], -CARD_HEIGHT - 20 - i * 4)
            c.deal_delay = i * 0.05
            c.rotation = c.fan_rotation

    # ----- Step builder ----- #
    def _build_steps(self, played: List[Card]) -> None:
        """
        Produce ordered list of step dicts the scoring phase will walk.

        Each scoring card fires:
          1. A 'card' step adding its base chip value
          2. (if it has a modifier with an effect) a 'modifier' step

        Then every joker that contributed gets a 'joker' step, then optionally
        a 'boss' step for boss-blind modifiers.

        Simulates everything through a parallel ScoreContext (`tmp_ctx`) so we
        can capture deltas per step. The same ctx is stashed on `self.score_ctx`
        so the FINAL phase can read its modifier side-channels (broken /
        consumed cards) for cleanup.
        """
        hand_type, scoring = evaluate_hand(played)
        self.hand_type = hand_type
        boss = self.run.current_blind.boss if self.run.current_blind else None
        if boss is not None:
            scoring = boss.filter_scoring(scoring)
        self.scoring_cards = scoring

        # Single ctx is the source of truth — modifier side-channels live on it
        tmp_ctx = ScoreContext(hand_type, played, scoring)
        tmp_ctx._break_cards = []
        tmp_ctx._consumed_modifier_cards = []

        steps: List[dict] = []

        # Per-card: base chips, then modifier effect (if any)
        for c in scoring:
            steps.append({"kind": "card", "card": c, "chips": c.chip_value})
            tmp_ctx.add_chips(c.chip_value)

            if getattr(c, "modifier", None) is not None:
                chips_before = tmp_ctx.chips
                mult_before = tmp_ctx.mult
                c.modifier.on_card_score(tmp_ctx, c)
                if c.modifier.is_consumed():
                    tmp_ctx._consumed_modifier_cards.append(c)
                dc = tmp_ctx.chips - chips_before
                dm = tmp_ctx.mult - mult_before
                if dc != 0 or dm != 0:
                    steps.append({
                        "kind": "modifier",
                        "card": c,
                        "modifier": c.modifier,
                        "chips_delta": dc,
                        "mult_delta": dm,
                        "label": c.modifier.name,
                    })

        # Joker steps
        for i, j in enumerate(self.run.jokers):
            chips_before = tmp_ctx.chips
            mult_before = tmp_ctx.mult
            log_before = len(tmp_ctx.log)
            j.on_score(tmp_ctx, self.run.jokers)
            dc = tmp_ctx.chips - chips_before
            dm = tmp_ctx.mult - mult_before
            if dc == 0 and dm == 0:
                continue
            labels = [e[0] for e in tmp_ctx.log[log_before:] if e and e[0]]
            label = labels[0] if labels else j.name
            steps.append({
                "kind": "joker", "joker_idx": i, "joker": j,
                "chips_delta": dc, "mult_delta": dm,
                "label": label,
            })

        # Boss final modifier (e.g. Halved Mult)
        if boss is not None:
            chips_before = tmp_ctx.chips
            mult_before = tmp_ctx.mult
            boss.modify_final(tmp_ctx)
            dc = tmp_ctx.chips - chips_before
            dm = tmp_ctx.mult - mult_before
            if dc != 0 or dm != 0:
                steps.append({
                    "kind": "boss", "label": boss.name,
                    "chips_delta": dc, "mult_delta": dm,
                })

        self.steps = steps
        # Stash the ctx so FINAL phase can clean up Fragile breaks / Burst consumes.
        self.score_ctx = tmp_ctx

    # ----- Apply a single step ----- #
    def _apply_step(self, step: dict) -> None:
        kind = step["kind"]
        if kind == "card":
            card = step["card"]
            chips = step["chips"]
            self.work_chips += chips
            self.chips_tween.set(self.work_chips)
            self.chips_pulse.trigger(0.16)
            card.pulse_t = 0.0
            # Gold spark off the card + chip popup
            cx = card.pos[0] + CARD_WIDTH / 2
            cy = card.pos[1] + CARD_HEIGHT / 2
            self.anim.particles.burst_sparks(cx, cy, C.BLUE_INFO, count=8, speed=180, lifetime=0.6)
            self.anim.add_popup(FloatingText(
                (cx, cy - 18), f"+{chips}", C.BLUE_INFO, size=24, duration=0.9, dy=-44,
            ))
            self.game.sounds.play("score_pop")

        elif kind == "modifier":
            # Card modifier (Reinforced, Burst, etc.) fires right after the
            # card itself scored. Reuse the same Pulse/popup pattern so the
            # animation language stays consistent.
            from game.modifiers import category_color
            card = step["card"]
            mod = step["modifier"]
            dc = step["chips_delta"]
            dm = step["mult_delta"]
            label = step["label"]
            if dc:
                self.work_chips += dc
                self.chips_tween.set(self.work_chips)
                self.chips_pulse.trigger(0.20)
            if dm:
                self.work_mult += dm
                self.mult_tween.set(self.work_mult)
                self.mult_pulse.trigger(0.26)
            cx = card.pos[0] + CARD_WIDTH / 2
            cy = card.pos[1] + CARD_HEIGHT / 2
            col = category_color(mod)
            self.anim.particles.burst_sparks(cx, cy, col, count=12, speed=200, lifetime=0.7)
            # Popup color follows the modifier category (gold/purple/cyan)
            popup_color = col
            self.anim.add_popup(FloatingText(
                (cx, cy - 30), label, popup_color, size=22, duration=1.1, dy=-50,
            ))
            # Card pulses again to highlight the modifier kick
            card.pulse_t = 0.0
            self.game.sounds.play("score_pop")

        elif kind == "joker":
            i = step["joker_idx"]
            j = step["joker"]
            dc = step["chips_delta"]
            dm = step["mult_delta"]
            label = step["label"]
            if dc:
                self.work_chips += dc
                self.chips_tween.set(self.work_chips)
                self.chips_pulse.trigger(0.18)
            if dm:
                self.work_mult += dm
                self.mult_tween.set(self.work_mult)
                self.mult_pulse.trigger(0.28)
            cx, cy = joker_slot_position(i)
            # Pulse the slot and fire signature particles
            self.joker_pulses[i].trigger(0.32)
            self.anim.trigger_joker(j.joker_id, cx, cy)
            # Per-joker signature SFX (raven swoosh / owl chime / eagle rise /
            # vulture deep decay / etc.) — falls back to generic score_pop if
            # the specific sound failed to generate.
            joker_sfx = f"joker_{j.joker_id}"
            if joker_sfx in self.game.sounds.sounds:
                self.game.sounds.play(joker_sfx)
            else:
                self.game.sounds.play("score_pop")
            color = C.BLUE_INFO if dc > 0 else C.BLOOD_BRIGHT
            self.anim.add_popup(FloatingText(
                (cx, cy + 8), label, color, size=20, duration=1.1, dy=-50,
            ))
            # Small shake for "loud" jokers
            if j.joker_id in ("eagle", "peacock"):
                self.anim.add_shake(0.20)

        elif kind == "boss":
            dm = step["mult_delta"]
            dc = step["chips_delta"]
            if dc:
                self.work_chips += dc
                self.chips_tween.set(self.work_chips)
            if dm:
                self.work_mult += dm
                self.mult_tween.set(self.work_mult)
                self.mult_pulse.trigger(0.30)
            self.anim.particles.loss_smoke(WINDOW_WIDTH // 2, self.play_y - 20)
            self.anim.add_popup(FloatingText(
                (WINDOW_WIDTH // 2, self.play_y - 60),
                step["label"], C.BLOOD_BRIGHT, size=24, duration=1.4, dy=-40,
            ))
            self.anim.add_shake(0.18)

        # Update total counter
        self.total_tween.set(self.work_chips * self.work_mult)

    # ----- Events ----- #
    def handle_events(self, events):
        for e in events:
            if self.show_menu:
                for b in self.menu_buttons:
                    b.handle_event(e)
                if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                    self.show_menu = False
                continue

            self.menu_btn.handle_event(e)

            if self.phase != PlayPhase.IDLE:
                if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                    self.show_menu = True
                continue

            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self._on_play_hand()
                elif e.key == pygame.K_x:
                    self._on_discard()
                elif e.key == pygame.K_ESCAPE:
                    self.show_menu = True
            for b in (self.play_btn, self.discard_btn,
                      self.sort_rank_btn, self.sort_suit_btn):
                b.handle_event(e)

            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                c = self._card_under_mouse(e.pos)
                if c is not None:
                    self._toggle_card(c)

    # ----- Update ----- #
    def update(self, dt):
        super().update(dt)

        # Hover detection (only when no pause and idle phase)
        mouse_pos = pygame.mouse.get_pos()
        hovered = None
        if self.phase == PlayPhase.IDLE and not self.show_menu:
            hovered = self._card_under_mouse(mouse_pos)

        # Cards in hand — apply hover-tilt toward mouse cursor for hovered card
        for c in self.run.hand:
            update_card_motion(c, dt, hover_target=(c is hovered))
            if c is hovered:
                center = (c.pos[0] + CARD_WIDTH / 2, c.pos[1] + CARD_HEIGHT / 2)
                target_tilt = compute_hover_tilt(center, mouse_pos)
            else:
                target_tilt = 0.0
            c.hover_tilt = damp(c.hover_tilt, target_tilt, 12.0, dt)
        # Played cards (mid-scoring)
        for c in self.played_cards:
            update_card_motion(c, dt, hover_target=False)
        # Flinging cards (discards & post-scoring)
        for c in self.flinging_cards:
            update_card_motion(c, dt, hover_target=False)
        self.flinging_cards = [c for c in self.flinging_cards if not c.dead]

        # Counters / pulses
        self.chips_tween.update(dt)
        self.mult_tween.update(dt)
        self.total_tween.update(dt)
        self.money_tween.set(self.run.money)
        self.money_tween.update(dt)
        self.score_tween.set(self.run.round_score)
        self.score_tween.update(dt)
        self.chips_pulse.update(dt)
        self.mult_pulse.update(dt)
        self.total_pulse.update(dt)
        for jp in self.joker_pulses:
            jp.update(dt)

        # Hand-name pop progress
        if self.hand_name_t < 1.0:
            self.hand_name_t = min(1.0, self.hand_name_t + dt / 0.45)

        # Button state
        sel = self._selected_cards()
        can_play = self.phase == PlayPhase.IDLE and self.run.hands_left > 0 and 1 <= len(sel) <= SELECT_MAX
        can_disc = self.phase == PlayPhase.IDLE and self.run.discards_left > 0 and len(sel) > 0
        self.play_btn.disabled = not can_play
        self.discard_btn.disabled = not can_disc

        # Phase progression
        if self.phase == PlayPhase.IDLE:
            return

        self.phase_timer -= dt
        if self.phase == PlayPhase.PLAYING:
            if self.phase_timer <= 0:
                # Cards have arrived. Pop the hand name.
                self.hand_name_text = hand_display_name(self.hand_type or "high_card")
                self.hand_name_t = 0.0
                self.phase = PlayPhase.HAND_NAME
                self.phase_timer = 0.45
                # Modest shake on landing
                self.anim.add_shake(0.10)

        elif self.phase == PlayPhase.HAND_NAME:
            if self.phase_timer <= 0:
                self.phase = PlayPhase.SCORING
                self.phase_timer = 0.0
                self.step_idx = 0

        elif self.phase == PlayPhase.SCORING:
            if self.phase_timer <= 0:
                if self.step_idx < len(self.steps):
                    step = self.steps[self.step_idx]
                    self._apply_step(step)
                    self.step_idx += 1
                    # Pacing varies by step kind
                    if step["kind"] == "card":
                        self.phase_timer = 0.22
                    elif step["kind"] == "modifier":
                        # Slightly slower than a card to let the modifier read
                        self.phase_timer = 0.30
                    elif step["kind"] == "joker":
                        self.phase_timer = 0.34
                    else:
                        self.phase_timer = 0.42
                else:
                    # All steps applied. Show final pulse.
                    self.total_pulse.trigger(0.45)
                    self.last_total = int(self.work_chips * self.work_mult)
                    # Screen shake based on how strong the score is
                    target = max(1, self.run.current_blind.score_target)
                    intensity = min(0.9, self.last_total / target * 0.35 + 0.25)
                    self.anim.add_shake(intensity)
                    # Hit flash + chromatic aberration scale with the score
                    self.trigger_hit_flash(min(0.55, 0.15 + intensity * 0.5))
                    if intensity > 0.5:
                        # Big gold burst + brief CRT-style aberration
                        self.anim.particles.burst_sparks(
                            WINDOW_WIDTH // 2, self.play_y - 60, C.GOLD_BRIGHT,
                            count=24, speed=320, lifetime=0.9,
                        )
                        self.trigger_aberration(frames=4)
                        self.game.sounds.play("win_round")
                    self.phase = PlayPhase.FINAL
                    self.phase_timer = 0.9

        elif self.phase == PlayPhase.FINAL:
            if self.phase_timer <= 0:
                total = self.last_total
                self.run.round_score += total
                if total > self.run.best_score_this_run:
                    self.run.best_score_this_run = total
                self.run.hands_left -= 1
                # --- Modifier cleanup from the score context ----------------
                # Burst etc. consumed themselves during scoring — strip them.
                consumed = getattr(self.score_ctx, "_consumed_modifier_cards", None) or []
                for c in consumed:
                    if c.modifier is not None:
                        c.modifier = None
                # Fragile may have flagged cards to shatter. Remove from deck
                # entirely and pop a smoke puff for visual confirmation.
                broken = getattr(self.score_ctx, "_break_cards", None) or []
                for c in broken:
                    self.run.deck.remove_card(c)
                    # Tiny dark smoke where the card sat
                    self.anim.particles.burst_smoke(
                        c.pos[0] + CARD_WIDTH / 2, c.pos[1] + CARD_HEIGHT / 2,
                        (90, 30, 38), count=4, speed=60, lifetime=0.9,
                    )
                if broken:
                    self.anim.add_shake(0.12)
                # Played cards fly off and fade
                for c in self.played_cards:
                    c.motion_mode = "fling"
                    c.velocity = (random.uniform(-90, 90), random.uniform(-420, -260))
                    c.spin = random.uniform(-540, 540)
                    c.fade_t = 0.0
                    self.flinging_cards.append(c)
                # Only cards that didn't shatter go to the discard pile.
                survivors = [c for c in self.played_cards if c not in broken]
                self.run.deck.discard.extend(survivors)
                self.played_cards = []
                self.hand_name_text = None
                # Refill hand and re-apply persistent sort so new cards land
                # in the right slot instead of being appended at the end.
                new_cards = self.run.deal_to_hand()
                self._apply_sort()
                self._layout_hand()
                for i, c in enumerate(new_cards):
                    c.pos = (c.target[0], -CARD_HEIGHT - 20 - i * 4)
                    c.deal_delay = i * 0.045
                    c.rotation = c.fan_rotation
                self.game.sounds.play("deal")
                # Check win/lose
                if self.run.round_score >= self.run.current_blind.score_target:
                    self.phase = PlayPhase.ROUND_WIN
                    self.phase_timer = 1.3
                    self.anim.add_shake(0.45)
                    self.anim.particles.burst_fan(
                        WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2,
                        C.GOLD_BRIGHT, C.GOLD, count=20, speed=260,
                    )
                    # Big-win audio reaction: choir stinger + win SFX,
                    # plus a brief held "huge multiplier" ringing tone if
                    # the score blew past the target hard.
                    self.game.audio.trigger_event("big_win")
                    target = max(1, self.run.current_blind.score_target)
                    if self.last_total > target * 1.5:
                        self.game.audio.trigger_event("huge_multiplier")
                elif self.run.hands_left <= 0:
                    self.phase = PlayPhase.ROUND_LOSE
                    self.phase_timer = 1.8
                    self.anim.particles.loss_smoke(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2)
                    self.game.audio.trigger_event("round_lost")
                else:
                    self.phase = PlayPhase.DEALING
                    self.phase_timer = 0.55
                    # Scoring done — drop music back to ambient for the next play.
                    self.game.audio.set_intensity("medium")

        elif self.phase == PlayPhase.DEALING:
            if self.phase_timer <= 0:
                # Reset working counters for next play preview
                self.work_chips = 0.0
                self.work_mult = 0.0
                self.chips_tween.snap(0)
                self.mult_tween.snap(0)
                self.total_tween.snap(0)
                # Release the score ctx so its references don't linger.
                self.score_ctx = None
                self.phase = PlayPhase.IDLE

        elif self.phase == PlayPhase.ROUND_WIN:
            if self.phase_timer <= 0:
                self._finish_round_win()

        elif self.phase == PlayPhase.ROUND_LOSE:
            if self.phase_timer <= 0:
                self._finish_round_lose()

    def _finish_round_win(self):
        """
        End-of-round: cash out, record the breakdown, then hand off to the
        RoundResultScreen for the reward reveal sequence. The result screen
        is the one that finally switches into the shop — this keeps PlayScreen
        from owning the transition.
        """
        run = self.run
        # Capture state for the result screen *before* we mutate it.
        money_before = run.money
        blind_title = run.current_blind.title if run.current_blind else ""
        blind_kind = run.current_blind_kind() if run.current_blind else "small"
        target = run.current_blind.score_target if run.current_blind else 0
        score = run.round_score

        breakdown = run.end_blind()  # mutates run.money in place
        if not run.advance_blind():
            # Completed the final boss — go straight to the WinScreen, no
            # interstitial reward screen (the win screen IS the reward).
            self.game.end_run(True)
            self.game.switch_to("win")
            return

        summary = dict(breakdown)
        summary.update({
            "money_before": money_before,
            "money_after": run.money,
            "score": score,
            "target": target,
            "blind_title": blind_title,
            "blind_kind": blind_kind,
        })
        # RoundResultScreen does its own ~3-second reveal, then switches to shop.
        self.game.switch_to("result", summary=summary)

    def _finish_round_lose(self):
        self.game.end_run(False)
        self.game.switch_to("over")

    # ----- Draw ----- #
    # Casino-table background: green felt + faint cross-hatch + corner darken.
    def _draw_bg(self, surface):
        if not hasattr(self, "_felt_tex") or self._felt_tex is None:
            self._felt_tex = self._build_felt_texture()
        surface.blit(self._felt_tex, (0, 0))
        # Drift silhouettes (kept faint) for ambient motion
        for d in self._bg_drifters:
            self._draw_drifter(surface, d)

    def _build_felt_texture(self) -> pygame.Surface:
        """Pre-bake the green felt: flat green + cross-hatch + corner shadow."""
        s = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        # Slight vertical gradient (top a touch darker so the table reads as lit)
        for y in range(WINDOW_HEIGHT):
            t = y / max(1, WINDOW_HEIGHT - 1)
            r = int(20 * (1 - t) + 28 * t)
            g = int(72 * (1 - t) + 92 * t)
            b = int(48 * (1 - t) + 60 * t)
            pygame.draw.line(s, (r, g, b), (0, y), (WINDOW_WIDTH, y))
        # Cross-hatch fabric texture
        hatch = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        for x in range(-WINDOW_HEIGHT, WINDOW_WIDTH, 3):
            pygame.draw.line(hatch, (0, 0, 0, 10), (x, 0), (x + WINDOW_HEIGHT, WINDOW_HEIGHT), 1)
        for x in range(0, WINDOW_WIDTH + WINDOW_HEIGHT, 3):
            pygame.draw.line(hatch, (255, 255, 255, 6), (x, 0), (x - WINDOW_HEIGHT, WINDOW_HEIGHT), 1)
        s.blit(hatch, (0, 0))
        # Grainy speckles
        rng = random.Random(0xfee1)
        for _ in range(800):
            x = rng.randint(0, WINDOW_WIDTH - 1)
            y = rng.randint(0, WINDOW_HEIGHT - 1)
            dot = (rng.randint(10, 40), rng.randint(40, 70), rng.randint(30, 55))
            s.set_at((x, y), dot)
        # Corner vignette
        vig = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        for i in range(6):
            inset = i * 18
            alpha = 28 - i * 4
            if alpha <= 0:
                break
            pygame.draw.rect(vig, (0, 0, 0, alpha),
                             pygame.Rect(inset, inset,
                                         WINDOW_WIDTH - inset * 2,
                                         WINDOW_HEIGHT - inset * 2),
                             24, border_radius=18)
        s.blit(vig, (0, 0))
        return s

    def draw_scene(self, surface):
        run = self.run

        # 1) Joker row across the top
        self._draw_joker_row(surface)

        # 2) Left side panel — ante, round score, chips×mult, sort buttons
        self._draw_left_sidebar(surface)

        # 3) Right side panel — round stats, play/discard, deck
        self._draw_right_sidebar(surface)

        # 4) Centered "Score at least" display with chip icon + progress bar
        self._draw_center_target(surface)

        # 5) Owl peek (if owned) — small card preview in left margin
        if any(j.joker_id == "owl" for j in run.jokers) and run.deck.cards:
            peek_card = run.deck.cards[-1]
            peek_label = render_text("OWL PEEK", 12, (210, 220, 200), bold=True)
            surface.blit(peek_label, (self.LEFT_PANEL_X + 8, WINDOW_HEIGHT - 200))
            peek_surf = self.game.assets.get_card(peek_card.rank, peek_card.suit)
            peek_small = pygame.transform.smoothscale(
                peek_surf, (int(CARD_WIDTH * 0.7), int(CARD_HEIGHT * 0.7))
            )
            peek_rect = peek_small.get_rect(topleft=(self.LEFT_PANEL_X + 8, WINDOW_HEIGHT - 184))
            surface.blit(peek_small, peek_rect)
            if peek_card.modifier is not None:
                draw_card_modifier_overlay(surface, peek_rect, peek_card.modifier)

        # 6) Cards: flinging (faded) → played (mid-scoring) → hand (front)
        for c in self.flinging_cards:
            draw_card(surface, c, self.game.assets)
        for c in self.played_cards:
            draw_card(surface, c, self.game.assets)
        for c in self.run.hand:
            draw_card(surface, c, self.game.assets, selected=c.selected)

        # 7) Hand-name pop (over the table)
        if self.hand_name_text and self.hand_name_t < 1.0:
            self._draw_hand_name(surface)

        # 8) Action + sort buttons (drawn after cards so they sit on top)
        self.play_btn.draw(surface)
        self.discard_btn.draw(surface)
        self.menu_btn.draw(surface)
        self.sort_rank_btn.draw(surface)
        self.sort_suit_btn.draw(surface)

        # 9) Pause overlay
        if self.show_menu:
            self._draw_menu(surface)

    # ------------------------------------------------------------------- #
    # Left side panel: ante + round-score + chips×mult readout + sort btns
    # ------------------------------------------------------------------- #
    def _draw_left_sidebar(self, surface):
        run = self.run
        x = self.LEFT_PANEL_X
        w = self.LEFT_PANEL_W

        # --- Top: Ante / Small Blind / score target panel -----------------
        ante_panel = pygame.Rect(x, 14, w, 142)
        self._draw_table_panel(surface, ante_panel, (40, 12, 16), C.BLOOD_DIM)
        # ANTE row
        ante_txt = render_text(f"ANTE {run.ante}/{MAX_ANTE}", 26, C.GOLD_BRIGHT, bold=True)
        surface.blit(ante_txt, (ante_panel.x + 14, ante_panel.y + 8))
        # Blind name
        blind_kind = run.current_blind_kind()
        blind_label = {"small": "SMALL BLIND", "big": "BIG BLIND", "boss": "BOSS BLIND"}[blind_kind]
        blind_color = C.BLOOD_BRIGHT if blind_kind == "boss" else (220, 220, 220)
        blind_txt = render_text(blind_label, 18, blind_color, bold=True)
        surface.blit(blind_txt, (ante_panel.x + 14, ante_panel.y + 40))
        # Big chip icon + Score-at-least
        chip_cx = ante_panel.x + 38
        chip_cy = ante_panel.y + 96
        self._draw_chip_icon(surface, (chip_cx, chip_cy), 22,
                             blind_color if blind_kind == "boss" else (40, 80, 170))
        sa_label = render_text("Score at least", 14, (200, 200, 200))
        surface.blit(sa_label, (ante_panel.x + 14, ante_panel.y + 70))
        target_val = run.current_blind.score_target if run.current_blind else 0
        target_txt = render_text(str(target_val), 32, C.BLOOD_BRIGHT, bold=True)
        surface.blit(target_txt, (ante_panel.x + 70, ante_panel.y + 84))
        # Reward indicator
        reward_dollars = "$" * min(5, max(1, (run.current_blind.reward if run.current_blind else 1)))
        rwd_label = render_text("Reward:", 13, (200, 200, 200))
        surface.blit(rwd_label, (ante_panel.x + 14, ante_panel.y + 122))
        rwd_val = render_text(reward_dollars, 16, C.GOLD_BRIGHT, bold=True)
        surface.blit(rwd_val, (ante_panel.x + 76, ante_panel.y + 120))

        # --- Round score (chip icon + counter) -----------------------------
        rs_panel = pygame.Rect(x, 168, w, 56)
        self._draw_table_panel(surface, rs_panel, (12, 22, 14), C.GOLD_DIM)
        lbl = render_text("Round score", 16, (220, 220, 220), bold=True)
        surface.blit(lbl, (rs_panel.x + 12, rs_panel.y + 6))
        self._draw_chip_icon(surface, (rs_panel.x + 30, rs_panel.bottom - 16), 12,
                             (170, 40, 50))
        score_val = render_text(str(self.score_tween.display_int), 22, C.GOLD_BRIGHT, bold=True)
        surface.blit(score_val, (rs_panel.x + 52, rs_panel.bottom - 30))

        # --- Chips × Mult inline readout -----------------------------------
        cm_panel = pygame.Rect(x, 236, w, 76)
        self._draw_table_panel(surface, cm_panel, (12, 14, 18), C.GOLD_DIM)
        # Determine current chips/mult to show
        if self.phase in (PlayPhase.PLAYING, PlayPhase.HAND_NAME,
                          PlayPhase.SCORING, PlayPhase.FINAL):
            chips_now = self.chips_tween.value
            mult_now = self.mult_tween.value
        else:
            sel = self._selected_cards()
            if sel:
                hand_type, scoring = evaluate_hand(sel)
                base_c, base_m = HAND_BASE_SCORES.get(hand_type, (0, 1))
                chips_now = float(base_c + sum(c.chip_value for c in scoring))
                mult_now = float(base_m)
            else:
                chips_now = 0.0
                mult_now = 0.0
        # Two sub-plates: blue chips, red mult
        plate_w = (cm_panel.width - 38) // 2
        chip_plate = pygame.Rect(cm_panel.x + 8, cm_panel.y + 8,
                                 plate_w, cm_panel.height - 16)
        mult_plate = pygame.Rect(cm_panel.right - 8 - plate_w, cm_panel.y + 8,
                                 plate_w, cm_panel.height - 16)
        pygame.draw.rect(surface, (30, 70, 150), chip_plate, border_radius=8)
        pygame.draw.rect(surface, (60, 110, 200), chip_plate, 2, border_radius=8)
        pygame.draw.rect(surface, (140, 30, 40), mult_plate, border_radius=8)
        pygame.draw.rect(surface, (200, 60, 70), mult_plate, 2, border_radius=8)
        # Numbers (scaled by pulse)
        chips_size = int(36 * self.chips_pulse.value)
        mult_size = int(36 * self.mult_pulse.value)
        chips_surf = render_text(str(int(chips_now)), max(18, chips_size),
                                 (245, 245, 250), bold=True)
        mult_surf = render_text(str(int(mult_now)), max(18, mult_size),
                                (245, 245, 250), bold=True)
        surface.blit(chips_surf, chips_surf.get_rect(center=chip_plate.center))
        surface.blit(mult_surf, mult_surf.get_rect(center=mult_plate.center))
        # × separator
        x_surf = render_text("X", 26, C.BLOOD_BRIGHT, bold=True)
        surface.blit(x_surf, x_surf.get_rect(center=(cm_panel.centerx, cm_panel.centery)))

        # --- Round info chips: Hands / Discards / $ -----------------------
        info_panel = pygame.Rect(x, 324, w, 90)
        self._draw_table_panel(surface, info_panel, (12, 14, 18), C.BORDER)
        col_w = info_panel.width // 3
        self._draw_stat_pill(surface,
            pygame.Rect(info_panel.x + 4, info_panel.y + 6, col_w - 6, info_panel.height - 12),
            "Hands", str(run.hands_left), (60, 110, 200))
        self._draw_stat_pill(surface,
            pygame.Rect(info_panel.x + col_w + 2, info_panel.y + 6, col_w - 6, info_panel.height - 12),
            "Discards", str(run.discards_left), (200, 60, 70))
        self._draw_stat_pill(surface,
            pygame.Rect(info_panel.x + col_w * 2, info_panel.y + 6, col_w - 6, info_panel.height - 12),
            "$", str(self.money_tween.display_int), (212, 175, 55))

        # --- Ante / Round counter pills below -----------------------------
        counters_y = info_panel.bottom + 10
        pill_w = (w - 14) // 2
        ap = pygame.Rect(x, counters_y, pill_w, 50)
        rp = pygame.Rect(x + pill_w + 14, counters_y, pill_w, 50)
        self._draw_stat_pill(surface, ap, "Ante", f"{run.ante}/{MAX_ANTE}", C.GOLD)
        self._draw_stat_pill(surface, rp, "Round", str(run.blind_idx + 1), C.GOLD)

    # ------------------------------------------------------------------- #
    # Top joker row
    # ------------------------------------------------------------------- #
    def _draw_joker_row(self, surface):
        run = self.run
        slots = run.max_joker_slots
        total_w = slots * self.JOKER_SLOT_W + (slots - 1) * self.JOKER_GAP
        # Center between the two side panels
        middle_x = self.LEFT_PANEL_X + self.LEFT_PANEL_W
        middle_w = self.RIGHT_PANEL_X - middle_x
        start_x = middle_x + (middle_w - total_w) // 2 + 10

        # Label above
        lbl = render_text(f"JOKERS  {len(run.jokers)}/{slots}", 16, (210, 210, 210), bold=True)
        surface.blit(lbl, (start_x, self.JOKER_ROW_Y - 22))

        for i in range(slots):
            slot_rect = pygame.Rect(
                start_x + i * (self.JOKER_SLOT_W + self.JOKER_GAP),
                self.JOKER_ROW_Y,
                self.JOKER_SLOT_W, self.JOKER_SLOT_H,
            )
            if i < len(run.jokers):
                joker = run.jokers[i]
                # Filled slot — show joker
                pygame.draw.rect(surface, (16, 12, 18), slot_rect, border_radius=10)
                pygame.draw.rect(surface, C.GOLD, slot_rect, 2, border_radius=10)
                icon = self.game.assets.get_joker(joker.joker_id)
                scale = self.joker_pulses[i].value if i < len(self.joker_pulses) else 1.0
                iw, ih = icon.get_size()
                target_w = int(min(self.JOKER_SLOT_W - 16, iw * 1.05) * scale)
                target_h = int(min(self.JOKER_SLOT_H - 38, ih * 1.05) * scale)
                scaled = pygame.transform.smoothscale(icon, (target_w, target_h))
                surface.blit(scaled, scaled.get_rect(center=(slot_rect.centerx, slot_rect.centery - 6)))
                status = joker.status_text()
                if status:
                    st = render_text(status, 14, C.GOLD_BRIGHT, bold=True)
                    surface.blit(st, st.get_rect(midbottom=(slot_rect.centerx, slot_rect.bottom - 4)))
            else:
                # Empty slot — dashed outline + "JOKER" label
                pygame.draw.rect(surface, (16, 36, 26), slot_rect, border_radius=10)
                self._draw_dashed_rect(surface, slot_rect, (90, 130, 100), 2, dash=8)
                joker_lbl = render_text("JOKER", 24, (110, 150, 120), bold=True)
                # Tilt 90° so it reads vertically like the reference
                joker_lbl = pygame.transform.rotate(joker_lbl, 90)
                surface.blit(joker_lbl, joker_lbl.get_rect(center=slot_rect.center))

    # ------------------------------------------------------------------- #
    # Centered "Score at least" display
    # ------------------------------------------------------------------- #
    def _draw_center_target(self, surface):
        run = self.run
        # Place between joker row and the play area
        middle_x = self.LEFT_PANEL_X + self.LEFT_PANEL_W
        middle_w = self.RIGHT_PANEL_X - middle_x
        cx = middle_x + middle_w // 2
        cy = self.JOKER_ROW_Y + self.JOKER_SLOT_H + 70

        # "Score at least"
        sa = render_text("Score at least", 26, (235, 235, 230))
        surface.blit(sa, sa.get_rect(center=(cx, cy - 38)))

        # Big chip + target number
        target_val = run.current_blind.score_target if run.current_blind else 0
        target_str = str(target_val)
        target_surf = render_text(target_str, 80, C.BLOOD_BRIGHT, bold=True)
        # Chip on the left, number on the right
        total_w = 60 + 16 + target_surf.get_width()
        start_x = cx - total_w // 2
        self._draw_chip_icon(surface, (start_x + 26, cy + 4), 26, (170, 40, 50))
        surface.blit(target_surf, (start_x + 60 + 16, cy - target_surf.get_height() // 2))

        # Reward indicator
        reward = run.current_blind.reward if run.current_blind else 0
        reward_str = "$" * min(5, max(1, reward))
        rwd_text = render_text(f"Reward: ", 16, (220, 220, 215))
        rwd_dollars = render_text(reward_str, 20, C.GOLD_BRIGHT, bold=True)
        rwd_total = rwd_text.get_width() + rwd_dollars.get_width()
        rwd_x = cx - rwd_total // 2
        rwd_y = cy + 54
        surface.blit(rwd_text, (rwd_x, rwd_y))
        surface.blit(rwd_dollars, (rwd_x + rwd_text.get_width(), rwd_y - 2))

        # Score progress bar
        bar_w = 360
        bar = pygame.Rect(cx - bar_w // 2, cy + 90, bar_w, 12)
        pygame.draw.rect(surface, (10, 30, 20), bar, border_radius=6)
        target_safe = max(1, target_val)
        prog = min(1.0, self.score_tween.value / target_safe)
        if prog > 0:
            fill = bar.copy()
            fill.width = max(2, int(bar.width * prog))
            pygame.draw.rect(surface, C.BLOOD_BRIGHT, fill, border_radius=6)
        pygame.draw.rect(surface, C.GOLD_DIM, bar, 1, border_radius=6)
        prog_txt = render_text(
            f"{self.score_tween.display_int} / {target_val}",
            14, (220, 220, 215),
        )
        surface.blit(prog_txt, prog_txt.get_rect(midtop=(bar.centerx, bar.bottom + 4)))

    # ------------------------------------------------------------------- #
    # Right side panel: round stats + play/discard buttons + deck visual
    # ------------------------------------------------------------------- #
    def _draw_right_sidebar(self, surface):
        run = self.run
        x = self.RIGHT_PANEL_X
        w = self.RIGHT_PANEL_W

        # MENU button position already set in __init__ (drawn in draw_scene)

        # Round stats panel
        rp = pygame.Rect(x + 6, 84, w - 12, 220)
        self._draw_table_panel(surface, rp, (12, 14, 18), C.BLOOD_DIM)
        hdr = render_text("ROUND", 18, C.GOLD_BRIGHT, bold=True)
        surface.blit(hdr, (rp.x + 12, rp.y + 8))
        row_y = rp.y + 40
        # Hands
        h_lbl = render_text("Hands", 18, (220, 220, 215))
        h_val = render_text(str(run.hands_left), 22, C.BLUE_INFO, bold=True)
        surface.blit(h_lbl, (rp.x + 14, row_y))
        surface.blit(h_val, h_val.get_rect(topright=(rp.right - 14, row_y - 2)))
        # Discards
        row_y += 40
        d_lbl = render_text("Discards", 18, (220, 220, 215))
        d_val = render_text(str(run.discards_left), 22, C.BLOOD_BRIGHT, bold=True)
        surface.blit(d_lbl, (rp.x + 14, row_y))
        surface.blit(d_val, d_val.get_rect(topright=(rp.right - 14, row_y - 2)))
        # Money
        row_y += 40
        m_lbl = render_text("$", 22, (220, 220, 215), bold=True)
        m_val = render_text(str(self.money_tween.display_int), 22, C.GOLD_BRIGHT, bold=True)
        surface.blit(m_lbl, (rp.x + 14, row_y - 2))
        surface.blit(m_val, m_val.get_rect(topright=(rp.right - 14, row_y - 2)))

        # Deck visual — stack of card backs at bottom-right
        self._draw_deck_visual(surface)

    def _draw_deck_visual(self, surface):
        x = self.RIGHT_PANEL_X
        w = self.RIGHT_PANEL_W
        # Stack of card backs at the bottom of the right panel
        deck_w = int(CARD_WIDTH * 0.85)
        deck_h = int(CARD_HEIGHT * 0.85)
        center_x = x + w // 2
        bottom_y = WINDOW_HEIGHT - 40
        back = self.game.assets.get_card_back()
        scaled_back = pygame.transform.smoothscale(back, (deck_w, deck_h))
        # Stack 3 offsets
        for i in range(3, -1, -1):
            ox = -i * 2
            oy = -i * 3
            r = scaled_back.get_rect(midbottom=(center_x + ox, bottom_y + oy))
            surface.blit(scaled_back, r)
        # Card count below
        deck_size = self.run.deck.size
        total = max(deck_size, 1)
        count_txt = render_text(f"{len(self.run.deck.cards)}/{deck_size}",
                                14, (235, 235, 230), bold=True)
        surface.blit(count_txt, count_txt.get_rect(midtop=(center_x, bottom_y + 4)))

    # ------------------------------------------------------------------- #
    # Small drawing primitives reused by the sidebars
    # ------------------------------------------------------------------- #
    def _draw_table_panel(self, surface, rect, fill_color, border_color):
        """Dark inset panel sitting on top of the green felt."""
        body = pygame.Surface(rect.size, pygame.SRCALPHA)
        pygame.draw.rect(body, (*fill_color, 235), body.get_rect(), border_radius=10)
        pygame.draw.rect(body, border_color, body.get_rect(), 2, border_radius=10)
        surface.blit(body, rect.topleft)

    def _draw_stat_pill(self, surface, rect, label, value, accent):
        """Compact label-over-value pill used in the side panels."""
        pygame.draw.rect(surface, (10, 8, 14), rect, border_radius=8)
        pygame.draw.rect(surface, accent, rect, 1, border_radius=8)
        lbl = render_text(label, 13, (200, 200, 200), bold=True)
        surface.blit(lbl, lbl.get_rect(midtop=(rect.centerx, rect.y + 4)))
        val = render_text(value, 22, accent, bold=True)
        surface.blit(val, val.get_rect(midbottom=(rect.centerx, rect.bottom - 4)))

    def _draw_chip_icon(self, surface, center, radius, color):
        """Simple stylised poker chip: outer ring, inner solid, four notch marks."""
        cx, cy = center
        # Drop shadow
        shadow = pygame.Surface((radius * 2 + 6, radius * 2 + 6), pygame.SRCALPHA)
        pygame.draw.circle(shadow, (0, 0, 0, 110), (radius + 3, radius + 3), radius + 1)
        surface.blit(shadow, (cx - radius - 3, cy - radius))
        # Outer ring (lighter)
        pygame.draw.circle(surface, color, (cx, cy), radius)
        pygame.draw.circle(surface, (245, 240, 230), (cx, cy), radius, 2)
        # Four notch marks at 12/3/6/9 o'clock
        notch_col = (245, 240, 230)
        nl = max(2, radius // 5)
        pygame.draw.rect(surface, notch_col, (cx - 1, cy - radius - 1, 2, nl + 2))
        pygame.draw.rect(surface, notch_col, (cx - 1, cy + radius - nl - 1, 2, nl + 2))
        pygame.draw.rect(surface, notch_col, (cx - radius - 1, cy - 1, nl + 2, 2))
        pygame.draw.rect(surface, notch_col, (cx + radius - nl - 1, cy - 1, nl + 2, 2))
        # Inner darker dot
        pygame.draw.circle(surface, (*color, 0)[:3], (cx, cy), max(2, radius - 6))
        inner_col = tuple(max(0, c - 30) for c in color)
        pygame.draw.circle(surface, inner_col, (cx, cy), max(2, radius - 6))
        pygame.draw.circle(surface, (245, 240, 230), (cx, cy), max(2, radius - 6), 1)

    def _draw_dashed_rect(self, surface, rect, color, thickness=2, dash=6):
        """Dashed rectangle outline (for empty joker slot frames)."""
        x, y, w, h = rect
        # Top and bottom edges
        for i in range(0, w, dash * 2):
            pygame.draw.line(surface, color, (x + i, y),
                             (min(x + i + dash, x + w), y), thickness)
            pygame.draw.line(surface, color, (x + i, y + h - 1),
                             (min(x + i + dash, x + w), y + h - 1), thickness)
        # Left and right edges
        for i in range(0, h, dash * 2):
            pygame.draw.line(surface, color, (x, y + i),
                             (x, min(y + i + dash, y + h)), thickness)
            pygame.draw.line(surface, color, (x + w - 1, y + i),
                             (x + w - 1, min(y + i + dash, y + h)), thickness)

    # ----- Hand zone (felt panel under the bottom row) ----- #
    def _draw_hand_zone(self, surface):
        n = len(self.run.hand)
        if n == 0:
            return
        total_w = n * CARD_WIDTH + (n - 1) * CARD_GAP
        zone_pad_x = 36
        zone_pad_y = 24
        zone = pygame.Rect(
            WINDOW_WIDTH // 2 - total_w // 2 - zone_pad_x,
            self.hand_y - zone_pad_y,
            total_w + zone_pad_x * 2,
            CARD_HEIGHT + zone_pad_y * 2,
        )
        # Vertical gradient (top darker, bottom lighter — feels like felt with light from below)
        bg = pygame.Surface((zone.width, zone.height), pygame.SRCALPHA)
        for y in range(zone.height):
            t = y / max(1, zone.height - 1)
            a = int(160 + 50 * t)
            pygame.draw.line(bg, (10, 6, 12, a), (0, y), (zone.width, y))
        # Round the panel
        mask = pygame.Surface(bg.get_size(), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=14)
        bg.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        surface.blit(bg, zone.topleft)
        # Gold border
        pygame.draw.rect(surface, C.GOLD_DIM, zone, 2, border_radius=14)
        # Faint felt cross-hatch
        hatch = pygame.Surface((zone.width, zone.height), pygame.SRCALPHA)
        for i in range(-zone.height, zone.width, 18):
            pygame.draw.line(hatch, (90, 30, 40, 16), (i, 0), (i + zone.height, zone.height), 1)
        surface.blit(hatch, zone.topleft)

    # ----- Play area felt (where played cards land during scoring) ----- #
    def _draw_play_area(self, surface):
        zone = pygame.Rect(
            WINDOW_WIDTH // 2 - 360, self.play_y - 30,
            720, CARD_HEIGHT + 60,
        )
        bg = pygame.Surface((zone.width, zone.height), pygame.SRCALPHA)
        # Gentle radial-ish gradient (vertical falloff from center)
        for y in range(zone.height):
            ny = (y - zone.height / 2) / (zone.height / 2)
            a = int(70 * (1.0 - min(1.0, abs(ny))))
            pygame.draw.line(bg, (140, 30, 40, a), (0, y), (zone.width, y))
        mask = pygame.Surface(bg.get_size(), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=18)
        bg.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        surface.blit(bg, zone.topleft)
        # Subtle dashed gold border
        for i in range(0, zone.width, 14):
            seg = pygame.Rect(zone.x + i, zone.y, 8, 1)
            pygame.draw.rect(surface, C.GOLD_DIM, seg)
            seg2 = pygame.Rect(zone.x + i, zone.bottom - 1, 8, 1)
            pygame.draw.rect(surface, C.GOLD_DIM, seg2)

    def _draw_hand_name(self, surface):
        """
        Center-screen banner — Balatro-style. Big bold gold text with a red
        drop shadow, a soft red aura glow ring, and a scale-pop on entry.
        """
        t = self.hand_name_t
        if t < 0.5:
            s = ease_out_back(t * 2) * 1.0
        else:
            s = 1.0 + (1.0 - (t - 0.5) * 2) * 0.05
        alpha = int(255 * min(1.0, 1.0 - max(0.0, (t - 0.85) / 0.15)))
        text = self.hand_name_text

        font = get_font(72, bold=True)
        surf = font.render(text, True, C.GOLD_BRIGHT)
        w, h = surf.get_size()
        new_w, new_h = max(1, int(w * s)), max(1, int(h * s))
        surf = pygame.transform.smoothscale(surf, (new_w, new_h))
        surf.set_alpha(alpha)
        center = (WINDOW_WIDTH // 2, self.play_y - 90)
        rect = surf.get_rect(center=center)

        # Aura glow ring behind the text — soft red, scales with the pop.
        aura = pygame.Surface((new_w + 80, new_h + 60), pygame.SRCALPHA)
        for i in range(6, 0, -1):
            ar = i * 6
            a = int(28 * alpha / 255)
            pygame.draw.rect(aura, (170, 30, 40, a),
                             aura.get_rect().inflate(-ar * 2, -ar * 2),
                             border_radius=ar)
        surface.blit(aura, aura.get_rect(center=center))

        # Hard red drop shadow then the gold front.
        sh = font.render(text, True, (60, 6, 12))
        sh = pygame.transform.smoothscale(sh, (new_w, new_h))
        sh.set_alpha(int(alpha * 0.7))
        surface.blit(sh, sh.get_rect(center=(rect.centerx + 4, rect.centery + 4)))
        surface.blit(surf, rect)

    def _draw_menu(self, surface):
        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        surface.blit(overlay, (0, 0))
        panel = pygame.Rect(WINDOW_WIDTH // 2 - 200, WINDOW_HEIGHT // 2 - 140, 400, 280)
        draw_panel(surface, panel, "PAUSED")
        for b in self.menu_buttons:
            b.draw(surface)


# ============================================================================ #
# Shop screen with slide-in stagger and money tween
# ============================================================================ #
class ShopScreen(Screen):
    """
    Two-section shop:
      * JOKERS & CARDS row    — 4 small single-purchase items
      * BOOSTER PACKS row     — 2 larger packs that reveal 2-5 picks on open

    States:
      * BROWSING      default — both sections visible
      * OPENING       just bought a pack; pack icon flies + bursts (~0.5s)
      * CHOOSING      revealed items shown; click one to take it
      * CLOSING       picked item flashes; pack disappears (~0.4s)

    Each phase reuses the same animation primitives (Pulse, damp, ease_out_back)
    the rest of the UI uses, so the feel is consistent.
    """

    MUSIC_INTENSITY = "low"
    ENTER_DURATION = 0.55

    # Section layout — single source of truth for both code and layout helpers.
    ITEMS_Y     = 252
    ITEM_W      = 140
    ITEM_H      = 170
    ITEM_GAP    = 24
    PACKS_Y     = 470
    PACK_W      = 230
    PACK_H      = 180
    PACK_GAP    = 60
    SECTION_HEADER_OFFSET = -36

    # Phases
    PHASE_BROWSING = "browsing"
    PHASE_OPENING  = "opening"
    PHASE_CHOOSING = "choosing"
    PHASE_CLOSING  = "closing"

    def __init__(self, game):
        super().__init__(game)
        self.run = game.run
        owned_ids = [j.joker_id for j in self.run.jokers]
        self.shop = Shop(self.run.rng,
                         self.game.stats.get("unlocked_jokers", []),
                         owned_ids)

        self.item_rects: List[pygame.Rect] = []
        self.pack_rects: List[pygame.Rect] = []
        self._layout_items()
        self._layout_packs()

        # Buttons
        self.leave_btn = Button(
            pygame.Rect(WINDOW_WIDTH - 200, WINDOW_HEIGHT - 80, 160, 50),
            "LEAVE SHOP", on_click=self._leave, color_border=C.GOLD,
        )
        self.reroll_btn = Button(
            pygame.Rect(40, WINDOW_HEIGHT - 80, 200, 50),
            f"REROLL  ${self.shop.reroll_price()}", on_click=self._reroll,
        )

        # Per-item animation state
        self.item_slide_t  = [0.0] * len(self.shop.items)
        self.item_hover_t  = [0.0] * len(self.shop.items)
        self.item_pulses   = [Pulse(decay=0.42) for _ in self.shop.items]
        self.item_flash    = [0.0] * len(self.shop.items)

        # Per-pack animation state
        self.pack_slide_t  = [0.0] * len(self.shop.packs)
        self.pack_hover_t  = [0.0] * len(self.shop.packs)
        self.pack_pulses   = [Pulse(decay=0.42) for _ in self.shop.packs]
        # Idle shimmer offset per pack — slowly drifts across the foil texture.
        self._shimmer_t    = 0.0

        # Pack-opening state
        self.phase = self.PHASE_BROWSING
        self.opening_pack: Optional[BoosterPack] = None
        self.opening_pack_idx: Optional[int] = None
        self.opening_t = 0.0           # 0..1 over opening animation
        self.reveal_t = 0.0            # 0..1 over reveal stagger
        self.closing_t = 0.0           # 0..1 over closing fade
        self.choosing_contents: List = []
        self.choosing_content_rects: List[pygame.Rect] = []
        self.choosing_content_hover_t: List[float] = []
        self.choosing_content_pulses: List[Pulse] = []
        self.chosen_idx: Optional[int] = None

        # Skip button for the choose phase (built on demand)
        self.skip_btn = Button(
            pygame.Rect(WINDOW_WIDTH // 2 - 90, WINDOW_HEIGHT - 100, 180, 44),
            "SKIP PACK", on_click=self._skip_pack, color_border=C.BLOOD,
        )

        # Hover index across both rows (single hovered thing at a time)
        # Stored as ('item', idx) or ('pack', idx) or None
        self._hover_target: Optional[tuple] = None

        # Money + tooltip
        self.money_tween = NumberTween(self.run.money, speed=8.0)
        self.tooltip_text: Optional[List[str]] = None
        self.tooltip_pos = (0, 0)
        self.tooltip_alpha = 0.0

        # Soft entry particle
        self.anim.particles.burst_fan(
            WINDOW_WIDTH // 2, 250, C.GOLD, C.BLOOD, count=14, speed=180, lifetime=0.7,
        )

    # ----- Layout ----- #
    def _layout_items(self):
        self.item_rects = []
        n = len(self.shop.items)
        if n == 0:
            return
        total = n * self.ITEM_W + (n - 1) * self.ITEM_GAP
        start_x = WINDOW_WIDTH // 2 - total // 2
        for i in range(n):
            x = start_x + i * (self.ITEM_W + self.ITEM_GAP)
            self.item_rects.append(pygame.Rect(x, self.ITEMS_Y, self.ITEM_W, self.ITEM_H))

    def _layout_packs(self):
        self.pack_rects = []
        n = len(self.shop.packs)
        if n == 0:
            return
        total = n * self.PACK_W + (n - 1) * self.PACK_GAP
        start_x = WINDOW_WIDTH // 2 - total // 2
        for i in range(n):
            x = start_x + i * (self.PACK_W + self.PACK_GAP)
            self.pack_rects.append(pygame.Rect(x, self.PACKS_Y, self.PACK_W, self.PACK_H))

    def _layout_content_rects(self, n: int):
        """Layout for the revealed items inside an opened pack."""
        w, h = 150, 200
        gap = 26
        total = n * w + (n - 1) * gap
        start_x = WINDOW_WIDTH // 2 - total // 2
        y = WINDOW_HEIGHT // 2 - h // 2
        return [pygame.Rect(start_x + i * (w + gap), y, w, h) for i in range(n)]

    # ----- Actions ----- #
    def _reroll(self):
        if self.phase != self.PHASE_BROWSING:
            return
        price = self.shop.reroll_price()
        if self.run.money < price:
            return
        self.run.money -= price
        self.shop.reroll()
        self.reroll_btn.label = f"REROLL  ${self.shop.reroll_price()}"
        self._layout_items()
        self._layout_packs()
        # Reset animation state
        self.item_slide_t = [0.0] * len(self.shop.items)
        self.item_hover_t = [0.0] * len(self.shop.items)
        self.item_pulses  = [Pulse(decay=0.42) for _ in self.shop.items]
        self.item_flash   = [0.0] * len(self.shop.items)
        self.pack_slide_t = [0.0] * len(self.shop.packs)
        self.pack_hover_t = [0.0] * len(self.shop.packs)
        self.pack_pulses  = [Pulse(decay=0.42) for _ in self.shop.packs]
        self._hover_target = None
        self.enter_t = 0.0
        self.game.sounds.play("reroll")

    def _leave(self):
        if self.phase != self.PHASE_BROWSING:
            return
        self.game.sounds.play("click")
        self.game.save_current_run()
        self.game.switch_to("blind")

    def _try_buy_item(self, idx: int):
        item = self.shop.items[idx]
        if item.sold or self.run.money < item.price:
            return
        if item.kind == "joker" and len(self.run.jokers) >= self.run.max_joker_slots:
            return
        self.run.money -= item.price
        self.shop.buy(item, self.run)
        self.item_pulses[idx].trigger(0.30)
        self.item_flash[idx] = 1.0
        self.anim.particles.burst_sparks(
            self.item_rects[idx].centerx, self.item_rects[idx].centery,
            C.GOLD_BRIGHT, count=14, speed=220,
        )
        self.anim.add_shake(0.18)
        self.game.sounds.play("buy")

    def _try_buy_pack(self, idx: int):
        pack = self.shop.packs[idx]
        if pack.sold or self.run.money < pack.price:
            return
        self.run.money -= pack.price
        pack.sold = True
        # Begin opening flow
        self.opening_pack = pack
        self.opening_pack_idx = idx
        self.opening_t = 0.0
        self.reveal_t = 0.0
        self.closing_t = 0.0
        self.chosen_idx = None
        self.phase = self.PHASE_OPENING
        self.choosing_contents = self.shop.open_pack(pack)
        self.choosing_content_rects = self._layout_content_rects(len(self.choosing_contents))
        self.choosing_content_hover_t = [0.0] * len(self.choosing_contents)
        self.choosing_content_pulses = [Pulse(decay=0.40) for _ in self.choosing_contents]
        # Bigger reaction than buying a single item — packs are a moment.
        self.pack_pulses[idx].trigger(0.40)
        self.anim.particles.burst_fan(
            self.pack_rects[idx].centerx, self.pack_rects[idx].centery,
            self._pack_glow_color(pack), C.GOLD_BRIGHT,
            count=22, speed=260, lifetime=0.9,
        )
        self.anim.add_shake(0.30)
        self.game.sounds.play("buy")
        self.game.audio.play_sfx("card_legendary", volume=0.8)

    def _choose_content(self, idx: int):
        if self.phase != self.PHASE_CHOOSING:
            return
        if idx < 0 or idx >= len(self.choosing_contents):
            return
        item = self.choosing_contents[idx]
        # Take the item — same plumbing as buying, but free.
        ok = self.shop.take_pack_item(item, self.run)
        if not ok:
            # Joker slot full → bounce the panel to communicate "can't"
            self.choosing_content_pulses[idx].trigger(0.18)
            return
        self.chosen_idx = idx
        self.choosing_content_pulses[idx].trigger(0.45)
        self.anim.particles.burst_sparks(
            self.choosing_content_rects[idx].centerx,
            self.choosing_content_rects[idx].centery,
            C.GOLD_BRIGHT, count=20, speed=260,
        )
        self.anim.add_shake(0.22)
        self.game.sounds.play("buy")
        self.phase = self.PHASE_CLOSING
        self.closing_t = 0.0

    def _skip_pack(self):
        if self.phase != self.PHASE_CHOOSING:
            return
        self.game.sounds.play("click")
        self.chosen_idx = None
        self.phase = self.PHASE_CLOSING
        self.closing_t = 0.0

    def _finish_closing(self):
        """Called when the close animation finishes — return to browsing."""
        self.opening_pack = None
        self.opening_pack_idx = None
        self.choosing_contents = []
        self.choosing_content_rects = []
        self.choosing_content_hover_t = []
        self.choosing_content_pulses = []
        self.chosen_idx = None
        self.phase = self.PHASE_BROWSING

    # ----- Events ----- #
    def handle_events(self, events):
        for e in events:
            if self.phase == self.PHASE_BROWSING:
                self.leave_btn.handle_event(e)
                self.reroll_btn.handle_event(e)
                if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                    self._leave()
                if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                    for i, r in enumerate(self.item_rects):
                        if r.collidepoint(e.pos):
                            self._try_buy_item(i)
                    for i, r in enumerate(self.pack_rects):
                        if r.collidepoint(e.pos):
                            self._try_buy_pack(i)
            elif self.phase == self.PHASE_CHOOSING:
                self.skip_btn.handle_event(e)
                if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                    self._skip_pack()
                if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                    for i, r in enumerate(self.choosing_content_rects):
                        if r.collidepoint(e.pos):
                            self._choose_content(i)
        # Reroll affordability check stays live
        self.reroll_btn.disabled = (
            self.phase != self.PHASE_BROWSING or
            self.run.money < self.shop.reroll_price()
        )

    # ----- Update ----- #
    def update(self, dt):
        super().update(dt)
        self.money_tween.set(self.run.money)
        self.money_tween.update(dt)
        self._shimmer_t += dt

        # Slide-in stagger — items then packs.
        for i in range(len(self.item_slide_t)):
            delay = i * 0.08
            t = max(0.0, self.enter_t * 1.30 - delay)
            self.item_slide_t[i] = min(1.0, t)
        for i in range(len(self.pack_slide_t)):
            delay = (len(self.item_slide_t) * 0.06) + i * 0.12
            t = max(0.0, self.enter_t * 1.30 - delay)
            self.pack_slide_t[i] = min(1.0, t)

        # Update all per-thing pulses
        for p in self.item_pulses + self.pack_pulses:
            p.update(dt)
        for p in self.choosing_content_pulses:
            p.update(dt)
        for i in range(len(self.item_flash)):
            if self.item_flash[i] > 0:
                self.item_flash[i] = max(0.0, self.item_flash[i] - dt * 2.6)

        # Phase-specific hover detection + tooltip
        if self.phase == self.PHASE_BROWSING:
            self._update_browsing_hover(dt)
        elif self.phase == self.PHASE_CHOOSING:
            self._update_choosing_hover(dt)
        else:
            # During OPENING / CLOSING, no hover handling — fade tooltip out.
            for i in range(len(self.item_hover_t)):
                self.item_hover_t[i] = damp(self.item_hover_t[i], 0.0, 14.0, dt)
            for i in range(len(self.pack_hover_t)):
                self.pack_hover_t[i] = damp(self.pack_hover_t[i], 0.0, 14.0, dt)
            self.tooltip_alpha = damp(self.tooltip_alpha, 0.0, 14.0, dt)

        # Phase progression
        if self.phase == self.PHASE_OPENING:
            self.opening_t = min(1.0, self.opening_t + dt / 0.50)
            if self.opening_t >= 1.0:
                self.phase = self.PHASE_CHOOSING
                self.reveal_t = 0.0
        elif self.phase == self.PHASE_CHOOSING:
            self.reveal_t = min(1.0, self.reveal_t + dt / 0.55)
        elif self.phase == self.PHASE_CLOSING:
            self.closing_t = min(1.0, self.closing_t + dt / 0.50)
            if self.closing_t >= 1.0:
                self._finish_closing()

    def _update_browsing_hover(self, dt):
        mouse_pos = pygame.mouse.get_pos()
        hovered: Optional[tuple] = None
        # Packs first so a slight overlap doesn't ghost-hover the item below.
        for i, r in enumerate(self.pack_rects):
            if r.collidepoint(mouse_pos) and self.pack_slide_t[i] > 0.5 and not self.shop.packs[i].sold:
                hovered = ("pack", i)
                break
        if hovered is None:
            for i, r in enumerate(self.item_rects):
                if r.collidepoint(mouse_pos) and self.item_slide_t[i] > 0.5 and not self.shop.items[i].sold:
                    hovered = ("item", i)
                    break
        self._hover_target = hovered

        for i in range(len(self.item_hover_t)):
            target = 1.0 if hovered == ("item", i) else 0.0
            self.item_hover_t[i] = damp(self.item_hover_t[i], target, 14.0, dt)
        for i in range(len(self.pack_hover_t)):
            target = 1.0 if hovered == ("pack", i) else 0.0
            self.pack_hover_t[i] = damp(self.pack_hover_t[i], target, 14.0, dt)

        # Tooltip text + smooth fade
        if hovered is not None:
            kind, i = hovered
            if kind == "item":
                it = self.shop.items[i]
                r = self.item_rects[i]
                self.tooltip_text = [it.name, "", it.description]
            else:
                pk = self.shop.packs[i]
                r = self.pack_rects[i]
                self.tooltip_text = [pk.name, "", pk.hint]
            self.tooltip_pos = (r.centerx + r.width // 2 + 12, r.centery)
            self.tooltip_alpha = damp(self.tooltip_alpha, 1.0, 18.0, dt)
        else:
            self.tooltip_alpha = damp(self.tooltip_alpha, 0.0, 14.0, dt)
            if self.tooltip_alpha < 0.02:
                self.tooltip_text = None

    def _update_choosing_hover(self, dt):
        mouse_pos = pygame.mouse.get_pos()
        hovered_idx = None
        for i, r in enumerate(self.choosing_content_rects):
            if r.collidepoint(mouse_pos):
                hovered_idx = i
                break
        for i in range(len(self.choosing_content_hover_t)):
            target = 1.0 if i == hovered_idx else 0.0
            self.choosing_content_hover_t[i] = damp(self.choosing_content_hover_t[i], target, 14.0, dt)
        # Tooltip on pack contents too
        if hovered_idx is not None:
            it = self.choosing_contents[hovered_idx]
            r = self.choosing_content_rects[hovered_idx]
            self.tooltip_text = [it.name, "", it.description]
            self.tooltip_pos = (r.centerx + r.width // 2 + 14, r.centery)
            self.tooltip_alpha = damp(self.tooltip_alpha, 1.0, 18.0, dt)
        else:
            self.tooltip_alpha = damp(self.tooltip_alpha, 0.0, 14.0, dt)
            if self.tooltip_alpha < 0.02:
                self.tooltip_text = None

    # ----- Pack visual colors per rarity ----- #
    @staticmethod
    def _pack_glow_color(pack: BoosterPack):
        return {
            "common":    (210, 160, 50),
            "rare":      (140, 80, 220),
            "legendary": (220, 60, 90),
        }.get(pack.rarity, C.GOLD)

    @staticmethod
    def _pack_border_color(pack: BoosterPack):
        return {
            "common":    C.GOLD,
            "rare":      C.PURPLE_RARE,
            "legendary": C.BLOOD_BRIGHT,
        }.get(pack.rarity, C.GOLD)

    # ----- Draw ----- #
    def draw_scene(self, surface):
        run = self.run
        _draw_top_hud(surface, run, self.game,
                      money_display=self.money_tween.display_int,
                      score_display=run.round_score)

        # Section: JOKERS & CARDS
        self._draw_section_header(
            surface, "JOKERS & CARDS",
            (WINDOW_WIDTH // 2, self.ITEMS_Y + self.SECTION_HEADER_OFFSET),
        )
        for i, item in enumerate(self.shop.items):
            self._draw_item(surface, i, item)

        # Section: BOOSTER PACKS
        self._draw_section_header(
            surface, "BOOSTER PACKS",
            (WINDOW_WIDTH // 2, self.PACKS_Y + self.SECTION_HEADER_OFFSET),
            color=C.GOLD_BRIGHT,
        )
        for i, pack in enumerate(self.shop.packs):
            self._draw_pack(surface, i, pack)

        # Browsing buttons (hidden during pack flow)
        if self.phase == self.PHASE_BROWSING:
            self.leave_btn.draw(surface)
            self.reroll_btn.draw(surface)

        # Pack opening + choose overlay
        if self.phase in (self.PHASE_OPENING, self.PHASE_CHOOSING, self.PHASE_CLOSING):
            self._draw_pack_overlay(surface)

        # Tooltip last so it sits on top of everything
        if self.tooltip_text and self.tooltip_alpha > 0.01:
            draw_tooltip(surface, self.tooltip_pos, self.tooltip_text,
                         alpha=self.tooltip_alpha)

    # ----- Section header ----- #
    def _draw_section_header(self, surface, text, center, color=C.GOLD):
        lbl = render_text(text, 22, color, bold=True)
        # Decorative thin gold rules either side
        cx, cy = center
        w = lbl.get_width()
        rule_pad = 14
        rule_len = 80
        pygame.draw.line(surface, C.GOLD_DIM,
                         (cx - w // 2 - rule_pad - rule_len, cy),
                         (cx - w // 2 - rule_pad, cy), 1)
        pygame.draw.line(surface, C.GOLD_DIM,
                         (cx + w // 2 + rule_pad, cy),
                         (cx + w // 2 + rule_pad + rule_len, cy), 1)
        # Drop shadow
        sh = render_text(text, 22, (0, 0, 0), bold=True)
        surface.blit(sh, sh.get_rect(center=(cx + 1, cy + 1)))
        surface.blit(lbl, lbl.get_rect(center=center))

    # ----- Single item card ----- #
    def _draw_item(self, surface, i, item):
        base_rect = self.item_rects[i]
        slide_t = self.item_slide_t[i]
        slide_eased = ease_out_back(slide_t)
        alpha = int(255 * min(1.0, slide_t * 2))
        hover_t = self.item_hover_t[i]
        pulse_val = self.item_pulses[i].value
        scale = pulse_val + 0.05 * hover_t
        hover_lift = -10 * hover_t

        scaled_w = int(base_rect.width * scale)
        scaled_h = int(base_rect.height * scale)
        r = pygame.Rect(0, 0, scaled_w, scaled_h)
        r.centerx = base_rect.centerx
        r.bottom = int(base_rect.bottom + (1.0 - slide_eased) * 90 + hover_lift)

        sold = item.sold

        # Hover glow
        if hover_t > 0.04 and not sold:
            self._draw_hover_glow(surface, r, hover_t, C.GOLD)

        # Panel
        bg = C.BG_PANEL_HI if not sold else C.BG_PANEL
        border = C.GOLD if not sold else C.BORDER
        panel = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
        pygame.draw.rect(panel, bg, panel.get_rect(), border_radius=10)
        pygame.draw.rect(panel, border, panel.get_rect(), 2, border_radius=10)
        panel.set_alpha(alpha)
        surface.blit(panel, r.topleft)

        if alpha > 60:
            self._draw_item_contents(surface, r, item, scale, sold)

        # Buy flash
        if self.item_flash[i] > 0.01:
            fl = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
            a = int(180 * self.item_flash[i])
            pygame.draw.rect(fl, (255, 220, 120, a), fl.get_rect(), border_radius=10)
            surface.blit(fl, r.topleft, special_flags=pygame.BLEND_RGBA_ADD)

    def _draw_item_contents(self, surface, r, item, scale, sold):
        # Icon area takes the top portion; name + price below
        icon_y_center = r.y + int(r.height * 0.34)
        if item.kind == "joker":
            icon = self.game.assets.get_joker(item.payload)
            if scale != 1.0:
                iw, ih = icon.get_size()
                icon = pygame.transform.smoothscale(
                    icon, (max(8, int(iw * 0.85 * scale)), max(8, int(ih * 0.85 * scale)))
                )
            surface.blit(icon, icon.get_rect(center=(r.centerx, icon_y_center)))
        elif item.kind == "add_card" and isinstance(item.payload, Card):
            card_img = self.game.assets.get_card(item.payload.rank, item.payload.suit)
            if scale != 1.0:
                cw, ch = card_img.get_size()
                card_img = pygame.transform.smoothscale(
                    card_img, (max(8, int(cw * 0.85 * scale)), max(8, int(ch * 0.85 * scale)))
                )
            card_rect = card_img.get_rect(center=(r.centerx, icon_y_center))
            surface.blit(card_img, card_rect)
            # Modifier overlay on the card if present (e.g. shop-rolled Foil Ace)
            if item.payload.modifier is not None:
                draw_card_modifier_overlay(surface, card_rect, item.payload.modifier)
        else:
            env_w, env_h = int(58 * scale), int(76 * scale)
            env = pygame.Rect(0, 0, env_w, env_h)
            env.center = (r.centerx, icon_y_center)
            pygame.draw.rect(surface, C.BLOOD_DIM, env, border_radius=6)
            pygame.draw.rect(surface, C.GOLD_DIM, env, 2, border_radius=6)
            glyph = render_text("?", max(20, int(40 * scale)), C.GOLD, bold=True)
            surface.blit(glyph, glyph.get_rect(center=env.center))

        # Name + price (compact for small items)
        name_size = max(11, int(15 * scale))
        name_surf = render_text(item.name, name_size, C.GOLD, bold=True)
        if name_surf.get_width() > r.width - 8:
            name_surf = render_text(item.name, max(10, int(13 * scale)), C.GOLD, bold=True)
        name_y = r.y + int(r.height * 0.66)
        surface.blit(name_surf, name_surf.get_rect(midtop=(r.centerx, name_y)))

        price_color = C.GREEN_GOOD if self.run.money >= item.price else C.BLOOD_BRIGHT
        price_size = max(14, int(20 * scale))
        price_surf = render_text(f"${item.price}", price_size, price_color, bold=True)
        surface.blit(price_surf,
                     price_surf.get_rect(midtop=(r.centerx, name_y + name_size + 8)))

        if sold:
            sold_size = max(18, int(26 * scale))
            sold_surf = render_text("SOLD", sold_size, C.BLOOD, bold=True)
            surface.blit(sold_surf, sold_surf.get_rect(center=r.center))

    # ----- Booster pack card ----- #
    def _draw_pack(self, surface, i, pack: BoosterPack):
        base_rect = self.pack_rects[i]
        slide_t = self.pack_slide_t[i]
        slide_eased = ease_out_back(slide_t)
        alpha = int(255 * min(1.0, slide_t * 2))
        hover_t = self.pack_hover_t[i]
        pulse_val = self.pack_pulses[i].value
        # Packs scale up slightly more on hover than items — they're the showpiece.
        scale = pulse_val + 0.06 * hover_t
        hover_lift = -14 * hover_t

        scaled_w = int(base_rect.width * scale)
        scaled_h = int(base_rect.height * scale)
        r = pygame.Rect(0, 0, scaled_w, scaled_h)
        r.centerx = base_rect.centerx
        r.bottom = int(base_rect.bottom + (1.0 - slide_eased) * 120 + hover_lift)

        sold = pack.sold
        glow_col = self._pack_glow_color(pack)
        border_col = self._pack_border_color(pack)

        # Hover glow (rarity colored)
        if hover_t > 0.04 and not sold:
            self._draw_hover_glow(surface, r, hover_t, glow_col)

        # --- Foil body (distinct from regular items) -----------------------
        panel = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
        # Vertical dark-red → near-black gradient base
        for y in range(r.height):
            t = y / max(1, r.height - 1)
            col = (
                int(50 * (1 - t) + 20 * t),
                int(10 * (1 - t) + 4 * t),
                int(18 * (1 - t) + 10 * t),
            )
            pygame.draw.line(panel, col, (0, y), (r.width, y))
        # Mask the gradient to rounded corners
        mask = pygame.Surface(panel.get_size(), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=12)
        panel.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

        # Diagonal foil stripes
        for sx in range(-r.height, r.width + r.height, 22):
            pygame.draw.line(panel,
                             (border_col[0], border_col[1], border_col[2], 28),
                             (sx, 0), (sx + r.height, r.height), 1)

        # Border + inner accent
        pygame.draw.rect(panel, border_col, panel.get_rect(), 3, border_radius=12)
        pygame.draw.rect(panel, (255, 220, 120, 90),
                         panel.get_rect().inflate(-6, -6), 1, border_radius=10)

        panel.set_alpha(alpha)
        surface.blit(panel, r.topleft)

        if alpha < 60:
            return

        # --- Shimmer streak (diagonal highlight that slowly drifts) --------
        if not sold:
            shimmer_x = (math.sin(self._shimmer_t * 0.8 + i * 1.4) * 0.5 + 0.5)
            shimmer_x = int(shimmer_x * r.width)
            shimmer = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
            pygame.draw.polygon(
                shimmer, (255, 230, 160, 28),
                [
                    (shimmer_x - 24, 0), (shimmer_x + 12, 0),
                    (shimmer_x + 4, r.height), (shimmer_x - 32, r.height),
                ],
            )
            # Mask to rounded corners
            shimmer.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            surface.blit(shimmer, r.topleft, special_flags=pygame.BLEND_RGBA_ADD)

        # --- Pack glyph: ribbon "?" inside an inset frame ------------------
        frame = pygame.Rect(0, 0, int(80 * scale), int(78 * scale))
        frame.center = (r.centerx, r.y + int(r.height * 0.36))
        pygame.draw.rect(surface, (12, 6, 10), frame, border_radius=8)
        pygame.draw.rect(surface, border_col, frame, 2, border_radius=8)
        glyph_size = max(28, int(56 * scale))
        glyph = render_text("?", glyph_size, glow_col, bold=True)
        glyph_shadow = render_text("?", glyph_size, (0, 0, 0), bold=True)
        surface.blit(glyph_shadow, glyph_shadow.get_rect(center=(frame.centerx + 2, frame.centery + 3)))
        surface.blit(glyph, glyph.get_rect(center=frame.center))

        # --- Name banner ----------------------------------------------------
        name_size = max(13, int(18 * scale))
        name_surf = render_text(pack.name, name_size, glow_col, bold=True)
        name_shadow = render_text(pack.name, name_size, (0, 0, 0), bold=True)
        name_y = r.y + int(r.height * 0.66)
        surface.blit(name_shadow, name_shadow.get_rect(midtop=(r.centerx + 1, name_y + 1)))
        surface.blit(name_surf, name_surf.get_rect(midtop=(r.centerx, name_y)))

        # Hint subtext
        hint_size = max(10, int(12 * scale))
        hint_surf = render_text(pack.hint, hint_size, C.TEXT_DIM)
        surface.blit(hint_surf, hint_surf.get_rect(midtop=(r.centerx, name_y + name_size + 3)))

        # Price
        price_color = C.GREEN_GOOD if self.run.money >= pack.price else C.BLOOD_BRIGHT
        price_size = max(15, int(22 * scale))
        price_surf = render_text(f"${pack.price}", price_size, price_color, bold=True)
        surface.blit(price_surf, price_surf.get_rect(midtop=(r.centerx, name_y + name_size + hint_size + 12)))

        if sold:
            sold_size = max(20, int(28 * scale))
            sold_surf = render_text("OPENED", sold_size, C.BLOOD, bold=True)
            surface.blit(sold_surf, sold_surf.get_rect(center=r.center))

    # ----- Hover glow helper used by both items and packs ----- #
    def _draw_hover_glow(self, surface, r, hover_t, color):
        glow_pad = int(18 + 6 * hover_t)
        glow = pygame.Surface((r.width + glow_pad * 2, r.height + glow_pad * 2), pygame.SRCALPHA)
        for k, a_mul in enumerate((40, 70)):
            a = int(a_mul * hover_t)
            pygame.draw.rect(glow, (*color, a), glow.get_rect().inflate(-k * 4, -k * 4),
                             border_radius=14 + k * 2)
        surface.blit(glow, (r.x - glow_pad, r.y - glow_pad),
                     special_flags=pygame.BLEND_RGBA_ADD)

    # ----- Pack-opening overlay ----- #
    def _draw_pack_overlay(self, surface):
        # Dim the shop behind the overlay so attention focuses on the pack contents.
        if self.phase == self.PHASE_OPENING:
            dim = int(170 * self.opening_t)
        elif self.phase == self.PHASE_CHOOSING:
            dim = 170
        else:  # CLOSING
            dim = int(170 * (1.0 - self.closing_t))
        if dim > 4:
            overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, dim))
            surface.blit(overlay, (0, 0))

        # Pack title at the top of the overlay
        if self.opening_pack is not None and self.phase != self.PHASE_CLOSING:
            title_color = self._pack_border_color(self.opening_pack)
            title_size = 44
            title_surf = render_text(self.opening_pack.name, title_size, title_color, bold=True)
            title_y = 160
            # Slide title in from above during opening
            t = ease_out_back(self.opening_t)
            title_y_anim = int(title_y - 40 * (1.0 - t))
            sh = render_text(self.opening_pack.name, title_size, (0, 0, 0), bold=True)
            surface.blit(sh, sh.get_rect(center=(WINDOW_WIDTH // 2 + 3, title_y_anim + 3)))
            surface.blit(title_surf, title_surf.get_rect(center=(WINDOW_WIDTH // 2, title_y_anim)))

            sub = render_text(self.opening_pack.hint, 22, C.TEXT_DIM)
            sub.set_alpha(int(255 * self.opening_t))
            surface.blit(sub, sub.get_rect(center=(WINDOW_WIDTH // 2, title_y_anim + 34)))

        # Revealed content (or imploding selected one during CLOSING)
        if self.phase in (self.PHASE_CHOOSING, self.PHASE_CLOSING):
            for i, item in enumerate(self.choosing_contents):
                self._draw_content_card(surface, i, item)

        # Skip button during CHOOSING
        if self.phase == self.PHASE_CHOOSING and self.reveal_t > 0.6:
            self.skip_btn.draw(surface)

    def _draw_content_card(self, surface, i, item):
        base_rect = self.choosing_content_rects[i]

        # Per-card stagger reveal
        per_card_delay = 0.12 * i
        local_t = max(0.0, min(1.0, self.reveal_t * 1.4 - per_card_delay))
        reveal_eased = ease_out_back(local_t)
        alpha = int(255 * min(1.0, local_t * 2))

        hover_t = self.choosing_content_hover_t[i] if i < len(self.choosing_content_hover_t) else 0.0
        pulse_val = self.choosing_content_pulses[i].value if i < len(self.choosing_content_pulses) else 1.0
        scale = pulse_val + 0.06 * hover_t

        # Closing animation — selected card pops, others fade
        if self.phase == self.PHASE_CLOSING:
            if i == self.chosen_idx:
                # Selected: stays visible, slight extra pop
                scale *= 1.0 + 0.10 * (1.0 - self.closing_t)
                alpha = int(255 * (1.0 - self.closing_t * 0.5))
            else:
                alpha = int(alpha * max(0.0, 1.0 - self.closing_t * 1.4))
                scale *= max(0.6, 1.0 - self.closing_t * 0.3)

        scaled_w = int(base_rect.width * scale)
        scaled_h = int(base_rect.height * scale)
        r = pygame.Rect(0, 0, scaled_w, scaled_h)
        r.centerx = base_rect.centerx
        # During reveal, slide up from below for a satisfying "lift out of pack" feel
        r.bottom = int(base_rect.bottom - (1.0 - reveal_eased) * -50 + (1.0 - reveal_eased) * 30)
        r.bottom = int(base_rect.bottom + (1.0 - reveal_eased) * 30)

        # Hover glow
        if hover_t > 0.04 and self.phase == self.PHASE_CHOOSING:
            self._draw_hover_glow(surface, r, hover_t, C.GOLD_BRIGHT)

        # Panel
        panel = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
        pygame.draw.rect(panel, C.BG_PANEL_HI, panel.get_rect(), border_radius=10)
        pygame.draw.rect(panel, C.GOLD, panel.get_rect(), 2, border_radius=10)
        panel.set_alpha(alpha)
        surface.blit(panel, r.topleft)

        if alpha < 60:
            return

        # Content visuals: larger than regular shop items since they're center stage
        icon_y_center = r.y + int(r.height * 0.38)
        if item.kind == "joker":
            icon = self.game.assets.get_joker(item.payload)
            iw, ih = icon.get_size()
            icon = pygame.transform.smoothscale(icon, (int(iw * 1.0 * scale), int(ih * 1.0 * scale)))
            surface.blit(icon, icon.get_rect(center=(r.centerx, icon_y_center)))
        elif item.kind == "add_card" and isinstance(item.payload, Card):
            card_img = self.game.assets.get_card(item.payload.rank, item.payload.suit)
            cw, ch = card_img.get_size()
            card_img = pygame.transform.smoothscale(card_img, (int(cw * 1.05 * scale), int(ch * 1.05 * scale)))
            card_rect = card_img.get_rect(center=(r.centerx, icon_y_center))
            surface.blit(card_img, card_rect)
            if item.payload.modifier is not None:
                draw_card_modifier_overlay(surface, card_rect, item.payload.modifier)

        name_size = max(12, int(16 * scale))
        name_surf = render_text(item.name, name_size, C.GOLD, bold=True)
        if name_surf.get_width() > r.width - 8:
            name_surf = render_text(item.name, max(11, int(13 * scale)), C.GOLD, bold=True)
        name_y = r.y + int(r.height * 0.74)
        surface.blit(name_surf, name_surf.get_rect(midtop=(r.centerx, name_y)))

        # Subtle "FREE" label so the player understands they don't pay again
        free_surf = render_text("FREE PICK", max(10, int(12 * scale)), C.GREEN_GOOD, bold=True)
        surface.blit(free_surf, free_surf.get_rect(midtop=(r.centerx, name_y + name_size + 6)))


# ============================================================================ #
# Game over / win screens
# ============================================================================ #
class GameOverScreen(Screen):
    MUSIC_INTENSITY = "silent"  # drop the bed; the lose stinger carries the moment

    def __init__(self, game):
        super().__init__(game)
        self.t = 0.0
        self.btn = Button(
            pygame.Rect(WINDOW_WIDTH // 2 - 140, WINDOW_HEIGHT - 120, 280, 50),
            "MAIN MENU", on_click=lambda: game.switch_to("title"),
            color_border=C.GOLD,
        )
        # Dramatic entrance: dark mist
        for _ in range(3):
            self.anim.particles.loss_smoke(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 - 100)
        self.anim.add_shake(0.4)

    def handle_events(self, events):
        for e in events:
            self.btn.handle_event(e)
            if e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                self.game.switch_to("title")

    def update(self, dt):
        super().update(dt)
        self.t += dt
        # Occasional dark feather drift
        if random.random() < dt * 1.5:
            self.anim.particles.burst_feathers(
                random.uniform(0, WINDOW_WIDTH), -20,
                (30, 16, 24), count=2, speed=40, lifetime=2.0,
            )

    def draw_scene(self, surface):
        wash = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        wash.fill((90, 0, 0, 80))
        surface.blit(wash, (0, 0))

        pulse = 1.0 + math.sin(self.t * 3) * 0.04
        size = max(40, int(110 * pulse))
        title = render_text("DEFEATED", size, C.BLOOD_BRIGHT, bold=True)
        surface.blit(title, title.get_rect(center=(WINDOW_WIDTH // 2, 200)))
        sub = render_text("the house always wins", 26, C.TEXT_DIM)
        surface.blit(sub, sub.get_rect(center=(WINDOW_WIDTH // 2, 270)))

        stats = self.game.stats
        info_lines = [
            f"Best Ante (all time): {stats.get('best_ante', 1)}",
            f"Best Single Hand: {stats.get('highest_score', 0)}",
            f"Total Wins: {stats.get('wins', 0)}",
        ]
        for i, line in enumerate(info_lines):
            s = render_text(line, 22, C.TEXT)
            surface.blit(s, s.get_rect(center=(WINDOW_WIDTH // 2, 360 + i * 30)))
        self.btn.draw(surface)


class WinScreen(Screen):
    MUSIC_INTENSITY = "low"  # quiet bed under the win stinger

    def __init__(self, game):
        super().__init__(game)
        self.t = 0.0
        # Win stinger plays on entry — the choir-hit + win SFX chord
        self.game.audio.trigger_event("big_win")
        self.btn = Button(
            pygame.Rect(WINDOW_WIDTH // 2 - 140, WINDOW_HEIGHT - 120, 280, 50),
            "MAIN MENU", on_click=lambda: game.switch_to("title"),
            color_border=C.GOLD,
        )
        # Burst of gold
        self.anim.particles.burst_fan(
            WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2,
            C.GOLD_BRIGHT, C.GOLD, count=28, speed=320, lifetime=1.2,
        )
        self.anim.add_shake(0.6)

    def handle_events(self, events):
        for e in events:
            self.btn.handle_event(e)
            if e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                self.game.switch_to("title")

    def update(self, dt):
        super().update(dt)
        self.t += dt
        # Continuous gold sparks
        if random.random() < dt * 4:
            self.anim.particles.burst_sparks(
                random.uniform(WINDOW_WIDTH * 0.3, WINDOW_WIDTH * 0.7),
                WINDOW_HEIGHT * 0.6,
                C.GOLD_BRIGHT, count=4, speed=160, lifetime=0.7,
            )

    def draw_scene(self, surface):
        glow = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        glow.fill((80, 60, 0, 60))
        surface.blit(glow, (0, 0))

        pulse = 1.0 + math.sin(self.t * 2.5) * 0.05
        size = max(40, int(110 * pulse))
        title = render_text("VICTORIOUS", size, C.GOLD_BRIGHT, bold=True)
        surface.blit(title, title.get_rect(center=(WINDOW_WIDTH // 2, 220)))
        sub = render_text("the crows know your name", 26, C.PARCHMENT)
        surface.blit(sub, sub.get_rect(center=(WINDOW_WIDTH // 2, 290)))
        s = render_text("A new joker has been unlocked.", 22, C.GREEN_GOOD)
        surface.blit(s, s.get_rect(center=(WINDOW_WIDTH // 2, 360)))
        self.btn.draw(surface)


# ============================================================================ #
# Round-result transition screen
# ============================================================================ #
class RoundResultScreen(Screen):
    """
    Sits between PlayScreen (after a win) and ShopScreen. Provides a
    Balatro-style "reward moment" with five clean phases:

      BANNER     ─ "BLIND DEFEATED" pops in
      SCORE      ─ score / target line fades in below
      REWARDS    ─ each reward row slides in from the left, staggered
      EARNED     ─ big EARNED total appears + money counter rolls up
      FADE       ─ full-screen fade to black, then `switch_to('shop')`

    Player can click anywhere to advance to the next phase, or press
    Enter/Space/Esc or hit the TO SHOP button to skip to the fade.
    No input from the round itself bleeds through — this screen owns
    its own event loop entirely.
    """

    MUSIC_INTENSITY = "low"
    ENTER_DURATION = 0.30

    PHASE_BANNER  = "banner"
    PHASE_SCORE   = "score"
    PHASE_REWARDS = "rewards"
    PHASE_EARNED  = "earned"
    PHASE_FADE    = "fade"

    BASE_PHASE_DURATIONS = {
        PHASE_BANNER:  0.90,
        PHASE_SCORE:   0.75,
        PHASE_REWARDS: 1.30,    # extended dynamically per reward row
        PHASE_EARNED:  1.30,
        PHASE_FADE:    0.55,
    }

    def __init__(self, game, summary: dict):
        super().__init__(game)
        self.summary = summary
        self.was_boss = summary.get("blind_kind") == "boss"

        # Phase state machine
        self.phase = self.PHASE_BANNER
        self.phase_t = 0.0

        # Build the reward rows (only non-zero ones — keeps the list tight)
        rows = []
        if summary.get("base"):
            rows.append(("Blind Reward", summary["base"]))
        if summary.get("hand_bonus"):
            n = summary.get("hands_left", 0)
            rows.append((f"Hands Left × {n}", summary["hand_bonus"]))
        if summary.get("interest"):
            ic = summary.get("interest_count", 0)
            rows.append((f"Interest ({ic}× $5 held)", summary["interest"]))
        self.reward_rows = rows
        self.reward_reveal_t = [0.0] * len(self.reward_rows)
        # Track which reward sounds have fired so we don't spam them
        self._reward_sound_fired = [False] * len(self.reward_rows)

        # Money counter (rolls when EARNED phase begins)
        self.money_tween = NumberTween(summary.get("money_before", 0), speed=8.0)
        self.money_target = summary.get("money_after", 0)

        # Pulses for satisfying entry pops on each line
        self.banner_pulse = Pulse(decay=0.55)
        self.banner_pulse.trigger(0.18)
        self.earned_pulse = Pulse(decay=0.65)

        # Skip button — appears once the banner has popped in.
        # Plain ">>" instead of → since pygame's default font lacks the arrow.
        self.skip_btn = Button(
            pygame.Rect(WINDOW_WIDTH - 220, WINDOW_HEIGHT - 90, 180, 50),
            "TO SHOP  >>", on_click=self._skip, color_border=C.GOLD,
            font_size=22,
        )

        # Entry effects: big shake + particle burst + audio sting
        if self.was_boss:
            self.anim.add_shake(0.50)
            self.anim.particles.burst_fan(
                WINDOW_WIDTH // 2, 240, C.BLOOD_BRIGHT, C.GOLD_BRIGHT,
                count=22, speed=280, lifetime=1.0,
            )
        else:
            self.anim.add_shake(0.30)
            self.anim.particles.burst_fan(
                WINDOW_WIDTH // 2, 240, C.GOLD_BRIGHT, C.GOLD,
                count=18, speed=240, lifetime=0.9,
            )

    # ----- Phase transition ----- #
    def _phase_duration(self) -> float:
        base = self.BASE_PHASE_DURATIONS.get(self.phase, 0.6)
        if self.phase == self.PHASE_REWARDS:
            # Give the staggered reveal time to finish + a short hold
            base = 0.6 + 0.35 * len(self.reward_rows)
            if not self.reward_rows:
                base = 0.2  # nothing to show, move on quick
        return base

    def _next_phase(self, p: str):
        self.phase = p
        self.phase_t = 0.0
        if p == self.PHASE_REWARDS:
            self.game.sounds.play("score_pop")
        elif p == self.PHASE_EARNED:
            self.money_tween.set(self.money_target)
            self.earned_pulse.trigger(0.32)
            self.game.sounds.play("buy")
            self.anim.particles.burst_sparks(
                WINDOW_WIDTH // 2, 480, C.GOLD_BRIGHT, count=18, speed=240,
            )
        elif p == self.PHASE_FADE:
            self.game.sounds.play("click")

    def _skip(self):
        """Hard-skip the whole sequence — jumps straight to the fade-out."""
        if self.phase == self.PHASE_FADE:
            return
        self.money_tween.snap(self.money_target)
        for i in range(len(self.reward_reveal_t)):
            self.reward_reveal_t[i] = 1.0
        self._next_phase(self.PHASE_FADE)

    def _advance(self):
        """Soft-advance via click — jumps to the next phase."""
        if self.phase == self.PHASE_BANNER:
            self._next_phase(self.PHASE_SCORE)
        elif self.phase == self.PHASE_SCORE:
            self._next_phase(self.PHASE_REWARDS)
        elif self.phase == self.PHASE_REWARDS:
            for i in range(len(self.reward_reveal_t)):
                self.reward_reveal_t[i] = 1.0
            self._next_phase(self.PHASE_EARNED)
        elif self.phase == self.PHASE_EARNED:
            self.money_tween.snap(self.money_target)
            self._next_phase(self.PHASE_FADE)

    def _finish(self):
        if self.game.run is None:
            self.game.switch_to("title")
            return
        self.game.switch_to("shop")

    # ----- Events ----- #
    def handle_events(self, events):
        for e in events:
            self.skip_btn.handle_event(e)
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    self._skip()
                elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self._advance()
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                # Only treat clicks outside the skip button as "advance"
                if not self.skip_btn.rect.collidepoint(e.pos):
                    self._advance()

    # ----- Update ----- #
    def update(self, dt):
        super().update(dt)
        self.phase_t += dt
        self.money_tween.update(dt)
        self.banner_pulse.update(dt)
        self.earned_pulse.update(dt)

        if self.phase == self.PHASE_REWARDS:
            # Staggered reveal — each row eases in over ~0.4s, 0.32s apart
            for i in range(len(self.reward_reveal_t)):
                t = max(0.0, self.phase_t - i * 0.32)
                v = min(1.0, t / 0.4)
                if v > 0.2 and not self._reward_sound_fired[i]:
                    self._reward_sound_fired[i] = True
                    self.game.sounds.play("score_pop", volume=0.6)
                    self.anim.particles.burst_sparks(
                        WINDOW_WIDTH // 2 - 220, 390 + i * 46,
                        C.GOLD, count=6, speed=110, lifetime=0.55,
                    )
                self.reward_reveal_t[i] = v

        # Time-based phase progression
        if self.phase_t >= self._phase_duration():
            order = {
                self.PHASE_BANNER:  self.PHASE_SCORE,
                self.PHASE_SCORE:   self.PHASE_REWARDS,
                self.PHASE_REWARDS: self.PHASE_EARNED,
                self.PHASE_EARNED:  self.PHASE_FADE,
                self.PHASE_FADE:    None,
            }
            nxt = order[self.phase]
            if nxt is None:
                self._finish()
            else:
                self._next_phase(nxt)

    # ----- Draw ----- #
    def draw_scene(self, surface):
        run = self.game.run

        # Top HUD stays for continuity (player still sees ante / target / money)
        if run is not None and run.current_blind is not None:
            _draw_top_hud(surface, run, self.game,
                          money_display=self.money_tween.display_int,
                          score_display=self.summary.get("score", 0))

        # Banner — visible BANNER..EARNED
        if self.phase != self.PHASE_FADE:
            self._draw_banner(surface)

        # Score line — visible from SCORE phase onward
        if self.phase in (self.PHASE_SCORE, self.PHASE_REWARDS, self.PHASE_EARNED):
            self._draw_score_line(surface)

        # Reward rows — visible from REWARDS phase onward
        if self.phase in (self.PHASE_REWARDS, self.PHASE_EARNED):
            self._draw_rewards_panel(surface)

        # Earned total + money — visible only in EARNED phase
        if self.phase == self.PHASE_EARNED:
            self._draw_earned(surface)

        # Skip button — hidden during fade
        if self.phase != self.PHASE_FADE:
            self.skip_btn.draw(surface)

        # Fade-out overlay
        if self.phase == self.PHASE_FADE:
            fade_t = min(1.0, self.phase_t / self.BASE_PHASE_DURATIONS[self.PHASE_FADE])
            overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, int(255 * (fade_t ** 0.7))))
            surface.blit(overlay, (0, 0))

    # ----- Sub-draws ----- #
    def _draw_banner(self, surface):
        cx = WINDOW_WIDTH // 2
        y = 235
        if self.was_boss:
            heading_text = "BOSS DEFEATED"
            heading_color = C.BLOOD_BRIGHT
        else:
            heading_text = "BLIND DEFEATED"
            heading_color = C.GOLD_BRIGHT
        # Banner pops in once on entry, otherwise stays at scale 1.
        if self.phase == self.PHASE_BANNER:
            t = min(1.0, self.phase_t / 0.40)
            scale = ease_out_back(t)
        else:
            scale = self.banner_pulse.value
        size = max(28, int(72 * scale))

        # Drop shadows
        shadow_dark = render_text(heading_text, size, (0, 0, 0), bold=True)
        shadow_red  = render_text(heading_text, size, (90, 16, 20), bold=True)
        head        = render_text(heading_text, size, heading_color, bold=True)
        surface.blit(shadow_dark, shadow_dark.get_rect(center=(cx + 5, y + 6)))
        surface.blit(shadow_red,  shadow_red.get_rect(center=(cx + 2, y + 3)))
        surface.blit(head,        head.get_rect(center=(cx, y)))

        # Subtitle — blind name
        blind_title = self.summary.get("blind_title", "")
        if blind_title:
            sub = render_text(blind_title, 26, C.PARCHMENT)
            surface.blit(sub, sub.get_rect(center=(cx, y + 56)))

    def _draw_score_line(self, surface):
        cx = WINDOW_WIDTH // 2
        y = 330
        # Fade-in
        if self.phase == self.PHASE_SCORE:
            t = min(1.0, self.phase_t / 0.45)
        else:
            t = 1.0
        # Slide up while fading in
        offset = int((1.0 - t) * 24)
        alpha = int(255 * t)

        score = self.summary.get("score", 0)
        target = self.summary.get("target", 0)
        line = f"{score} / {target}"

        score_surf = render_text(line, 38, C.TEXT, bold=True)
        score_surf.set_alpha(alpha)
        score_rect = score_surf.get_rect(center=(cx - 18, y + offset))
        surface.blit(score_surf, score_rect)

        # Polygon checkmark next to the score — default pygame font has no ✓.
        check_size = 26
        cx_chk = score_rect.right + 22
        cy_chk = score_rect.centery
        self._draw_checkmark(surface, (cx_chk, cy_chk), check_size, C.GOLD_BRIGHT, alpha)

    @staticmethod
    def _draw_checkmark(surface, center, size, color, alpha=255):
        """Two-stroke checkmark drawn with anti-aliased lines."""
        cx, cy = center
        s = size / 2
        col = (*color, alpha) if len(color) == 3 else color
        # Draw onto a temp surface so alpha is respected end-to-end
        surf = pygame.Surface((size + 6, size + 6), pygame.SRCALPHA)
        pts = [
            (3, s + 1),
            (s - 2, size + 1),
            (size + 2, 2),
        ]
        pygame.draw.lines(surf, col, False, pts, 5)
        surface.blit(surf, surf.get_rect(center=(cx, cy)))

    def _draw_rewards_panel(self, surface):
        cx = WINDOW_WIDTH // 2
        panel_w, panel_h = 480, max(80, 50 + 46 * len(self.reward_rows))
        panel_rect = pygame.Rect(cx - panel_w // 2, 380, panel_w, panel_h)

        # Panel body
        pygame.draw.rect(surface, (16, 10, 18), panel_rect, border_radius=10)
        pygame.draw.rect(surface, C.GOLD_DIM, panel_rect, 2, border_radius=10)

        # Header
        hdr = render_text("REWARDS", 18, C.GOLD, bold=True)
        surface.blit(hdr, hdr.get_rect(midtop=(panel_rect.centerx, panel_rect.y - 26)))

        if not self.reward_rows:
            none_surf = render_text("(no bonuses)", 18, C.TEXT_FAINT, bold=False)
            surface.blit(none_surf, none_surf.get_rect(center=panel_rect.center))
            return

        for i, (label, amount) in enumerate(self.reward_rows):
            t = self.reward_reveal_t[i]
            # Slide in from the left with overshoot
            slide_in = ease_out_back(t)
            x_offset = int((1.0 - slide_in) * -60)
            alpha = int(255 * min(1.0, t * 2))

            row_y = panel_rect.y + 14 + i * 46

            label_surf = render_text(label, 22, C.TEXT, bold=True)
            label_surf.set_alpha(alpha)
            surface.blit(label_surf, (panel_rect.x + 20 + x_offset, row_y))

            amount_surf = render_text(f"+${amount}", 24, C.GREEN_GOOD, bold=True)
            amount_surf.set_alpha(alpha)
            surface.blit(amount_surf,
                         amount_surf.get_rect(midright=(panel_rect.right - 20 - x_offset, row_y + 12)))

    def _draw_earned(self, surface):
        cx = WINDOW_WIDTH // 2
        # Big EARNED line with the total
        scale = self.earned_pulse.value
        size = max(20, int(46 * scale))
        total = self.summary.get("total", 0)
        line = f"EARNED  +${total}"
        sh = render_text(line, size, (0, 0, 0), bold=True)
        main = render_text(line, size, C.GOLD_BRIGHT, bold=True)
        y = 560
        surface.blit(sh, sh.get_rect(center=(cx + 3, y + 4)))
        surface.blit(main, main.get_rect(center=(cx, y)))

        # Live money roll under it
        money_str = f"${self.money_tween.display_int}"
        msurf = render_text(money_str, 28, C.GOLD, bold=True)
        surface.blit(msurf, msurf.get_rect(center=(cx, y + 38)))


# ============================================================================ #
# Shared HUD
# ============================================================================ #
def _draw_hud_panel(surface, rect, label_text, value_text,
                    value_color=C.GOLD_BRIGHT, value_size: int = 28,
                    label_color=C.TEXT_DIM, label_size: int = 13,
                    accent=C.GOLD_DIM):
    """Reusable sub-panel for the top HUD with label above, big value below."""
    # Vertical gradient body
    body = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    top = (24, 16, 24)
    bot = (10, 6, 12)
    for y in range(rect.height):
        t = y / max(1, rect.height - 1)
        col = (
            int(top[0] * (1 - t) + bot[0] * t),
            int(top[1] * (1 - t) + bot[1] * t),
            int(top[2] * (1 - t) + bot[2] * t),
        )
        pygame.draw.line(body, col, (0, y), (rect.width, y))
    mask = pygame.Surface(body.get_size(), pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=8)
    body.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surface.blit(body, rect.topleft)
    pygame.draw.rect(surface, accent, rect, 1, border_radius=8)
    # Label
    lbl = render_text(label_text, label_size, label_color, bold=True)
    surface.blit(lbl, lbl.get_rect(midtop=(rect.centerx, rect.y + 4)))
    # Value with subtle shadow
    val_shadow = render_text(value_text, value_size, (0, 0, 0), bold=True)
    val = render_text(value_text, value_size, value_color, bold=True)
    cx = rect.centerx
    cy = rect.y + 30 + (rect.height - 30) // 2 - 4
    surface.blit(val_shadow, val_shadow.get_rect(center=(cx + 1, cy + 2)))
    surface.blit(val, val.get_rect(center=(cx, cy)))


def _draw_top_hud(surface, run, game,
                  money_display: Optional[int] = None,
                  score_display: Optional[int] = None,
                  joker_pulses: Optional[List[float]] = None):
    """
    Premium top HUD: unified dark bar with a gold accent edge, then three
    framed sub-panels (Ante/Blind, Score Target + progress, Money + Jokers).
    """
    bar = pygame.Rect(0, 0, WINDOW_WIDTH, 100)
    # Gradient bar background
    grad = pygame.Surface((WINDOW_WIDTH, 100), pygame.SRCALPHA)
    for y in range(100):
        t = y / 99
        col = (int(28 - 14 * t), int(16 - 8 * t), int(24 - 12 * t), 255)
        pygame.draw.line(grad, col, (0, y), (WINDOW_WIDTH, y))
    surface.blit(grad, (0, 0))
    # Bottom edge accents
    pygame.draw.line(surface, C.GOLD_DIM, (0, bar.bottom), (WINDOW_WIDTH, bar.bottom), 2)
    pygame.draw.line(surface, (60, 30, 38), (0, bar.bottom + 2),
                     (WINDOW_WIDTH, bar.bottom + 2), 1)

    # ----- Left sub-panel: Ante + blind kind ----- #
    left_panel = pygame.Rect(16, 12, 200, 76)
    blind_kind = run.current_blind_kind()
    blind_label = {"small": "SMALL BLIND", "big": "BIG BLIND", "boss": "BOSS BLIND"}[blind_kind]
    blind_color = C.BLOOD_BRIGHT if blind_kind == "boss" else C.GOLD_BRIGHT
    _draw_hud_panel(
        surface, left_panel,
        label_text=f"ANTE {run.ante} / {MAX_ANTE}",
        value_text=blind_label,
        value_color=blind_color, value_size=22,
        accent=C.BLOOD if blind_kind == "boss" else C.GOLD_DIM,
    )

    # ----- Center sub-panel: Score target + current score progress ----- #
    if run.current_blind is not None:
        center_panel = pygame.Rect(WINDOW_WIDTH // 2 - 160, 8, 320, 84)
        sdisp = score_display if score_display is not None else run.round_score
        target = run.current_blind.score_target
        # Larger panel, draw differently — target on top, score below w/ bar
        _draw_hud_panel(
            surface, center_panel,
            label_text="TARGET",
            value_text=f"{target}",
            value_color=C.GOLD_BRIGHT, value_size=34,
        )
        # Progress under the value
        bar_y = center_panel.bottom - 14
        prog_bar = pygame.Rect(center_panel.x + 14, bar_y, center_panel.width - 28, 8)
        pygame.draw.rect(surface, (8, 6, 10), prog_bar, border_radius=4)
        prog = max(0.0, min(1.0, sdisp / max(1, target)))
        fill = prog_bar.copy()
        fill.width = int(prog_bar.width * prog)
        if fill.width > 0:
            pygame.draw.rect(surface, C.BLOOD_BRIGHT, fill, border_radius=4)
        pygame.draw.rect(surface, C.GOLD_DIM, prog_bar, 1, border_radius=4)
        # Score number tiny below
        score_txt = render_text(f"{sdisp}", 14, C.TEXT, bold=True)
        surface.blit(score_txt, score_txt.get_rect(midtop=(center_panel.centerx, bar_y + 10)))

    # ----- Right sub-panel: Money + joker count ----- #
    right_panel = pygame.Rect(WINDOW_WIDTH - 216, 12, 200, 76)
    mdisp = money_display if money_display is not None else run.money
    _draw_hud_panel(
        surface, right_panel,
        label_text=f"JOKERS {len(run.jokers)}/{run.max_joker_slots}",
        value_text=f"${mdisp}",
        value_color=C.GOLD_BRIGHT, value_size=30,
    )

    # ----- Joker slot strip beneath the HUD ----- #
    if run.jokers:
        draw_joker_slots(surface, run.jokers, game.assets,
                         (20, 110), JOKER_HEIGHT,
                         max_slots=run.max_joker_slots,
                         pulses=joker_pulses)


# ============================================================================ #
# Text wrapping
# ============================================================================ #
def _wrap(text: str, width: int) -> List[str]:
    words = text.split()
    lines, cur = [], ""
    for w in words:
        candidate = (cur + " " + w).strip()
        if len(candidate) > width:
            if cur:
                lines.append(cur)
            cur = w
        else:
            cur = candidate
    if cur:
        lines.append(cur)
    return lines
