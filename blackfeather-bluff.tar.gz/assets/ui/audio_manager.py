"""
Top-level audio coordinator for BLACKFEATHER BLUFF.

Owns the MusicController (adaptive ambient layers) and the SFXManager
(per-action sound effects). Exposes a single tidy interface for the rest of
the game:

    audio.play_sfx("card_play")
    audio.set_intensity("high")           # crossfade music mix
    audio.stinger("win")                  # one-shot dramatic hit
    audio.trigger_event("big_win")        # combined stinger + SFX
    audio.set_muted(True)

Master volume, mute, and the channel pool are all centralised here.
"""

import os
from typing import Optional

import pygame

from ui.music_controller import MusicController
from ui.sfx_manager import SFXManager


class AudioManager:
    """Single point of contact for everything audio-related."""

    # We reserve channels 0..3 for the four music layers, channel 4 for
    # stingers. Leaving 12 channels for SFX is plenty in practice (peak
    # scoring sequence fires 5-7 concurrent sounds).
    NUM_CHANNELS = 24

    def __init__(self, music_volume: float = 0.45, sfx_volume: float = 0.7):
        # main.py calls pygame.mixer.pre_init(22050, -16, 2, 512) before
        # pygame.init(). If pre_init was skipped for some reason, initialise
        # explicitly with the same args so our procedural buffers match what
        # the mixer expects.
        if pygame.mixer.get_init() is None:
            try:
                pygame.mixer.init(22050, -16, 2, 512)
            except pygame.error:
                pass
        try:
            pygame.mixer.set_num_channels(self.NUM_CHANNELS)
        except pygame.error:
            pass

        self.music = MusicController(master_volume=music_volume)
        self.sfx = SFXManager(master_volume=sfx_volume)
        self._muted = False

    # --------------------------------------------------------------------- #
    # Per-frame update
    # --------------------------------------------------------------------- #
    def update(self, dt: float) -> None:
        self.music.update(dt)

    # --------------------------------------------------------------------- #
    # SFX
    # --------------------------------------------------------------------- #
    def play_sfx(self, name: str, volume: float = 1.0) -> None:
        if self._muted:
            return
        self.sfx.play(name, volume=volume)

    # --------------------------------------------------------------------- #
    # Music intensity / stingers
    # --------------------------------------------------------------------- #
    def set_intensity(self, level: str) -> None:
        if self._muted:
            self.music.set_intensity("silent")
            return
        self.music.set_intensity(level)

    def stinger(self, name: str) -> None:
        if self._muted:
            return
        self.music.stinger(name)

    # --------------------------------------------------------------------- #
    # High-level event hooks — combine music + SFX for big moments
    # --------------------------------------------------------------------- #
    def trigger_event(self, event: str) -> None:
        """Single call for things that want a unified audio reaction."""
        if event == "big_win":
            self.stinger("win")
            self.play_sfx("win_round", volume=0.8)
        elif event == "small_win":
            self.play_sfx("win_round", volume=0.7)
        elif event == "round_lost":
            self.stinger("lose")
            self.play_sfx("lose_round", volume=0.9)
        elif event == "boss_intro":
            self.stinger("boss")
            self.play_sfx("boss", volume=0.85)
        elif event == "huge_multiplier":
            self.play_sfx("huge_multiplier", volume=0.6)
        elif event == "legendary_card":
            self.play_sfx("card_legendary", volume=0.8)

    # --------------------------------------------------------------------- #
    # Master controls
    # --------------------------------------------------------------------- #
    def set_muted(self, muted: bool) -> None:
        self._muted = muted
        # Drop music to silence immediately so the player doesn't hear a tail.
        if muted:
            self.music.set_intensity("silent")
        # When unmuting, the active screen's set_intensity will re-trigger
        # the proper level on its next switch_to or the next Screen __init__.

    def toggle_muted(self) -> bool:
        self.set_muted(not self._muted)
        return self._muted

    def set_music_volume(self, v: float) -> None:
        self.music.set_master_volume(v)

    def set_sfx_volume(self, v: float) -> None:
        self.sfx.set_master_volume(v)

    @property
    def is_muted(self) -> bool:
        return self._muted

    @property
    def is_ready(self) -> bool:
        """True once the music layers have finished generating + are looping."""
        return self.music.ready
