"""
Easing curves and value tweens.

Used everywhere we need a value to move smoothly over time: card positions,
counter rolls, button scales, particle properties.

Nothing here knows about pygame — these are pure math primitives.
"""

import math
from dataclasses import dataclass, field
from typing import Callable, Optional


# --------------------------------------------------------------------------- #
# Easing functions: all take t in [0, 1] and return a transformed t in [0, 1+ε]
# --------------------------------------------------------------------------- #
def linear(t: float) -> float:
    return t


def ease_in_quad(t: float) -> float:
    return t * t


def ease_out_quad(t: float) -> float:
    return 1 - (1 - t) ** 2


def ease_in_out_quad(t: float) -> float:
    if t < 0.5:
        return 2 * t * t
    return 1 - ((-2 * t + 2) ** 2) / 2


def ease_in_cubic(t: float) -> float:
    return t ** 3


def ease_out_cubic(t: float) -> float:
    return 1 - (1 - t) ** 3


def ease_in_out_cubic(t: float) -> float:
    if t < 0.5:
        return 4 * t * t * t
    return 1 - ((-2 * t + 2) ** 3) / 2


def ease_out_back(t: float) -> float:
    """Overshoots target then settles back — punchy 'pop' feel."""
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2


def ease_in_back(t: float) -> float:
    c1 = 1.70158
    c3 = c1 + 1
    return c3 * t * t * t - c1 * t * t


def ease_out_elastic(t: float) -> float:
    """Wobbly spring landing. Use sparingly."""
    if t <= 0:
        return 0.0
    if t >= 1:
        return 1.0
    c4 = (2 * math.pi) / 3
    return 2 ** (-10 * t) * math.sin((t * 10 - 0.75) * c4) + 1


def ease_out_bounce(t: float) -> float:
    """Ball-bouncing-on-floor curve. Multi-overshoot landing."""
    n1 = 7.5625
    d1 = 2.75
    if t < 1 / d1:
        return n1 * t * t
    if t < 2 / d1:
        t -= 1.5 / d1
        return n1 * t * t + 0.75
    if t < 2.5 / d1:
        t -= 2.25 / d1
        return n1 * t * t + 0.9375
    t -= 2.625 / d1
    return n1 * t * t + 0.984375


# --------------------------------------------------------------------------- #
# Tween — animate a value over a fixed duration.
# --------------------------------------------------------------------------- #
@dataclass
class Tween:
    start: float
    end: float
    duration: float
    ease: Callable[[float], float] = ease_out_cubic
    delay: float = 0.0
    on_done: Optional[Callable[[], None]] = None
    elapsed: float = 0.0
    done: bool = False

    @property
    def value(self) -> float:
        if self.elapsed < 0:
            return self.start
        t = max(0.0, min(1.0, self.elapsed / max(self.duration, 1e-6)))
        return self.start + (self.end - self.start) * self.ease(t)

    def update(self, dt: float) -> None:
        if self.done:
            return
        self.elapsed += dt
        if self.elapsed >= self.duration + self.delay:
            self.done = True
            if self.on_done:
                self.on_done()

    @property
    def t(self) -> float:
        """0..1 raw progress, ignoring easing."""
        return max(0.0, min(1.0, self.elapsed / max(self.duration, 1e-6)))


# --------------------------------------------------------------------------- #
# NumberTween — counter that rolls smoothly toward its target.
# --------------------------------------------------------------------------- #
class NumberTween:
    """
    A smoothly-rolling number. Display rounds to int for chip/mult counters.

    Calling `.set(target)` schedules movement; update() advances it each frame.
    """
    def __init__(self, initial: float = 0.0, speed: float = 9.0,
                 min_step: float = 0.5):
        self.value = float(initial)
        self.target = float(initial)
        self.speed = speed       # higher = snaps faster
        self.min_step = min_step

    def set(self, target: float) -> None:
        self.target = float(target)

    def snap(self, value: float) -> None:
        self.value = float(value)
        self.target = float(value)

    def update(self, dt: float) -> None:
        if self.value == self.target:
            return
        # Frame-rate-independent exponential approach.
        k = 1.0 - math.exp(-self.speed * dt)
        self.value += (self.target - self.value) * k
        if abs(self.value - self.target) < self.min_step:
            self.value = self.target

    @property
    def display_int(self) -> int:
        return int(round(self.value))

    @property
    def is_animating(self) -> bool:
        return self.value != self.target


# --------------------------------------------------------------------------- #
# Pulse — one-shot scale/intensity envelope.
# --------------------------------------------------------------------------- #
class Pulse:
    """
    Idle at 1.0. Calling `.trigger(amount)` momentarily ramps the value up
    then settles back. Useful for 'mult just got bigger' bounces.

    value(t) = 1 + amount * sin(pi * progress)
    """
    def __init__(self, decay: float = 0.55):
        self.progress = 1.0    # 1.0 = idle
        self.amount = 0.0
        self.decay = decay     # duration in seconds

    def trigger(self, amount: float = 0.18) -> None:
        self.progress = 0.0
        self.amount = amount

    def update(self, dt: float) -> None:
        if self.progress >= 1.0:
            return
        self.progress = min(1.0, self.progress + dt / self.decay)

    @property
    def value(self) -> float:
        if self.progress >= 1.0:
            return 1.0
        # sin curve peaks at 1+amount halfway through, returns to 1.
        return 1.0 + self.amount * math.sin(self.progress * math.pi)

    @property
    def active(self) -> bool:
        return self.progress < 1.0


# --------------------------------------------------------------------------- #
# Convenience helpers
# --------------------------------------------------------------------------- #
def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def smoothstep(a: float, b: float, t: float) -> float:
    t = max(0.0, min(1.0, (t - a) / max(b - a, 1e-6)))
    return t * t * (3 - 2 * t)


def damp(current: float, target: float, smoothing: float, dt: float) -> float:
    """
    Frame-rate-independent exponential damping toward a target.
    `smoothing` ≈ how fast you converge; ~10 is snappy, ~3 is slow.
    """
    k = 1.0 - math.exp(-smoothing * dt)
    return current + (target - current) * k
