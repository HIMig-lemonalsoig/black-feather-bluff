"""
Procedural assets.

Cards, joker icons, the card back, and a few decorative props are all drawn
at runtime via pygame primitives — so the game runs with zero asset files.

The AssetCache lazily generates and stores each surface. SoundCache does the
same with procedural sine/triangle waves.

`ensure_assets()` only creates the assets directory (we keep things in memory).
"""

import array
import math
import os
import random
from typing import Dict, Tuple

import pygame

from game.constants import (
    CARD_WIDTH, CARD_HEIGHT, JOKER_WIDTH, JOKER_HEIGHT,
    SUIT_SYMBOLS, RED_SUITS, RANKS, SUITS, ASSETS_DIR,
)
from ui import colors as C
from game.jokers import JOKER_DEFS


# --------------------------------------------------------------------------- #
# Public entry point
# --------------------------------------------------------------------------- #
def ensure_assets() -> None:
    """Create the assets directory. Actual assets are generated lazily."""
    os.makedirs(ASSETS_DIR, exist_ok=True)


# --------------------------------------------------------------------------- #
# Font management
# --------------------------------------------------------------------------- #
_FONT_CACHE: Dict[Tuple[int, bool], pygame.font.Font] = {}


def get_font(size: int, bold: bool = False) -> pygame.font.Font:
    """Cached font getter. Uses pygame's built-in default font."""
    key = (size, bold)
    if key not in _FONT_CACHE:
        f = pygame.font.Font(None, size)
        f.set_bold(bold)
        _FONT_CACHE[key] = f
    return _FONT_CACHE[key]


def render_text(text: str, size: int, color, bold: bool = False) -> pygame.Surface:
    """Convenience wrapper: render anti-aliased text in one call."""
    return get_font(size, bold).render(text, True, color)


# --------------------------------------------------------------------------- #
# Asset cache
# --------------------------------------------------------------------------- #
class AssetCache:
    """Lazy-builds and stores pygame.Surfaces by key."""

    def __init__(self):
        self.cards: Dict[Tuple[str, str], pygame.Surface] = {}
        self.card_back: pygame.Surface = None
        self.jokers: Dict[str, pygame.Surface] = {}
        self.bg: pygame.Surface = None

    # ----- Cards ----- #
    def get_card(self, rank: str, suit: str) -> pygame.Surface:
        key = (rank, suit)
        if key not in self.cards:
            self.cards[key] = _draw_card_face(rank, suit)
        return self.cards[key]

    def get_card_back(self) -> pygame.Surface:
        if self.card_back is None:
            self.card_back = _draw_card_back()
        return self.card_back

    # ----- Jokers ----- #
    def get_joker(self, joker_id: str) -> pygame.Surface:
        if joker_id not in self.jokers:
            cls = JOKER_DEFS.get(joker_id)
            rarity = cls.rarity if cls else "common"
            self.jokers[joker_id] = _draw_joker(joker_id, rarity)
        return self.jokers[joker_id]

    # ----- Background ----- #
    def get_bg(self, width: int, height: int) -> pygame.Surface:
        if self.bg is None or self.bg.get_size() != (width, height):
            self.bg = _draw_background(width, height)
        return self.bg


# --------------------------------------------------------------------------- #
# Suit symbol drawing (polygon-based, font-independent)
# --------------------------------------------------------------------------- #
# We draw the four suits as polygons so we don't depend on the OS font having
# the Unicode suit glyphs (♥ ♦ ♣ ♠). Default pygame font on macOS lacks them
# at most sizes, which would otherwise render as empty boxes.

def _draw_heart(surf, cx, cy, size, color):
    r = size / 2.6
    pygame.draw.circle(surf, color, (int(cx - r * 0.55), int(cy - r * 0.4)), int(r))
    pygame.draw.circle(surf, color, (int(cx + r * 0.55), int(cy - r * 0.4)), int(r))
    pygame.draw.polygon(surf, color, [
        (cx - r * 1.45, cy - r * 0.2),
        (cx + r * 1.45, cy - r * 0.2),
        (cx, cy + r * 1.45),
    ])


def _draw_diamond(surf, cx, cy, size, color):
    r = size / 2.1
    pygame.draw.polygon(surf, color, [
        (cx, cy - r),
        (cx + r * 0.72, cy),
        (cx, cy + r),
        (cx - r * 0.72, cy),
    ])


def _draw_club(surf, cx, cy, size, color):
    """Three lobes meeting at a short stem."""
    r = size / 3.4
    pygame.draw.circle(surf, color, (int(cx - r * 1.05), int(cy + r * 0.25)), int(r))
    pygame.draw.circle(surf, color, (int(cx + r * 1.05), int(cy + r * 0.25)), int(r))
    pygame.draw.circle(surf, color, (int(cx), int(cy - r * 0.95)), int(r))
    # Short trapezoid stem
    pygame.draw.polygon(surf, color, [
        (cx - r * 0.45, cy + r * 0.55),
        (cx + r * 0.45, cy + r * 0.55),
        (cx + r * 0.75, cy + r * 1.25),
        (cx - r * 0.75, cy + r * 1.25),
    ])


def _draw_spade(surf, cx, cy, size, color):
    """Inverted-heart body + short stem — reads as a traditional spade."""
    r = size / 2.6
    # Two round bulges at the bottom of the inverted heart
    pygame.draw.circle(surf, color, (int(cx - r * 0.55), int(cy + r * 0.35)), int(r))
    pygame.draw.circle(surf, color, (int(cx + r * 0.55), int(cy + r * 0.35)), int(r))
    # Triangle pointing up
    pygame.draw.polygon(surf, color, [
        (cx - r * 1.45, cy + r * 0.15),
        (cx + r * 1.45, cy + r * 0.15),
        (cx, cy - r * 1.45),
    ])
    # Short stem at bottom
    pygame.draw.polygon(surf, color, [
        (cx - r * 0.3, cy + r * 1.0),
        (cx + r * 0.3, cy + r * 1.0),
        (cx + r * 0.6, cy + r * 1.5),
        (cx - r * 0.6, cy + r * 1.5),
    ])


_SUIT_DRAWERS = {
    'hearts':   _draw_heart,
    'diamonds': _draw_diamond,
    'clubs':    _draw_club,
    'spades':   _draw_spade,
}


def make_suit_surface(suit: str, size: int, color) -> pygame.Surface:
    """Polygon-rendered suit symbol on a transparent surface (square, size×size)."""
    side = size + 6
    surf = pygame.Surface((side, side), pygame.SRCALPHA)
    _SUIT_DRAWERS[suit](surf, side / 2, side / 2, size, color)
    return surf


# --------------------------------------------------------------------------- #
# Card face — suit-distinct redesign
# --------------------------------------------------------------------------- #
def _draw_card_face(rank: str, suit: str) -> pygame.Surface:
    """
    Draw a playing card face procedurally with strong suit differentiation.

    Each suit has its own tinted card background, symbol color, and border
    color (see SUIT_PALETTES). The center holds a dominant suit symbol; the
    rank sits big in the corners with the small suit underneath.
    """
    pal = C.SUIT_PALETTES[suit]
    surf = pygame.Surface((CARD_WIDTH, CARD_HEIGHT), pygame.SRCALPHA)
    rect = surf.get_rect()

    # --- Drop shadow (soft, offset) -------------------------------------- #
    shadow = pygame.Surface((CARD_WIDTH + 6, CARD_HEIGHT + 8), pygame.SRCALPHA)
    pygame.draw.rect(shadow, (0, 0, 0, 110),
                     pygame.Rect(0, 0, CARD_WIDTH + 4, CARD_HEIGHT + 4),
                     border_radius=10)
    surf.blit(shadow, (3, 5))

    # --- Card body with a subtle vertical gradient ----------------------- #
    body = pygame.Surface((CARD_WIDTH, CARD_HEIGHT), pygame.SRCALPHA)
    bg_top = pal['bg']
    bg_bot = pal['bg_edge']
    for y in range(CARD_HEIGHT):
        t = y / max(1, CARD_HEIGHT - 1)
        col = (
            int(bg_top[0] * (1 - t) + bg_bot[0] * t),
            int(bg_top[1] * (1 - t) + bg_bot[1] * t),
            int(bg_top[2] * (1 - t) + bg_bot[2] * t),
        )
        pygame.draw.line(body, col, (0, y), (CARD_WIDTH, y))
    # Mask the gradient with rounded corners
    mask = pygame.Surface((CARD_WIDTH, CARD_HEIGHT), pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=10)
    body.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surf.blit(body, (0, 0))

    # --- Border ----------------------------------------------------------- #
    pygame.draw.rect(surf, pal['border'], rect, 2, border_radius=10)
    # Subtle inner highlight (1 px lighter inset, gives "glossy" feel)
    inner = rect.inflate(-4, -4)
    inner_col = _shift(pal['bg'], 12)
    pygame.draw.rect(surf, inner_col, inner, 1, border_radius=8)

    # --- Faint suit watermark (very low alpha big polygon symbol)  -------- #
    watermark = make_suit_surface(suit, 70, pal['symbol'])
    watermark.set_alpha(28)
    surf.blit(watermark, watermark.get_rect(center=(CARD_WIDTH // 2 + 4,
                                                    CARD_HEIGHT // 2 + 4)))

    # --- Dominant center suit symbol ------------------------------------- #
    big_sym = make_suit_surface(suit, 48, pal['symbol'])
    surf.blit(big_sym, big_sym.get_rect(center=(CARD_WIDTH // 2,
                                                CARD_HEIGHT // 2 + 6)))

    # --- Big rank in corners --------------------------------------------- #
    # Slightly smaller font for two-character "10".
    rank_size = 30 if len(rank) == 1 else 24
    rank_text = render_text(rank, rank_size, pal['text'], bold=True)
    sym_small = make_suit_surface(suit, 16, pal['symbol'])

    # Top-left corner
    surf.blit(rank_text, (6, 2))
    surf.blit(sym_small, (4, 2 + rank_text.get_height() - 2))

    # Bottom-right corner (rotated 180)
    rank_rot = pygame.transform.rotate(rank_text, 180)
    sym_rot = pygame.transform.rotate(sym_small, 180)
    surf.blit(rank_rot, (CARD_WIDTH - rank_rot.get_width() - 6,
                         CARD_HEIGHT - rank_rot.get_height() - 2))
    surf.blit(sym_rot, (CARD_WIDTH - sym_rot.get_width() - 4,
                        CARD_HEIGHT - rank_rot.get_height() - sym_rot.get_height()))

    # --- Suit-specific accent flourish ----------------------------------- #
    _draw_suit_accent(surf, suit, pal)

    return surf


def _shift(color, delta):
    """Lighten an RGB tuple by `delta` per channel, clamped to 255."""
    return tuple(min(255, c + delta) for c in color)


def _draw_suit_accent(surf, suit, pal):
    """
    Tiny suit-themed flourish in the inner corners to reinforce identity.

    Hearts:   small heart bullets
    Diamonds: sharp four-point ticks
    Clubs:    leaf-like ovals
    Spades:   angular dagger-tips
    """
    sym_col = pal['symbol']
    # Two opposing corners (top-right, bottom-left), small accent (~6px)
    a = (CARD_WIDTH - 12, 10)
    b = (12, CARD_HEIGHT - 12)
    if suit == 'hearts':
        for cx, cy in (a, b):
            pygame.draw.circle(surf, sym_col, (cx - 2, cy), 3)
            pygame.draw.circle(surf, sym_col, (cx + 2, cy), 3)
            pygame.draw.polygon(surf, sym_col,
                                [(cx - 5, cy + 1), (cx + 5, cy + 1), (cx, cy + 6)])
    elif suit == 'diamonds':
        for cx, cy in (a, b):
            pygame.draw.polygon(surf, sym_col,
                                [(cx, cy - 5), (cx + 4, cy), (cx, cy + 5), (cx - 4, cy)])
    elif suit == 'clubs':
        for cx, cy in (a, b):
            pygame.draw.ellipse(surf, sym_col,
                                pygame.Rect(cx - 4, cy - 5, 8, 6))
            pygame.draw.rect(surf, sym_col,
                             pygame.Rect(cx - 1, cy + 1, 2, 4))
    elif suit == 'spades':
        for cx, cy in (a, b):
            pygame.draw.polygon(surf, sym_col,
                                [(cx, cy - 6), (cx + 4, cy + 2), (cx - 4, cy + 2)])
            pygame.draw.rect(surf, sym_col,
                             pygame.Rect(cx - 1, cy + 1, 2, 4))


# --------------------------------------------------------------------------- #
# Card back
# --------------------------------------------------------------------------- #
def _draw_card_back() -> pygame.Surface:
    """Dark red/black card back with a gold raven monogram."""
    surf = pygame.Surface((CARD_WIDTH, CARD_HEIGHT), pygame.SRCALPHA)
    rect = surf.get_rect()
    pygame.draw.rect(surf, C.BLOOD_DIM, rect, border_radius=10)
    pygame.draw.rect(surf, C.GOLD_DIM, rect, 2, border_radius=10)

    # Diagonal lattice
    for i in range(-CARD_HEIGHT, CARD_WIDTH + CARD_HEIGHT, 8):
        pygame.draw.line(surf, (50, 12, 18), (i, 0), (i + CARD_HEIGHT, CARD_HEIGHT), 1)

    # Gold border inset
    inset = rect.inflate(-10, -10)
    pygame.draw.rect(surf, C.GOLD_DIM, inset, 1, border_radius=8)

    # Raven monogram (gold "B")
    txt = render_text("B", 40, C.GOLD, bold=True)
    surf.blit(txt, txt.get_rect(center=(CARD_WIDTH // 2, CARD_HEIGHT // 2)))
    return surf


# --------------------------------------------------------------------------- #
# Joker icon
# --------------------------------------------------------------------------- #
# Per-bird color hints for variety
_BIRD_PALETTES = {
    "raven":   ((20, 20, 26), (60, 50, 70), (80, 80, 100)),
    "crow":    ((28, 22, 30), (60, 50, 70), (140, 130, 150)),
    "owl":     ((90, 60, 30), (150, 110, 50), (240, 220, 170)),
    "peacock": ((30, 70, 110), (40, 130, 160), (220, 180, 40)),
    "eagle":   ((110, 80, 30), (220, 200, 160), (240, 200, 30)),
    "vulture": ((130, 120, 110), (90, 80, 70), (200, 80, 80)),
    "parrot":  ((40, 130, 60), (220, 60, 60), (240, 200, 30)),
    "falcon":  ((80, 60, 50), (180, 150, 100), (220, 200, 160)),
    "swan":    ((220, 220, 230), (180, 180, 200), (240, 100, 100)),
}


def _draw_joker(joker_id: str, rarity: str) -> pygame.Surface:
    """Draw a joker card: framed bird silhouette + name tag."""
    surf = pygame.Surface((JOKER_WIDTH, JOKER_HEIGHT), pygame.SRCALPHA)
    rect = surf.get_rect()

    # Shadow + body
    shadow = pygame.Surface((JOKER_WIDTH, JOKER_HEIGHT), pygame.SRCALPHA)
    pygame.draw.rect(shadow, (0, 0, 0, 130), rect.inflate(-2, -2), border_radius=8)
    surf.blit(shadow, (3, 4))

    pygame.draw.rect(surf, C.BG_PANEL_HI, rect, border_radius=8)
    border_color = C.RARITY_COLORS.get(rarity, C.GOLD_DIM)
    pygame.draw.rect(surf, border_color, rect, 3, border_radius=8)

    # Inset frame
    inset = rect.inflate(-10, -10)
    pygame.draw.rect(surf, C.BG_PANEL, inset, border_radius=6)

    # Bird silhouette in the central area
    body_col, accent_col, eye_col = _BIRD_PALETTES.get(joker_id, ((50, 40, 50), (90, 70, 90), (220, 200, 60)))
    _draw_bird(surf, joker_id, body_col, accent_col, eye_col,
               center=(JOKER_WIDTH // 2, JOKER_HEIGHT // 2 - 6))

    # Name tag
    name = JOKER_DEFS[joker_id].name if joker_id in JOKER_DEFS else joker_id.upper()
    tag = render_text(name, 18, C.GOLD, bold=True)
    if tag.get_width() > JOKER_WIDTH - 8:
        tag = render_text(name, 14, C.GOLD, bold=True)
    surf.blit(tag, tag.get_rect(center=(JOKER_WIDTH // 2, JOKER_HEIGHT - 14)))

    return surf


def _draw_bird(surf, joker_id, body, accent, eye, center):
    """Crude bird silhouette. Different shapes per species."""
    cx, cy = center

    if joker_id == "owl":
        # Round body, big eyes
        pygame.draw.circle(surf, body, (cx, cy + 8), 22)
        pygame.draw.circle(surf, accent, (cx, cy - 6), 18)
        pygame.draw.circle(surf, (240, 240, 240), (cx - 6, cy - 6), 5)
        pygame.draw.circle(surf, (240, 240, 240), (cx + 6, cy - 6), 5)
        pygame.draw.circle(surf, (10, 10, 10), (cx - 6, cy - 6), 2)
        pygame.draw.circle(surf, (10, 10, 10), (cx + 6, cy - 6), 2)
        pygame.draw.polygon(surf, eye, [(cx - 3, cy - 1), (cx + 3, cy - 1), (cx, cy + 4)])
        return

    if joker_id == "peacock":
        # Fan tail
        for i, ang in enumerate((-50, -30, -10, 10, 30, 50)):
            r = 22
            a = math.radians(ang - 90)
            ex = cx + math.cos(a) * r
            ey = cy + math.sin(a) * r
            col = accent if i % 2 == 0 else eye
            pygame.draw.circle(surf, col, (int(ex), int(ey)), 5)
        pygame.draw.circle(surf, body, (cx, cy + 4), 14)
        pygame.draw.circle(surf, (240, 240, 240), (cx + 3, cy + 1), 3)
        pygame.draw.polygon(surf, eye, [(cx + 12, cy + 4), (cx + 18, cy + 2), (cx + 12, cy + 8)])
        return

    if joker_id == "parrot":
        pygame.draw.circle(surf, body, (cx, cy + 4), 18)
        pygame.draw.polygon(surf, accent, [(cx - 18, cy - 4), (cx, cy - 14), (cx + 18, cy - 4)])
        pygame.draw.circle(surf, (240, 240, 240), (cx + 3, cy), 3)
        pygame.draw.polygon(surf, eye, [(cx + 14, cy + 2), (cx + 22, cy), (cx + 14, cy + 6)])
        return

    if joker_id == "swan":
        # S-curve neck
        pygame.draw.circle(surf, body, (cx + 2, cy + 10), 16)
        pygame.draw.line(surf, body, (cx + 4, cy + 4), (cx - 10, cy - 14), 8)
        pygame.draw.circle(surf, body, (cx - 14, cy - 16), 6)
        pygame.draw.polygon(surf, eye, [(cx - 22, cy - 16), (cx - 18, cy - 18), (cx - 18, cy - 14)])
        pygame.draw.circle(surf, (10, 10, 10), (cx - 14, cy - 18), 2)
        return

    # Generic raven/crow/eagle/vulture/falcon silhouette
    # Body
    pygame.draw.ellipse(surf, body, (cx - 16, cy - 4, 32, 24))
    # Head
    pygame.draw.circle(surf, body, (cx - 14, cy - 10), 8)
    # Beak
    pygame.draw.polygon(surf, eye, [(cx - 22, cy - 10), (cx - 14, cy - 12), (cx - 18, cy - 6)])
    # Wing accent
    pygame.draw.polygon(surf, accent, [(cx + 14, cy - 2), (cx - 6, cy + 8), (cx + 14, cy + 12)])
    # Eye
    pygame.draw.circle(surf, (240, 240, 240), (cx - 14, cy - 11), 2)


# --------------------------------------------------------------------------- #
# Background
# --------------------------------------------------------------------------- #
def _draw_background(width: int, height: int) -> pygame.Surface:
    """Deep red/black vertical gradient with a subtle vignette and noise specks."""
    surf = pygame.Surface((width, height))

    # Vertical gradient
    for y in range(height):
        t = y / max(1, height - 1)
        r = int(C.BG_DEEP[0] * (1 - t) + 30 * t)
        g = int(C.BG_DEEP[1] * (1 - t) + 8 * t)
        b = int(C.BG_DEEP[2] * (1 - t) + 14 * t)
        pygame.draw.line(surf, (r, g, b), (0, y), (width, y))

    # Vignette
    vignette = pygame.Surface((width, height), pygame.SRCALPHA)
    for i in range(8):
        alpha = 18 + i * 6
        pygame.draw.rect(vignette, (0, 0, 0, alpha),
                         pygame.Rect(i * 8, i * 6, width - i * 16, height - i * 12),
                         8, border_radius=20)
    surf.blit(vignette, (0, 0))

    # Subtle red speckles for grain
    rng = random.Random(1337)
    for _ in range(120):
        x = rng.randint(0, width - 1)
        y = rng.randint(0, height - 1)
        a = rng.randint(15, 40)
        pygame.draw.circle(surf, (60 + rng.randint(0, 40), 10, 14), (x, y), 1)
    return surf


# --------------------------------------------------------------------------- #
# Sound cache
# --------------------------------------------------------------------------- #
class SoundCache:
    """Procedurally builds and caches simple sound effects.

    Tones are stored as `pygame.mixer.Sound`s. If mixer init failed, we
    silently no-op every play_*() call.
    """

    def __init__(self):
        self._sounds: Dict[str, pygame.mixer.Sound] = {}
        try:
            pygame.mixer.init()
            self._enabled = True
        except pygame.error:
            self._enabled = False

        if self._enabled:
            self._build()

    def _build(self):
        # Each entry: (sequence-of-(freq, duration), volume)
        recipes = {
            "card_select": ([(880, 0.04)], 0.25),
            "card_play":   ([(660, 0.06), (990, 0.08)], 0.30),
            "deal":        ([(440, 0.03)], 0.20),
            "score_pop":   ([(700, 0.04), (900, 0.04), (1200, 0.06)], 0.25),
            "win_round":   ([(523, 0.10), (659, 0.10), (784, 0.16)], 0.35),
            "lose_round":  ([(330, 0.10), (262, 0.10), (196, 0.20)], 0.35),
            "buy":         ([(880, 0.05), (1320, 0.08)], 0.30),
            "reroll":      ([(660, 0.04), (660, 0.06)], 0.20),
            "click":       ([(520, 0.03)], 0.20),
            "boss":        ([(110, 0.12), (98, 0.20)], 0.40),
        }
        for name, (notes, vol) in recipes.items():
            self._sounds[name] = _build_tone_sequence(notes, vol)

    def play(self, name: str) -> None:
        if not self._enabled:
            return
        s = self._sounds.get(name)
        if s is not None:
            s.play()


def _build_tone_sequence(notes, volume: float = 0.3, sample_rate: int = 22050) -> pygame.mixer.Sound:
    """
    Build a single Sound by concatenating short tone segments.

    Uses the stdlib `array` module to avoid a numpy dependency.
    """
    buf = array.array('h')
    for freq, dur in notes:
        n = int(sample_rate * dur)
        for s in range(n):
            t = s / sample_rate
            # Attack/release envelope
            env_attack = min(1.0, t * 80)
            env_release = min(1.0, (dur - t) * 80)
            env = max(0.0, min(env_attack, env_release))
            v = volume * env * math.sin(2 * math.pi * freq * t)
            sample = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(sample)
            buf.append(sample)  # stereo
    return pygame.mixer.Sound(buffer=buf.tobytes())
