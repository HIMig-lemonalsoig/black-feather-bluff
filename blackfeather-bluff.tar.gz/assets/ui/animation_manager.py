"""
The animation hub.

A single AnimationManager owned by each screen pulls together:
  - Tweens (value animations with a duration + ease)
  - Floating text popups (drift up and fade out)
  - Particle system (feathers, sparks, smoke, rings)
  - Screen shake (trauma model, applied as a post-process offset)
  - Joker-trigger ring overlays (visible joker callouts)

Joker-specific particle bursts are mapped here so the rest of the UI just
calls `manager.trigger_joker(joker_id, x, y)`.
"""

import math
import random
from typing import List, Optional, Tuple

import pygame

from ui import colors as C
from ui.tweening import Tween, NumberTween, Pulse, ease_out_cubic, ease_out_back
from ui.particle_system import ParticleSystem


# --------------------------------------------------------------------------- #
# Screen shake (trauma model — Squirrel Eiserloh)
# --------------------------------------------------------------------------- #
class ScreenShake:
    """
    Accumulate 'trauma' [0, 1]. Shake = trauma² × random offset.
    Trauma decays linearly. Squaring makes small adds feel gentle.
    """
    def __init__(self, max_offset: float = 22.0, max_angle: float = 3.5,
                 decay: float = 1.8):
        self.trauma = 0.0
        self.max_offset = max_offset
        self.max_angle = max_angle
        self.decay = decay

    def add(self, amount: float) -> None:
        """Bump trauma. 0.2 = small kick, 0.6 = strong shake, 1.0 = max."""
        self.trauma = max(0.0, min(1.0, self.trauma + amount))

    def update(self, dt: float) -> None:
        if self.trauma > 0.0:
            self.trauma = max(0.0, self.trauma - self.decay * dt)

    def offset(self) -> Tuple[float, float, float]:
        """Returns (dx, dy, angle_degrees) to apply to the rendered scene."""
        if self.trauma <= 0:
            return (0.0, 0.0, 0.0)
        t2 = self.trauma * self.trauma
        dx = self.max_offset * t2 * random.uniform(-1, 1)
        dy = self.max_offset * t2 * random.uniform(-1, 1)
        da = self.max_angle * t2 * random.uniform(-1, 1)
        return (dx, dy, da)


# --------------------------------------------------------------------------- #
# Floating text
# --------------------------------------------------------------------------- #
class FloatingText:
    """A bit of text that drifts upward and fades. Supports a 'pop' birth."""

    def __init__(self, pos: Tuple[float, float], text: str, color,
                 size: int = 24, duration: float = 1.2, dy: float = -60,
                 pop: bool = True):
        self.x, self.y = pos
        self.text = text
        self.color = color
        self.size = size
        self.duration = duration
        self.elapsed = 0.0
        self.dy = dy
        self.pop = pop

    def update(self, dt: float) -> bool:
        """Returns True when the popup should be removed."""
        self.elapsed += dt
        return self.elapsed >= self.duration

    def draw(self, surface) -> None:
        from ui.assets import get_font
        t = min(1.0, self.elapsed / self.duration)
        alpha = int(255 * (1.0 - t * t))
        y = self.y + self.dy * t

        # Pop: scale grows from 0.6 -> 1.15 -> 1.0 in the first ~25% of life.
        if self.pop:
            pop_t = min(1.0, self.elapsed / (self.duration * 0.25))
            scale = 0.6 + ease_out_back(pop_t) * 0.4
        else:
            scale = 1.0

        font = get_font(self.size, bold=True)
        surf = font.render(self.text, True, self.color)
        if scale != 1.0:
            w, h = surf.get_size()
            surf = pygame.transform.smoothscale(
                surf, (max(1, int(w * scale)), max(1, int(h * scale)))
            )
        surf.set_alpha(alpha)
        rect = surf.get_rect(center=(int(self.x), int(y)))
        surface.blit(surf, rect)


# --------------------------------------------------------------------------- #
# Manager
# --------------------------------------------------------------------------- #
class AnimationManager:
    """Composes tweens, popups, particles, and shake for a single screen."""

    def __init__(self):
        self.tweens: List[Tween] = []
        self.popups: List[FloatingText] = []
        self.particles = ParticleSystem()
        self.shake = ScreenShake()

    # ----- Tween / popup / particle hooks ----- #
    def add_tween(self, t: Tween) -> Tween:
        self.tweens.append(t)
        return t

    def add_popup(self, p: FloatingText) -> None:
        self.popups.append(p)

    def add_shake(self, amount: float) -> None:
        self.shake.add(amount)

    def particle_system(self) -> ParticleSystem:
        return self.particles

    # ----- Lifecycle ----- #
    def update(self, dt: float) -> None:
        for t in self.tweens:
            t.update(dt)
        self.tweens = [t for t in self.tweens if not t.done]
        self.popups = [p for p in self.popups if not p.update(dt)]
        self.particles.update(dt)
        self.shake.update(dt)

    def draw_particles(self, surface) -> None:
        self.particles.draw(surface)

    def draw_popups(self, surface) -> None:
        for p in self.popups:
            p.draw(surface)

    # --------------------------------------------------------------------- #
    # Joker-specific triggers
    # --------------------------------------------------------------------- #
    def trigger_joker(self, joker_id: str, x: float, y: float) -> None:
        """Spawn the signature effect for a given joker at (x, y)."""
        # Default ring for any joker activation — keeps the eye anchored.
        self.particles.shockwave(x, y, C.GOLD, lifetime=0.4)

        if joker_id == "raven":
            # Dark feather swirl
            self.particles.burst_feathers(x, y, (28, 24, 36), count=12, speed=160)
        elif joker_id == "crow":
            # Crow is about discard scaling — pulse a shadowy ring + sparks
            self.particles.burst_feathers(x, y, (50, 36, 50), count=8, speed=120)
            self.particles.burst_sparks(x, y, C.BLOOD_BRIGHT, count=6, speed=160)
        elif joker_id == "owl":
            self.particles.eye_glow(x, y)
        elif joker_id == "peacock":
            self.particles.burst_fan(x, y, C.BLUE_INFO, C.GOLD_BRIGHT, count=18, speed=200)
        elif joker_id == "eagle":
            self.particles.gold_streak(x, y)
            self.add_shake(0.18)
        elif joker_id == "vulture":
            self.particles.burst_smoke(x, y, (130, 110, 90), count=8)
            self.particles.burst_sparks(x, y, (200, 80, 80), count=6, speed=140)
        elif joker_id == "parrot":
            self.particles.echo_clone(x, y, C.PURPLE_RARE)
            self.particles.burst_sparks(x, y, (60, 200, 110), count=8, speed=160)
        elif joker_id == "falcon":
            self.particles.burst_sparks(x, y, C.GOLD, count=10, speed=200)
            self.particles.burst_feathers(x, y, (130, 100, 70), count=6, speed=130)
        elif joker_id == "swan":
            self.particles.burst_feathers(x, y, (235, 230, 240), count=10, speed=120)
        else:
            self.particles.burst_sparks(x, y, C.GOLD, count=8)
