"""
Layered adaptive ambient music for BLACKFEATHER BLUFF.

Vibe target: lonely underground casino, 2 AM. Hypnotic, slightly dissonant,
never cheerful. Built so the player feels like they're slowly being pulled
under without ever being able to point at what's wrong with the room.

How it works
------------
Four looping layers play simultaneously on dedicated pygame.mixer.Channels:

  * drone   — slow detuned low sines, the "room tone" of a haunted casino
  * pulse   — heartbeat-style bass throbs at ~50 BPM
  * tension — dissonant tritone pad that rides high above the drone
  * crackle — quiet vinyl/static noise floor

The *mix* of these layers expresses an INTENSITY profile:

    silent : everything muted (game over, splash)
    low    : drone + faint crackle only (menus, shop)
    medium : adds pulse (between-hand idle, blind select)
    high   : adds tension (live during scoring sequence)

Switching `set_intensity` retargets every layer's volume; volumes smoothly
damp toward their target each frame so transitions are imperceptible.

One-shot **stingers** (win / lose / boss) play on a reserved channel over the
top of the bed for dramatic moments.

File overrides
--------------
On startup the controller looks for these files (in order .ogg, .wav, .mp3)
inside `assets/audio/music/`:

    drone.<ext>, pulse.<ext>, tension.<ext>, crackle.<ext>
    sting_win.<ext>, sting_lose.<ext>, sting_boss.<ext>

If a file is found, it's used as-is. Otherwise the controller generates a
procedural fallback so the game has audio out of the box.

Generation happens on a background thread so the main loop doesn't stutter
during the first ~5 seconds of launch; music fades in once each layer is
ready.
"""

import array
import math
import os
import random
import sys
import threading
from typing import Dict, Optional

import pygame

from game.constants import ASSETS_DIR

# Pygbag/WASM runs Python in the browser via Pyodide, which doesn't have real
# threads. Generating ~25s of procedural audio synchronously would block the
# main loop for ~15-30 seconds on first load (the canvas stays black). Detect
# this environment and skip procedural generation. File overrides still load.
IS_WEB = sys.platform == "emscripten"


# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
AUDIO_DIR = os.path.join(ASSETS_DIR, "audio")
MUSIC_DIR = os.path.join(AUDIO_DIR, "music")

LAYER_NAMES = ("drone", "pulse", "tension", "crackle")
STINGER_NAMES = ("win", "lose", "boss")

# Channels 0..3 reserved for the four music layers, channel 4 for stingers.
# (Pygame default mixer ships with 8; we bump to 24 in AudioManager init.)
LAYER_CHANNEL_INDEX = {name: i for i, name in enumerate(LAYER_NAMES)}
STINGER_CHANNEL_INDEX = 4


# --------------------------------------------------------------------------- #
# Intensity profiles — per-layer target volumes
# --------------------------------------------------------------------------- #
INTENSITY_PROFILES: Dict[str, Dict[str, float]] = {
    "silent": {"drone": 0.00, "pulse": 0.00, "tension": 0.00, "crackle": 0.00},
    "low":    {"drone": 0.55, "pulse": 0.00, "tension": 0.00, "crackle": 0.18},
    "medium": {"drone": 0.55, "pulse": 0.45, "tension": 0.12, "crackle": 0.25},
    "high":   {"drone": 0.50, "pulse": 0.60, "tension": 0.55, "crackle": 0.35},
}


# --------------------------------------------------------------------------- #
# MusicController
# --------------------------------------------------------------------------- #
class MusicController:
    """Layered ambient music with adaptive intensity."""

    # Per-layer "musical" parameters tuned so loop boundaries line up cleanly
    # (period × duration is an integer cycle count for every frequency used).
    DRONE_DURATION   = 8.0
    PULSE_DURATION   = 9.6     # exactly 8 beats at 50 BPM
    TENSION_DURATION = 10.0
    CRACKLE_DURATION = 6.0

    # How quickly volumes lerp toward their target (seconds-ish time constant).
    FADE_TIME = 1.4

    def __init__(self, master_volume: float = 0.55):
        self.master_volume = master_volume
        self._enabled = pygame.mixer.get_init() is not None
        # Match generators to whatever the mixer was actually initialised at,
        # so playback never has the wrong pitch/speed.
        init = pygame.mixer.get_init()
        if init:
            self.sample_rate = init[0]
            self.channels = init[2]
        else:
            self.sample_rate = 22050
            self.channels = 2

        # Volume state
        self.intensity = "silent"
        self.target_volumes = dict(INTENSITY_PROFILES["silent"])
        self.current_volumes = dict(self.target_volumes)

        # Sounds + channels (populated by the background init)
        self.layer_sounds: Dict[str, Optional[pygame.mixer.Sound]] = {n: None for n in LAYER_NAMES}
        self.layer_channels: Dict[str, Optional[pygame.mixer.Channel]] = {n: None for n in LAYER_NAMES}
        self.stingers: Dict[str, Optional[pygame.mixer.Sound]] = {n: None for n in STINGER_NAMES}

        self._ready = False
        self._lock = threading.Lock()

        if self._enabled:
            os.makedirs(MUSIC_DIR, exist_ok=True)
            if IS_WEB:
                # WASM: skip threading. Try file overrides only — no synth
                # work. If no files exist, music stays silent (game runs).
                self._init_in_background()
            else:
                threading.Thread(target=self._init_in_background, daemon=True).start()

    # --------------------------------------------------------------------- #
    # Public API
    # --------------------------------------------------------------------- #
    def set_intensity(self, level: str) -> None:
        """Cross-fade the layer mix toward the given intensity profile."""
        if level not in INTENSITY_PROFILES:
            return
        self.intensity = level
        if self._ready:
            with self._lock:
                self.target_volumes = dict(INTENSITY_PROFILES[level])

    def stinger(self, name: str) -> None:
        """Fire a one-shot dramatic sound (win / lose / boss)."""
        if not self._enabled or not self._ready:
            return
        sound = self.stingers.get(name)
        if sound is None:
            return
        try:
            channel = pygame.mixer.Channel(STINGER_CHANNEL_INDEX)
            channel.set_volume(self.master_volume * 0.9)
            channel.play(sound)
        except pygame.error:
            pass

    def update(self, dt: float) -> None:
        """Damp current layer volumes toward their targets each frame."""
        if not self._enabled or not self._ready:
            return
        k = 1.0 - math.exp(-dt / max(self.FADE_TIME, 0.001))
        with self._lock:
            for name in LAYER_NAMES:
                target = self.target_volumes[name] * self.master_volume
                current = self.current_volumes[name]
                new = current + (target - current) * k
                self.current_volumes[name] = new
                ch = self.layer_channels[name]
                if ch is not None:
                    try:
                        ch.set_volume(new)
                    except pygame.error:
                        pass

    def set_master_volume(self, v: float) -> None:
        self.master_volume = max(0.0, min(1.0, v))

    @property
    def ready(self) -> bool:
        return self._ready

    # --------------------------------------------------------------------- #
    # Background init — find files or generate, then bind channels
    # --------------------------------------------------------------------- #
    def _init_in_background(self) -> None:
        # Each layer: try to load file, else generate procedurally
        try:
            self.layer_sounds["drone"]   = self._load_or_generate("drone", self._gen_drone)
            self.layer_sounds["pulse"]   = self._load_or_generate("pulse", self._gen_pulse)
            self.layer_sounds["tension"] = self._load_or_generate("tension", self._gen_tension)
            self.layer_sounds["crackle"] = self._load_or_generate("crackle", self._gen_crackle)

            self.stingers["win"]  = self._load_or_generate("sting_win",  self._gen_win_sting)
            self.stingers["lose"] = self._load_or_generate("sting_lose", self._gen_lose_sting)
            self.stingers["boss"] = self._load_or_generate("sting_boss", self._gen_boss_sting)

            # Start all layers looping at volume 0 (will be lerped up by update())
            for name in LAYER_NAMES:
                snd = self.layer_sounds[name]
                if snd is None:
                    continue
                idx = LAYER_CHANNEL_INDEX[name]
                ch = pygame.mixer.Channel(idx)
                ch.set_volume(0.0)
                ch.play(snd, loops=-1)
                self.layer_channels[name] = ch
        except pygame.error:
            # If mixer was lost mid-init, just bail silently.
            return

        with self._lock:
            # Apply whatever intensity was requested before init finished.
            self.target_volumes = dict(INTENSITY_PROFILES[self.intensity])
            self._ready = True

    def _load_or_generate(self, basename: str, fallback_gen) -> Optional[pygame.mixer.Sound]:
        """Look in assets/audio/music/ for an override; else generate.
        On web, never generate — return None instead, leaving the layer silent."""
        for ext in (".ogg", ".wav", ".mp3"):
            path = os.path.join(MUSIC_DIR, basename + ext)
            if os.path.exists(path):
                try:
                    return pygame.mixer.Sound(path)
                except pygame.error:
                    pass
        if IS_WEB:
            return None
        try:
            return fallback_gen()
        except Exception:
            return None

    # --------------------------------------------------------------------- #
    # Procedural generators
    # --------------------------------------------------------------------- #
    @staticmethod
    def _to_sound(buf: array.array) -> pygame.mixer.Sound:
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _gen_drone(self) -> pygame.mixer.Sound:
        """
        Slow detuned low sines. Three voices, fundamentals chosen so the
        intervals are slightly off — sounds like a room you shouldn't be in.
        """
        sr = self.sample_rate
        duration = self.DRONE_DURATION
        n = int(duration * sr)
        buf = array.array("h")
        # Carefully-chosen frequencies that all complete integer cycles in 8s
        f1, f2, f3 = 55.0, 82.5, 110.0
        lfo_freq = 1.0 / duration         # exactly one slow swell per loop
        master = 0.32
        for i in range(n):
            t = i / sr
            # Slow swell: starts dim, peaks mid-loop, dim again
            lfo = 0.45 + 0.55 * math.sin(2 * math.pi * lfo_freq * t - math.pi / 2)
            tau = 2 * math.pi * t
            v_l = (0.36 * math.sin(tau * f1)
                   + 0.22 * math.sin(tau * f2 + 0.3)
                   + 0.10 * math.sin(tau * f3 + 0.7))
            # Slight stereo phase offset for width
            v_r = (0.36 * math.sin(tau * f1 + 0.40)
                   + 0.22 * math.sin(tau * f2 + 0.70)
                   + 0.10 * math.sin(tau * f3 + 1.10))
            v_l *= lfo * master
            v_r *= lfo * master
            buf.append(int(max(-1.0, min(1.0, v_l)) * 32767))
            buf.append(int(max(-1.0, min(1.0, v_r)) * 32767))
        return self._to_sound(buf)

    def _gen_pulse(self) -> pygame.mixer.Sound:
        """
        Heartbeat throb. 50 BPM, each pulse is a quick-attack, exp-decay
        bass note at ~55 Hz. 8 beats in 9.6s = clean loop.
        """
        sr = self.sample_rate
        duration = self.PULSE_DURATION
        n = int(duration * sr)
        buf = array.array("h")
        beat_period = 60.0 / 50.0          # 1.2s
        beat_freq = 55.0
        for i in range(n):
            t = i / sr
            beat_t = t % beat_period
            # Envelope: 25ms attack then decay
            if beat_t < 0.025:
                env = beat_t / 0.025
            else:
                env = math.exp(-(beat_t - 0.025) * 4.5)
            v = math.sin(2 * math.pi * beat_freq * beat_t) * env * 0.55
            sample = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(sample)
            buf.append(sample)
        return self._to_sound(buf)

    def _gen_tension(self) -> pygame.mixer.Sound:
        """
        Higher dissonant pad — fundamental + tritone-ish interval.
        Quiet enough to read as anxiety, not melody.
        """
        sr = self.sample_rate
        duration = self.TENSION_DURATION
        n = int(duration * sr)
        buf = array.array("h")
        f1, f2, f3 = 110.0, 220.0, 311.0       # tritone ~ 1.414 * 220
        lfo_freq = 0.5                          # 5 cycles in 10s
        for i in range(n):
            t = i / sr
            lfo = 0.5 + 0.5 * math.sin(2 * math.pi * lfo_freq * t)
            tau = 2 * math.pi * t
            v_l = (0.20 * math.sin(tau * f1)
                   + 0.14 * math.sin(tau * f2 + 0.2)
                   + 0.12 * math.sin(tau * f3 + 0.5))
            v_r = (0.20 * math.sin(tau * f1 + 0.3)
                   + 0.14 * math.sin(tau * f2 + 0.6)
                   + 0.12 * math.sin(tau * f3 + 0.9))
            v_l *= lfo * 0.30
            v_r *= lfo * 0.30
            buf.append(int(max(-1.0, min(1.0, v_l)) * 32767))
            buf.append(int(max(-1.0, min(1.0, v_r)) * 32767))
        return self._to_sound(buf)

    def _gen_crackle(self) -> pygame.mixer.Sound:
        """
        Vinyl-style noise floor: smoothed random with occasional sharper pops.
        """
        sr = self.sample_rate
        duration = self.CRACKLE_DURATION
        n = int(duration * sr)
        buf = array.array("h")
        rng = random.Random(0xfeed)
        prev_l = prev_r = 0.0
        for _ in range(n):
            raw_l = (rng.random() - 0.5) * 2.0
            raw_r = (rng.random() - 0.5) * 2.0
            # Smooth low-pass via single-pole IIR
            prev_l = prev_l * 0.6 + raw_l * 0.4
            prev_r = prev_r * 0.6 + raw_r * 0.4
            v_l = prev_l * 0.05
            v_r = prev_r * 0.05
            # Rare sharper crackle (~once per second on average)
            if rng.random() < 0.0004:
                spike = (rng.random() - 0.5) * 0.5
                v_l += spike
                v_r += spike * 0.9
            buf.append(int(max(-1.0, min(1.0, v_l)) * 32767))
            buf.append(int(max(-1.0, min(1.0, v_r)) * 32767))
        return self._to_sound(buf)

    def _gen_win_sting(self) -> pygame.mixer.Sound:
        """
        Dark choir-like hit — low A with stacked harmonics, slow attack +
        long decay. Reads as "you got away with it… for now."
        """
        sr = self.sample_rate
        duration = 2.4
        n = int(duration * sr)
        buf = array.array("h")
        base = 110.0
        for i in range(n):
            t = i / sr
            if t < 0.18:
                env_a = t / 0.18
            elif t < 1.6:
                env_a = 1.0
            else:
                env_a = max(0.0, 1.0 - (t - 1.6) / 0.8)
            tau = 2 * math.pi * t
            v = (0.32 * math.sin(tau * base)
                 + 0.22 * math.sin(tau * base * 2)
                 + 0.16 * math.sin(tau * base * 3 + 0.3)
                 + 0.10 * math.sin(tau * base * 4 + 0.6)
                 + 0.06 * math.sin(tau * base * 5 + 0.9))
            v *= env_a * 0.55
            sample = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(sample)
            buf.append(sample)
        return self._to_sound(buf)

    def _gen_lose_sting(self) -> pygame.mixer.Sound:
        """Descending detuned pitch decay — the room swallowing you."""
        sr = self.sample_rate
        duration = 2.0
        n = int(duration * sr)
        buf = array.array("h")
        start_freq = 220.0
        end_freq = 55.0
        # Integrate phase to handle the swept frequency cleanly
        phase = 0.0
        phase2 = 0.0
        for i in range(n):
            t = i / sr
            t_norm = t / duration
            freq = start_freq * (1 - t_norm) + end_freq * t_norm
            phase += 2 * math.pi * freq / sr
            phase2 += 2 * math.pi * (freq * 1.012) / sr
            env = math.exp(-t * 1.4)
            v = (math.sin(phase) * 0.6 + math.sin(phase2) * 0.3) * env
            sample = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(sample)
            buf.append(sample)
        return self._to_sound(buf)

    def _gen_boss_sting(self) -> pygame.mixer.Sound:
        """Deep ominous hit + sustained low rumble — boss intro."""
        sr = self.sample_rate
        duration = 2.5
        n = int(duration * sr)
        buf = array.array("h")
        for i in range(n):
            t = i / sr
            if t < 0.06:
                env_hit = t / 0.06
            else:
                env_hit = math.exp(-(t - 0.06) * 0.9)
            v = math.sin(2 * math.pi * 41.0 * t) * env_hit * 0.7
            # Rumble underneath
            rumble_env = 1.0 - t / duration
            v += math.sin(2 * math.pi * 55.0 * t) * 0.22 * rumble_env
            # Detuned shadow voice for unease
            v += math.sin(2 * math.pi * 55.0 * 1.015 * t) * 0.18 * rumble_env
            sample = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(sample)
            buf.append(sample)
        return self._to_sound(buf)
