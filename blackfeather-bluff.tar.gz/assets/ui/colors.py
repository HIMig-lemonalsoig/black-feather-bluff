"""
Centralised color palette for the noir-casino aesthetic.

Black / blood-red / gold dominate. Card faces use a slightly warm off-white so
they don't blow out the dark UI.
"""

# Base background palette
BG_DEEP        = (8, 6, 10)
BG             = (14, 10, 16)
BG_PANEL       = (22, 14, 22)
BG_PANEL_HI    = (36, 22, 32)
BORDER         = (60, 40, 50)

# Brand accents
GOLD           = (212, 175, 55)
GOLD_DIM       = (140, 110, 30)
GOLD_BRIGHT    = (255, 215, 80)
BLOOD          = (170, 28, 38)
BLOOD_DIM      = (90, 18, 24)
BLOOD_BRIGHT   = (215, 60, 70)

# Text and cards
WHITE          = (235, 230, 215)
OFF_WHITE      = (242, 236, 222)
PARCHMENT      = (228, 215, 178)
TEXT           = (228, 220, 200)
TEXT_DIM       = (160, 150, 130)
TEXT_FAINT     = (110, 100, 90)
CARD_BG        = (244, 238, 220)
CARD_BG_HOVER  = (252, 246, 228)
CARD_SHADOW    = (0, 0, 0)
CARD_BORDER    = (40, 30, 30)
BLACK          = (8, 6, 10)

# Suits (red/black) - kept for backwards-compat references; the SUIT_PALETTES
# table below is the source of truth for the polished card rendering.
SUIT_RED       = (220, 40, 50)
SUIT_BLACK     = (16, 12, 18)

# --------------------------------------------------------------------------- #
# Per-suit palettes — used by the redesigned cards for instant visual
# differentiation. Each suit has a tinted card background, a saturated symbol
# color, a high-contrast text color, a darker border, and a brighter glow
# color used by the selection/hover halo.
#
# Hearts   = warm red on warm cream card
# Diamonds = neon cyan-blue on cool cream card (the *opposite* of hearts so
#            you can't mistake them at a glance)
# Clubs    = vivid green on green-cream card (NOT the traditional black —
#            chosen so all four suits are color-coded, per design brief)
# Spades   = silver/white on a dark navy card (the gothic / noir suit)
# --------------------------------------------------------------------------- #
SUIT_PALETTES = {
    'hearts': {
        'bg':       (252, 232, 230),
        'bg_edge':  (245, 210, 208),     # subtle gradient toward edge
        'symbol':   (220, 40, 50),
        'text':     (140, 18, 28),
        'border':   (180, 30, 40),
        'glow':     (255, 90, 110),
        'halo_radius': 18,                # rounded soft halo
        'halo_thickness': 4,
    },
    'diamonds': {
        'bg':       (224, 240, 252),
        'bg_edge':  (200, 226, 248),
        'symbol':   (30, 150, 240),
        'text':     (18, 60, 140),
        'border':   (50, 130, 210),
        'glow':     (90, 210, 255),
        'halo_radius': 3,                 # sharp geometric halo
        'halo_thickness': 3,
    },
    'clubs': {
        'bg':       (228, 244, 228),
        'bg_edge':  (206, 232, 206),
        'symbol':   (50, 170, 80),
        'text':     (18, 90, 36),
        'border':   (60, 140, 70),
        'glow':     (110, 230, 130),
        'halo_radius': 14,                # organic soft halo
        'halo_thickness': 4,
    },
    'spades': {
        'bg':       (28, 28, 42),         # dark navy gothic
        'bg_edge':  (16, 16, 28),
        'symbol':   (235, 235, 248),
        'text':     (220, 220, 235),
        'border':   (140, 140, 158),
        'glow':     (220, 220, 240),
        'halo_radius': 2,                 # sharp dark-edged halo
        'halo_thickness': 4,
    },
}

# Status colors
GREEN_GOOD     = (120, 180, 90)
PURPLE_RARE    = (170, 90, 210)
BLUE_INFO      = (100, 160, 220)

# Joker rarity colors (borders)
RARITY_COLORS = {
    "common":    (180, 180, 170),
    "uncommon":  (120, 180, 90),
    "rare":      (90, 130, 220),
    "legendary": (200, 100, 220),
}

# Button states
BTN_BG         = (26, 18, 24)
BTN_BG_HOVER   = (50, 30, 38)
BTN_BG_DOWN    = (74, 40, 48)
BTN_DISABLED   = (28, 24, 28)
BTN_TEXT       = OFF_WHITE
BTN_BORDER     = GOLD_DIM

# Overlays
OVERLAY_DARK   = (0, 0, 0, 180)
OVERLAY_RED    = (60, 0, 0, 80)
