"""
Stable particle-module name (the implementation lives in particle_system.py).

Created so external code can `from ui.particles import ParticleSystem` and so
the module layout matches the documented top-level grouping
(animation_manager / particles / ui_effects / shaders / card_renderer).
"""

from ui.particle_system import Particle, ParticleSystem  # noqa: F401

__all__ = ["Particle", "ParticleSystem"]
