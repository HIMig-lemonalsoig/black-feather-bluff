"""
Per-action sound effects for BLACKFEATHER BLUFF.

Replaces the old `ui.assets.SoundCache` with a richer library:

  * tactile card sounds (select / hover / play / slap / discard)
  * scoring + UI feedback (score_pop, click, buy, reroll)
  * per-bird-joker signature sounds (raven swoosh, owl chime, etc.)
  * win / lose / boss callouts

Every sound:
  1. First tries to load `assets/audio/sfx/<name>.<ext>` (ogg / wav).
  2. Falls back to a procedural generator using stdlib math + array.

Playback uses `pygame.mixer.find_channel()` so concurrent SFX coexist with
the music-controller's reserved channels.
"""

import array
import math
import os
import random
from typing import Callable, Dict, Optional

import pygame

from game.constants import ASSETS_DIR


AUDIO_DIR = os.path.join(ASSETS_DIR, "audio")
SFX_DIR = os.path.join(AUDIO_DIR, "sfx")


class SFXManager:
    """Cached library of short sound effects."""

    def __init__(self, master_volume: float = 0.55):
        self._enabled = pygame.mixer.get_init() is not None
        # Match generators to whatever the mixer was actually initialised at.
        init = pygame.mixer.get_init()
        if init:
            self.sample_rate = init[0]
            self.channels = init[2]
        else:
            self.sample_rate = 22050
            self.channels = 2
        self.master_volume = master_volume
        self.sounds: Dict[str, pygame.mixer.Sound] = {}
        if self._enabled:
            os.makedirs(SFX_DIR, exist_ok=True)
            self._build()

    # --------------------------------------------------------------------- #
    # Public API
    # --------------------------------------------------------------------- #
    def play(self, name: str, volume: float = 1.0) -> None:
        """Play one of the cached sounds by name. Silent if not present."""
        if not self._enabled:
            return
        sound = self.sounds.get(name)
        if sound is None:
            return
        try:
            channel = pygame.mixer.find_channel(force=False)
            if channel is None:
                # All channels busy — fall back to the Sound's own .play()
                sound.set_volume(self.master_volume * volume)
                sound.play()
            else:
                channel.set_volume(self.master_volume * volume)
                channel.play(sound)
        except pygame.error:
            pass

    def set_master_volume(self, v: float) -> None:
        self.master_volume = max(0.0, min(1.0, v))

    # --------------------------------------------------------------------- #
    # Library build
    # --------------------------------------------------------------------- #
    def _build(self) -> None:
        defs: Dict[str, Callable[[], pygame.mixer.Sound]] = {
            # --- Card tactility ---
            "card_select":  lambda: self._tone(880, 0.045, 0.20),
            "card_hover":   lambda: self._tone(1320, 0.02, 0.10),
            "card_play":    lambda: self._sweep(660, 980, 0.10, 0.28),
            "card_slap":    lambda: self._thud(90, 0.18, 0.45),
            "deal":         lambda: self._noise_burst(0.05, 0.20, low_pass=True),
            "discard":      lambda: self._whoosh(0.20, 0.28),

            # --- UI feedback ---
            "score_pop":    lambda: self._tone_seq([(700, 0.04), (900, 0.04), (1200, 0.06)], 0.22),
            "click":        lambda: self._tone(520, 0.03, 0.18),
            "buy":          lambda: self._tone_seq([(880, 0.05), (1320, 0.08)], 0.28),
            "reroll":       lambda: self._tone_seq([(660, 0.04), (660, 0.06)], 0.18),
            "win_round":    lambda: self._tone_seq([(523, 0.10), (659, 0.10), (784, 0.20)], 0.30),
            "lose_round":   lambda: self._tone_seq([(330, 0.10), (262, 0.10), (196, 0.30)], 0.34),
            "boss":         lambda: self._tone_seq([(110, 0.14), (98, 0.22)], 0.38),

            # --- Per-joker signature sounds ---
            #     The audio identity of each bird:
            # Raven  : dark feather swoosh (filtered noise burst)
            "joker_raven":   lambda: self._whoosh(0.22, 0.35, dark=True),
            # Owl    : ghostly chime (pure tone + harmonics, long decay)
            "joker_owl":     lambda: self._chime(880, 0.55, 0.30),
            # Eagle  : sharp metallic upward rise
            "joker_eagle":   lambda: self._sweep(220, 1320, 0.28, 0.36),
            # Vulture: deep decay bass — heavy, ominous
            "joker_vulture": lambda: self._thud(55, 0.35, 0.55),
            # Crow   : discordant double tick
            "joker_crow":    lambda: self._tick_pair(0.30),
            # Peacock: shimmering harmonic sweep
            "joker_peacock": lambda: self._sweep(440, 1760, 0.20, 0.28),
            # Parrot : short echo of three quick notes (literal "echo")
            "joker_parrot":  lambda: self._tone_seq(
                [(660, 0.04), (660, 0.04), (660, 0.04)], 0.22, gap=0.05
            ),
            # Falcon : descending hunt-cry
            "joker_falcon":  lambda: self._sweep(880, 220, 0.20, 0.30),
            # Swan   : single soft chime
            "joker_swan":    lambda: self._chime(660, 0.45, 0.22),

            # --- Special atmospheric stings (SFX-side, paired with music ones) ---
            "card_legendary": lambda: self._dark_bass_hit(0.45, 0.55),
            "huge_multiplier": lambda: self._ringing(880, 1.2, 0.25),
        }

        for name, gen in defs.items():
            sound = self._try_load(name)
            if sound is None:
                try:
                    sound = gen()
                except Exception:
                    continue
            self.sounds[name] = sound

    def _try_load(self, name: str) -> Optional[pygame.mixer.Sound]:
        for ext in (".wav", ".ogg"):
            path = os.path.join(SFX_DIR, name + ext)
            if os.path.exists(path):
                try:
                    return pygame.mixer.Sound(path)
                except pygame.error:
                    pass
        return None

    # --------------------------------------------------------------------- #
    # Procedural generators
    # --------------------------------------------------------------------- #
    def _tone(self, freq: float, duration: float, volume: float) -> pygame.mixer.Sound:
        sr = self.sample_rate
        n = int(duration * sr)
        buf = array.array("h")
        for i in range(n):
            t = i / sr
            env_a = min(1.0, t * 80)
            env_r = min(1.0, (duration - t) * 80)
            env = max(0.0, min(env_a, env_r))
            v = volume * env * math.sin(2 * math.pi * freq * t)
            s = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(s)
            buf.append(s)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _tone_seq(self, notes, volume: float, gap: float = 0.0) -> pygame.mixer.Sound:
        sr = self.sample_rate
        buf = array.array("h")
        for freq, duration in notes:
            n = int(duration * sr)
            for i in range(n):
                t = i / sr
                env_a = min(1.0, t * 80)
                env_r = min(1.0, (duration - t) * 80)
                env = max(0.0, min(env_a, env_r))
                v = volume * env * math.sin(2 * math.pi * freq * t)
                s = int(max(-1.0, min(1.0, v)) * 32767)
                buf.append(s)
                buf.append(s)
            if gap > 0:
                gap_n = int(gap * sr)
                for _ in range(gap_n):
                    buf.append(0)
                    buf.append(0)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _sweep(self, start_freq, end_freq, duration, volume) -> pygame.mixer.Sound:
        """Sine sweep with proper phase integration so the pitch slide is clean."""
        sr = self.sample_rate
        n = int(duration * sr)
        buf = array.array("h")
        phase = 0.0
        for i in range(n):
            t = i / sr
            t_norm = t / duration
            freq = start_freq * (1 - t_norm) + end_freq * t_norm
            phase += 2 * math.pi * freq / sr
            env_a = min(1.0, t * 30)
            env_r = min(1.0, (duration - t) * 10)
            env = max(0.0, min(env_a, env_r))
            v = volume * env * math.sin(phase)
            s = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(s)
            buf.append(s)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _thud(self, freq: float, duration: float, volume: float) -> pygame.mixer.Sound:
        sr = self.sample_rate
        n = int(duration * sr)
        buf = array.array("h")
        for i in range(n):
            t = i / sr
            env = math.exp(-t * 18)
            # Click + body
            click = math.exp(-t * 200) * 0.5
            body = math.sin(2 * math.pi * freq * t) * env
            v = volume * (body + click * math.sin(2 * math.pi * freq * 4 * t))
            s = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(s)
            buf.append(s)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _whoosh(self, duration: float, volume: float,
                dark: bool = False, low_pass: bool = True) -> pygame.mixer.Sound:
        sr = self.sample_rate
        n = int(duration * sr)
        buf = array.array("h")
        rng = random.Random()
        prev_l = prev_r = 0.0
        # Darker whooshes use heavier low-pass smoothing
        smooth = 0.92 if dark else 0.85
        for i in range(n):
            t = i / sr
            t_norm = t / duration
            env = math.sin(t_norm * math.pi)   # bell envelope
            raw_l = (rng.random() - 0.5) * 2.0
            raw_r = (rng.random() - 0.5) * 2.0
            if low_pass:
                prev_l = prev_l * smooth + raw_l * (1 - smooth)
                prev_r = prev_r * smooth + raw_r * (1 - smooth)
                v_l = prev_l
                v_r = prev_r
            else:
                v_l = raw_l
                v_r = raw_r
            v_l *= volume * env
            v_r *= volume * env
            buf.append(int(max(-1.0, min(1.0, v_l)) * 32767))
            buf.append(int(max(-1.0, min(1.0, v_r)) * 32767))
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _noise_burst(self, duration: float, volume: float,
                     low_pass: bool = False) -> pygame.mixer.Sound:
        sr = self.sample_rate
        n = int(duration * sr)
        buf = array.array("h")
        rng = random.Random()
        prev = 0.0
        for i in range(n):
            t = i / sr
            env = max(0, 1 - t / duration) ** 2
            raw = (rng.random() - 0.5) * 2.0
            if low_pass:
                prev = prev * 0.7 + raw * 0.3
                v = prev * volume * env
            else:
                v = raw * volume * env
            s = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(s)
            buf.append(s)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _chime(self, freq: float, duration: float, volume: float) -> pygame.mixer.Sound:
        sr = self.sample_rate
        n = int(duration * sr)
        buf = array.array("h")
        for i in range(n):
            t = i / sr
            env = math.exp(-t * 2.4)
            tau = 2 * math.pi * t
            v = volume * env * (
                math.sin(tau * freq) * 0.55
                + math.sin(tau * freq * 2.01) * 0.28
                + math.sin(tau * freq * 3.02) * 0.15
            )
            s = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(s)
            buf.append(s)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _tick_pair(self, volume: float) -> pygame.mixer.Sound:
        sr = self.sample_rate
        buf = array.array("h")
        # Two short ticks with a gap, slightly detuned
        for j, freq in enumerate((1200, 1140)):
            tick_dur = 0.03
            n = int(tick_dur * sr)
            for i in range(n):
                t = i / sr
                env = math.exp(-t * 80)
                v = volume * env * math.sin(2 * math.pi * freq * t)
                s = int(max(-1.0, min(1.0, v)) * 32767)
                buf.append(s)
                buf.append(s)
            gap_n = int(0.08 * sr)
            for _ in range(gap_n):
                buf.append(0)
                buf.append(0)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _dark_bass_hit(self, duration: float, volume: float) -> pygame.mixer.Sound:
        """Heavy single low note for rare/legendary moments."""
        sr = self.sample_rate
        n = int(duration * sr)
        buf = array.array("h")
        for i in range(n):
            t = i / sr
            env_a = min(1.0, t * 60)
            env_d = math.exp(-t * 4)
            env = env_a * env_d
            tau = 2 * math.pi * t
            v = volume * env * (
                math.sin(tau * 41.0) * 0.6
                + math.sin(tau * 55.0) * 0.3
                + math.sin(tau * 82.0) * 0.15
            )
            s = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(s)
            buf.append(s)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def _ringing(self, freq: float, duration: float, volume: float) -> pygame.mixer.Sound:
        """Lingering ringing tone — used after huge multipliers."""
        sr = self.sample_rate
        n = int(duration * sr)
        buf = array.array("h")
        for i in range(n):
            t = i / sr
            env = math.exp(-t * 1.5)
            tau = 2 * math.pi * t
            v = volume * env * (
                math.sin(tau * freq) * 0.5
                + math.sin(tau * freq * 1.5) * 0.25
            )
            s = int(max(-1.0, min(1.0, v)) * 32767)
            buf.append(s)
            buf.append(s)
        return pygame.mixer.Sound(buffer=buf.tobytes())
