"""
Reusable UI widgets: buttons, panels, text rows, joker slots, score readout.

All widgets have smoothed visual state (hover progress, press progress, pulse
intensity) so they feel alive rather than stamping in/out between two states.
"""

import math
from dataclasses import dataclass, field
from typing import Callable, Optional, Tuple, List

import pygame

from ui import colors as C
from ui.assets import render_text, get_font
from ui.tweening import damp, ease_out_back


# --------------------------------------------------------------------------- #
# Button — bouncy version
# --------------------------------------------------------------------------- #
class Button:
    """
    Rectangular text button with hover/press state.

    Visual feel:
      - hover_t   smoothly damps 0 → 1 while hovered
      - press_t   smoothly damps 0 → 1 while pressed
      - On click, briefly bounces with ease_out_back (~0.18s)
    """

    def __init__(self, rect: pygame.Rect, label: str,
                 on_click: Optional[Callable[[], None]] = None,
                 font_size: int = 26,
                 color_bg=C.BTN_BG, color_bg_hover=C.BTN_BG_HOVER,
                 color_text=C.BTN_TEXT, color_border=C.BTN_BORDER,
                 disabled: bool = False, hotkey: Optional[int] = None,
                 tooltip: Optional[str] = None):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.on_click = on_click
        self.font_size = font_size
        self.color_bg = color_bg
        self.color_bg_hover = color_bg_hover
        self.color_text = color_text
        self.color_border = color_border
        self.disabled = disabled
        self.hotkey = hotkey
        self.tooltip = tooltip
        self.hovered = False
        self.pressed = False
        # Smoothed visual state
        self.hover_t = 0.0
        self.press_t = 0.0
        self.click_pop = 1.0   # 1.0 = idle; <1 = pop animation in flight
        self._click_dir = 1.0

    # ----- Events ----- #
    def handle_event(self, event) -> bool:
        if self.disabled:
            return False
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.pressed = True
                return True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            was_pressed = self.pressed
            self.pressed = False
            if was_pressed and self.rect.collidepoint(event.pos):
                self._fire()
                return True
        elif event.type == pygame.KEYDOWN and self.hotkey is not None:
            if event.key == self.hotkey:
                self._fire()
                return True
        return False

    def _fire(self) -> None:
        self.click_pop = 0.0
        if self.on_click:
            self.on_click()

    # ----- Draw ----- #
    def draw(self, surface) -> None:
        """
        Premium button render:
          * Vertical gradient fill (dark top → slightly lighter bottom)
          * 2px gold inset border with a 1px brighter inner highlight
          * Soft additive glow when hovered (suit/color-themed)
          * Inset shadow under text for readability
          * Click pop on press release
        """
        dt = 1.0 / 60.0
        # Slightly snappier hover-in (15 vs 12) for that "immediate" feel.
        self.hover_t = damp(self.hover_t, 1.0 if (self.hovered and not self.disabled) else 0.0, 15.0, dt)
        self.press_t = damp(self.press_t, 1.0 if self.pressed else 0.0, 26.0, dt)
        if self.click_pop < 1.0:
            # Slightly longer pop window so the bounce reads as "soft settle"
            # rather than a tick. 0.26s vs the old 0.22s.
            self.click_pop = min(1.0, self.click_pop + dt / 0.26)

        # Hover lift is intentionally small (4%) — Balatro UI feels stable, not bouncy.
        # Press scale dip is a notch larger (-6%) so the press-down is felt.
        scale = 1.0 + 0.04 * self.hover_t - 0.06 * self.press_t
        if self.click_pop < 1.0:
            # Smooth sine envelope (0 → 1 → 0) gives a satisfying "pop" with
            # gentle settle, vs the triangular curve we used to have.
            scale += 0.16 * math.sin(self.click_pop * math.pi)
        new_w = int(self.rect.width * scale)
        new_h = int(self.rect.height * scale)
        draw_rect = pygame.Rect(0, 0, new_w, new_h)
        draw_rect.center = self.rect.center

        if self.disabled:
            top_col = (32, 24, 32)
            bot_col = (18, 14, 20)
            border = C.BORDER
            text_col = C.TEXT_FAINT
        else:
            # Blend hover/press into the gradient endpoints.
            base_top = _blend(self.color_bg, self.color_bg_hover, self.hover_t)
            base_top = _blend(base_top, C.BTN_BG_DOWN, self.press_t)
            top_col = base_top
            bot_col = _shift(base_top, -8)
            border = self.color_border
            text_col = self.color_text

        # Soft additive outer glow on hover — uses the button's border color
        if self.hover_t > 0.05 and not self.disabled:
            glow_pad = 14
            glow = pygame.Surface((draw_rect.width + glow_pad * 2,
                                   draw_rect.height + glow_pad * 2), pygame.SRCALPHA)
            for i in range(3, 0, -1):
                a = int(40 * self.hover_t / i)
                pygame.draw.rect(glow, (*self.color_border, a),
                                 glow.get_rect().inflate(-i * 4, -i * 4),
                                 border_radius=10 + i)
            surface.blit(glow, (draw_rect.x - glow_pad, draw_rect.y - glow_pad),
                         special_flags=pygame.BLEND_RGBA_ADD)

        # Build the gradient body
        body = pygame.Surface((draw_rect.width, draw_rect.height), pygame.SRCALPHA)
        for y in range(draw_rect.height):
            t = y / max(1, draw_rect.height - 1)
            col = (
                int(top_col[0] * (1 - t) + bot_col[0] * t),
                int(top_col[1] * (1 - t) + bot_col[1] * t),
                int(top_col[2] * (1 - t) + bot_col[2] * t),
            )
            pygame.draw.line(body, col, (0, y), (draw_rect.width, y))
        # Round-corner mask
        mask = pygame.Surface(body.get_size(), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=8)
        body.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        surface.blit(body, draw_rect.topleft)

        # Border + inner highlight for that "expensive" feel
        pygame.draw.rect(surface, border, draw_rect, 2, border_radius=8)
        inner = draw_rect.inflate(-4, -4)
        pygame.draw.rect(surface, _shift(border, 30), inner, 1, border_radius=6)

        # Label with subtle drop shadow
        label_shadow = render_text(self.label, self.font_size, (0, 0, 0), bold=True)
        label_surf = render_text(self.label, self.font_size, text_col, bold=True)
        center = draw_rect.center
        surface.blit(label_shadow, label_shadow.get_rect(center=(center[0] + 1, center[1] + 2)))
        surface.blit(label_surf, label_surf.get_rect(center=center))


def _shift(color, delta):
    return tuple(max(0, min(255, c + delta)) for c in color[:3])


def _blend(c1, c2, t: float):
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t),
    )


# --------------------------------------------------------------------------- #
# Panel
# --------------------------------------------------------------------------- #
def draw_panel(surface, rect, title: Optional[str] = None,
               bg=C.BG_PANEL, border=C.GOLD_DIM, title_color=C.GOLD):
    pygame.draw.rect(surface, bg, rect, border_radius=8)
    pygame.draw.rect(surface, border, rect, 2, border_radius=8)
    if title:
        t = render_text(title, 18, title_color, bold=True)
        surface.blit(t, (rect.x + 10, rect.y + 6))


# --------------------------------------------------------------------------- #
# Stat row
# --------------------------------------------------------------------------- #
def draw_stat(surface, pos, label: str, value: str,
              label_color=C.TEXT_DIM, value_color=C.GOLD, size: int = 20):
    lbl = render_text(label, size, label_color)
    val = render_text(value, size, value_color, bold=True)
    surface.blit(lbl, pos)
    surface.blit(val, (pos[0] + lbl.get_width() + 8, pos[1]))


# --------------------------------------------------------------------------- #
# Joker slot row
# --------------------------------------------------------------------------- #
def draw_joker_slots(surface, jokers, assets, top_left, slot_size,
                     max_slots: int = 5, pulses: Optional[list] = None,
                     gap: int = 8):
    """
    Render the row of joker slots. Optionally accepts a per-joker pulse value
    in [0,1] for highlight scaling when that joker fires.
    """
    from game.constants import JOKER_WIDTH, JOKER_HEIGHT
    x, y = top_left
    for i in range(max_slots):
        slot_rect = pygame.Rect(x + i * (JOKER_WIDTH + gap), y, JOKER_WIDTH, JOKER_HEIGHT)
        pygame.draw.rect(surface, C.BG_PANEL, slot_rect, border_radius=8)
        pygame.draw.rect(surface, C.BORDER, slot_rect, 1, border_radius=8)
        if i < len(jokers):
            img = assets.get_joker(jokers[i].joker_id)
            scale = 1.0
            if pulses is not None and i < len(pulses):
                scale = pulses[i]
            if scale != 1.0:
                w, h = img.get_size()
                img = pygame.transform.smoothscale(
                    img, (max(1, int(w * scale)), max(1, int(h * scale)))
                )
            rect = img.get_rect(center=slot_rect.center)
            surface.blit(img, rect)
            status = jokers[i].status_text()
            if status:
                stxt = render_text(status, 14, C.GOLD, bold=True)
                # Faint background pill for legibility
                pad = 3
                pill = pygame.Rect(slot_rect.x + 2, slot_rect.y + 2,
                                   stxt.get_width() + pad * 2, stxt.get_height() + pad)
                pygame.draw.rect(surface, (0, 0, 0, 150), pill, border_radius=4)
                surface.blit(stxt, (pill.x + pad, pill.y + pad // 2))


def joker_slot_position(slot_index: int, top_left=(20, 110), gap: int = 8) -> Tuple[int, int]:
    """Return the centre of a given joker slot — used by particle effects."""
    from game.constants import JOKER_WIDTH, JOKER_HEIGHT
    x = top_left[0] + slot_index * (JOKER_WIDTH + gap) + JOKER_WIDTH // 2
    y = top_left[1] + JOKER_HEIGHT // 2
    return (x, y)


# --------------------------------------------------------------------------- #
# Tooltip
# --------------------------------------------------------------------------- #
def draw_tooltip(surface, pos: Tuple[int, int], lines: List[str],
                 max_width: int = 280, alpha: float = 1.0):
    """
    Tooltip box near `pos`. Pass `alpha` in [0, 1] for smooth fade in/out;
    callers track their own fade tween so the tooltip never flickers.
    """
    if alpha <= 0.01 or not lines:
        return
    pad = 8
    line_surfs = [render_text(line, 18, C.TEXT) for line in lines]
    width = max(s.get_width() for s in line_surfs) + pad * 2
    height = sum(s.get_height() for s in line_surfs) + pad * 2

    sw, sh = surface.get_size()
    x, y = pos
    x = min(x, sw - width - 4)
    y = min(y, sh - height - 4)
    x = max(4, x)
    y = max(4, y)

    # Build the whole tooltip onto a temp surface so a single set_alpha
    # controls everything (background + border + text) uniformly.
    tip = pygame.Surface((width, height), pygame.SRCALPHA)
    pygame.draw.rect(tip, (0, 0, 0, 220), tip.get_rect(), border_radius=6)
    pygame.draw.rect(tip, C.GOLD_DIM, tip.get_rect(), 1, border_radius=6)
    cy = pad
    for s in line_surfs:
        tip.blit(s, (pad, cy))
        cy += s.get_height()
    if alpha < 1.0:
        tip.set_alpha(int(255 * alpha))
    surface.blit(tip, (x, y))


# --------------------------------------------------------------------------- #
# Score readout — supports pulses for chips/mult
# --------------------------------------------------------------------------- #
def draw_score_readout(surface, rect, chips: float, mult: float, total: int,
                       chips_pulse: float = 1.0, mult_pulse: float = 1.0,
                       total_pulse: float = 1.0):
    """
    Big centerpiece chips × mult display. Each numeric chunk can independently
    pulse-scale (>1.0) to celebrate increases.

    Balatro-style: numbers are large and high-contrast, sitting on flat panels
    with strong color separation (blue chips, red mult, gold total).
    """
    # Inset darker plate for contrast behind the numbers.
    pygame.draw.rect(surface, (10, 6, 10), rect, border_radius=12)
    pygame.draw.rect(surface, C.GOLD_DIM, rect, 2, border_radius=12)

    # Sub-plates for chips and mult so the colors don't bleed
    plate_w = (rect.width - 64) // 2
    plate_h = rect.height - 50
    chip_plate = pygame.Rect(rect.x + 12, rect.y + 12, plate_w, plate_h)
    mult_plate = pygame.Rect(rect.right - 12 - plate_w, rect.y + 12, plate_w, plate_h)
    pygame.draw.rect(surface, (12, 22, 40), chip_plate, border_radius=8)
    pygame.draw.rect(surface, (60, 110, 200), chip_plate, 1, border_radius=8)
    pygame.draw.rect(surface, (40, 10, 14), mult_plate, border_radius=8)
    pygame.draw.rect(surface, (170, 50, 70), mult_plate, 1, border_radius=8)

    # Bumped 56 → 68 base, with pulse scaling on top.
    base_size = 68
    chips_size = max(20, int(base_size * chips_pulse))
    mult_size = max(20, int(base_size * mult_pulse))

    chips_surf = render_text(f"{int(chips)}", chips_size, C.BLUE_INFO, bold=True)
    surface.blit(chips_surf, chips_surf.get_rect(center=chip_plate.center))

    x_surf = render_text("X", 42, C.GOLD, bold=True)
    surface.blit(x_surf, x_surf.get_rect(center=(rect.centerx, chip_plate.centery)))

    mult_surf = render_text(f"{mult:.1f}", mult_size, C.BLOOD_BRIGHT, bold=True)
    surface.blit(mult_surf, mult_surf.get_rect(center=mult_plate.center))

    # Total under the plates
    tot_size = max(18, int(34 * total_pulse))
    tot_color = C.GOLD_BRIGHT if total_pulse > 1.01 else C.GOLD
    tot_surf = render_text(f"= {total}", tot_size, tot_color, bold=True)
    surface.blit(tot_surf, tot_surf.get_rect(midtop=(rect.centerx, rect.bottom - 40)))
