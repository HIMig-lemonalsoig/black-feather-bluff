"""
Post-process "shader" pipeline.

Pygame doesn't expose GLSL fragment shaders directly, so we fake the moral
equivalent: a configurable chain of Surface→Surface effects applied in order.

The pipeline is wired into the Screen base class as `self.postfx`. Each
screen can enable/disable or replace effects (e.g., the title screen wants
heavier vignette; the play screen wants the spotlight under the table).

A typical chain:

    [SpotLight] -> [GoldRim] -> [ScanlineOverlay] -> [VignetteOverlay]
                                                  -> [NoiseGrain]
                                                  -> [HitFlash]
"""

from typing import List, Optional

import pygame

from ui.ui_effects import (
    VignetteOverlay, ScanlineOverlay, SpotLight, GoldRim,
    NoiseGrain, HitFlash, AtmosphereLayer,
)


class PostFXPipeline:
    """
    A composable ordered list of effects.

    Each effect should expose a `draw(surface)` method; some also expose
    `update(dt)`. The pipeline calls them in the order they were added.
    """

    def __init__(self):
        self.effects: List[object] = []

    def add(self, effect: object) -> object:
        self.effects.append(effect)
        return effect

    def remove(self, effect: object) -> None:
        if effect in self.effects:
            self.effects.remove(effect)

    def update(self, dt: float) -> None:
        for fx in self.effects:
            if hasattr(fx, "update"):
                fx.update(dt)

    def draw(self, surface) -> None:
        for fx in self.effects:
            fx.draw(surface)


def build_default_pipeline(width: int, height: int,
                           scanlines_enabled: bool = True,
                           with_spotlight: bool = False) -> PostFXPipeline:
    """Construct the standard chain used by most screens."""
    pipe = PostFXPipeline()
    if with_spotlight:
        # Subtle warm pool — ~12% center opacity, fades to invisible at the
        # edge of a 380px radius. Implementation uses RGB+colorkey (no
        # smoothscale, no per-pixel alpha) for cross-pygame reliability.
        pipe.add(SpotLight(width, height,
                           cx=width // 2, cy=height // 2 + 30,
                           radius=380, color=(255, 200, 110),
                           intensity=32))
    pipe.add(GoldRim(width, height))
    if scanlines_enabled:
        pipe.add(ScanlineOverlay(width, height, alpha=18, gap=3, enabled=True))
    pipe.add(VignetteOverlay(width, height, intensity=0.85))
    pipe.add(NoiseGrain(width, height, density=0.008))
    return pipe
