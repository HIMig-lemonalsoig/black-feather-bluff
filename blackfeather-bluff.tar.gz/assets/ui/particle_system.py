"""
Lightweight particle system.

Particles are simple dataclass-ish objects with their own update/draw. The
ParticleSystem owns a flat list, updates it once per frame, and exposes a
handful of pre-baked emitters (feathers, sparks, fan, smoke, gold streak).

We keep it cheap:
  - alpha is computed once per particle per frame
  - shapes are drawn with pygame.draw primitives onto small temp surfaces
  - dead particles are filtered out each frame

To keep performance predictable, emitters cap their counts conservatively.
"""

import math
import random
from typing import List, Tuple

import pygame

from ui import colors as C


# --------------------------------------------------------------------------- #
# Particle
# --------------------------------------------------------------------------- #
class Particle:
    """One drifting bit of feedback."""

    __slots__ = (
        "x", "y", "vx", "vy", "life", "max_life", "color", "size",
        "gravity", "drag", "rot", "spin", "fade", "kind", "extra",
    )

    def __init__(self, x, y, vx, vy, life, color, size=3,
                 gravity=0.0, drag=0.0, rot=0.0, spin=0.0,
                 fade=True, kind="circle", extra=None):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.life = life
        self.max_life = max(life, 0.0001)
        self.color = color           # (r, g, b)
        self.size = size
        self.gravity = gravity
        self.drag = drag
        self.rot = rot
        self.spin = spin
        self.fade = fade
        self.kind = kind             # 'circle' | 'feather' | 'spark' | 'smoke' | 'ring'
        self.extra = extra or {}

    @property
    def alive(self) -> bool:
        return self.life > 0.0

    def update(self, dt: float) -> None:
        self.life -= dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += self.gravity * dt
        if self.drag:
            f = max(0.0, 1.0 - self.drag * dt)
            self.vx *= f
            self.vy *= f
        if self.spin:
            self.rot += self.spin * dt

    # ----- Draw dispatch ----- #
    def draw(self, surface) -> None:
        a = 1.0
        if self.fade:
            a = max(0.0, min(1.0, self.life / self.max_life))
        if a <= 0.0:
            return

        if self.kind == "circle":
            self._draw_circle(surface, a)
        elif self.kind == "feather":
            self._draw_feather(surface, a)
        elif self.kind == "spark":
            self._draw_spark(surface, a)
        elif self.kind == "smoke":
            self._draw_smoke(surface, a)
        elif self.kind == "ring":
            self._draw_ring(surface, a)

    def _draw_circle(self, surface, a):
        s = max(1, int(self.size * (0.4 + 0.6 * a)))
        surf = pygame.Surface((s * 2 + 2, s * 2 + 2), pygame.SRCALPHA)
        col = (*self.color, int(255 * a))
        pygame.draw.circle(surf, col, (s + 1, s + 1), s)
        surface.blit(surf, (int(self.x - s), int(self.y - s)))

    def _draw_feather(self, surface, a):
        s = int(self.size)
        # Build feather shape (tear-drop) then rotate.
        w = s * 2
        h = s * 4
        surf = pygame.Surface((w * 2, h * 2), pygame.SRCALPHA)
        cx, cy = w, h
        pts_local = [(0, -h), (s, 0), (0, h * 0.8), (-s, 0)]
        cos_r = math.cos(self.rot)
        sin_r = math.sin(self.rot)
        rotated = [
            (px * cos_r - py * sin_r + cx, px * sin_r + py * cos_r + cy)
            for px, py in pts_local
        ]
        col = (*self.color, int(220 * a))
        pygame.draw.polygon(surf, col, rotated)
        # A central rachis line in a darker tone
        spine_col = (max(0, self.color[0] - 30), max(0, self.color[1] - 30), max(0, self.color[2] - 30), int(220 * a))
        spine_start = (cx + math.sin(self.rot) * h * 0.8, cy - math.cos(self.rot) * h * 0.8)
        spine_end = (cx - math.sin(self.rot) * h * 0.6, cy + math.cos(self.rot) * h * 0.6)
        pygame.draw.line(surf, spine_col, spine_start, spine_end, 1)
        surface.blit(surf, (int(self.x - w), int(self.y - h)))

    def _draw_spark(self, surface, a):
        s = max(2, int(self.size))
        w = s * 4
        surf = pygame.Surface((w, w), pygame.SRCALPHA)
        col = (*self.color, int(255 * a))
        cx = cy = w // 2
        pygame.draw.line(surf, col, (cx - s * 2, cy), (cx + s * 2, cy), 2)
        pygame.draw.line(surf, col, (cx, cy - s * 2), (cx, cy + s * 2), 2)
        pygame.draw.circle(surf, col, (cx, cy), max(1, s))
        surface.blit(surf, (int(self.x - w // 2), int(self.y - w // 2)))

    def _draw_smoke(self, surface, a):
        # Smoke expands as it ages.
        grow = 1.0 + (1.0 - a) * 1.5
        s = int(self.size * grow)
        if s <= 0:
            return
        surf = pygame.Surface((s * 2, s * 2), pygame.SRCALPHA)
        col = (*self.color, int(130 * a))
        pygame.draw.circle(surf, col, (s, s), s)
        surface.blit(surf, (int(self.x - s), int(self.y - s)))

    def _draw_ring(self, surface, a):
        # An expanding ring used for joker triggers.
        grow = self.extra.get("grow_rate", 80.0)
        r = int(self.size + (1.0 - a) * grow)
        if r <= 1:
            return
        thickness = max(1, int(3 * a))
        surf_size = (r + thickness + 2) * 2
        surf = pygame.Surface((surf_size, surf_size), pygame.SRCALPHA)
        col = (*self.color, int(220 * a))
        pygame.draw.circle(surf, col, (surf_size // 2, surf_size // 2), r, thickness)
        surface.blit(surf, (int(self.x - surf_size // 2), int(self.y - surf_size // 2)))


# --------------------------------------------------------------------------- #
# System
# --------------------------------------------------------------------------- #
class ParticleSystem:
    """Owns a flat list of Particles + emitter helpers."""

    MAX_PARTICLES = 600   # safety cap

    def __init__(self):
        self.particles: List[Particle] = []

    def add(self, p: Particle) -> None:
        if len(self.particles) < self.MAX_PARTICLES:
            self.particles.append(p)

    def clear(self) -> None:
        self.particles.clear()

    def update(self, dt: float) -> None:
        for p in self.particles:
            p.update(dt)
        # Replacing the list is cheaper than .remove() for large counts.
        self.particles = [p for p in self.particles if p.alive]

    def draw(self, surface) -> None:
        for p in self.particles:
            p.draw(surface)

    # --------------------------------------------------------------------- #
    # Emitter helpers
    # --------------------------------------------------------------------- #
    def burst_feathers(self, x, y, color, count: int = 10,
                       speed: float = 130.0, lifetime: float = 1.1) -> None:
        """Generic feather burst — falling slowly with rotation."""
        for _ in range(count):
            ang = random.uniform(0, math.tau)
            sp = random.uniform(speed * 0.45, speed)
            life = random.uniform(lifetime * 0.7, lifetime)
            self.add(Particle(
                x, y, math.cos(ang) * sp, math.sin(ang) * sp - 50,
                life, color, size=random.uniform(3.5, 5.5),
                gravity=35, drag=0.7,
                rot=random.uniform(0, math.tau),
                spin=random.uniform(-5.0, 5.0),
                kind="feather",
            ))

    def burst_sparks(self, x, y, color, count: int = 14,
                     speed: float = 220.0, gravity: float = 200.0,
                     lifetime: float = 0.7) -> None:
        for _ in range(count):
            ang = random.uniform(-math.pi, 0)  # upward bias
            sp = random.uniform(speed * 0.3, speed)
            self.add(Particle(
                x, y, math.cos(ang) * sp, math.sin(ang) * sp,
                random.uniform(lifetime * 0.5, lifetime), color,
                size=random.uniform(2.5, 4.0),
                gravity=gravity, drag=1.0, kind="spark",
            ))

    def burst_fan(self, x, y, color1, color2, count: int = 14,
                  speed: float = 170.0, lifetime: float = 0.9) -> None:
        """Half-circle fan in two alternating colors — peacock-style."""
        for i in range(count):
            t = i / max(1, count - 1)
            ang = math.pi + math.pi * t - math.pi * 0.25  # upward fan
            sp = speed * random.uniform(0.85, 1.15)
            col = color1 if i % 2 == 0 else color2
            self.add(Particle(
                x, y, math.cos(ang) * sp, math.sin(ang) * sp,
                random.uniform(lifetime * 0.6, lifetime), col,
                size=random.uniform(3.5, 5.5),
                gravity=70, drag=0.4, kind="circle",
            ))

    def burst_smoke(self, x, y, color, count: int = 6,
                    speed: float = 35.0, lifetime: float = 1.2) -> None:
        for _ in range(count):
            ang = random.uniform(-math.pi * 0.75, -math.pi * 0.25)
            sp = random.uniform(speed * 0.4, speed)
            self.add(Particle(
                x, y, math.cos(ang) * sp, math.sin(ang) * sp,
                random.uniform(lifetime * 0.7, lifetime), color,
                size=random.uniform(5.0, 8.0),
                gravity=-10, drag=0.5, kind="smoke",
            ))

    def gold_streak(self, x, y) -> None:
        """Eagle: upward gold streak with sparks."""
        for _ in range(10):
            self.add(Particle(
                x + random.uniform(-8, 8), y,
                random.uniform(-20, 20), random.uniform(-280, -200),
                random.uniform(0.5, 1.1), C.GOLD_BRIGHT,
                size=random.uniform(2.0, 3.5),
                gravity=120, drag=0.6, kind="spark",
            ))
        for _ in range(4):
            self.add(Particle(
                x, y, random.uniform(-15, 15), random.uniform(-120, -80),
                0.6, C.GOLD, size=8, kind="ring",
                extra={"grow_rate": 70},
            ))

    def shockwave(self, x, y, color, lifetime: float = 0.45) -> None:
        """Expanding ring — generic 'something happened here' cue."""
        self.add(Particle(
            x, y, 0, 0, lifetime, color,
            size=18, kind="ring",
            extra={"grow_rate": 140.0},
        ))

    def eye_glow(self, x, y) -> None:
        """Owl: brief warm-gold pulse + ring."""
        self.add(Particle(x, y, 0, 0, 0.35, C.GOLD_BRIGHT,
                          size=18, kind="ring",
                          extra={"grow_rate": 60.0}))
        for _ in range(4):
            self.add(Particle(
                x + random.uniform(-12, 12), y + random.uniform(-12, 12),
                random.uniform(-30, 30), random.uniform(-50, -10),
                random.uniform(0.4, 0.8), C.GOLD_BRIGHT,
                size=3, kind="spark", drag=2.0,
            ))

    def echo_clone(self, x, y, color) -> None:
        """Parrot: two pulsing rings — an echo motif."""
        for delay_idx in range(2):
            scale = 14 + delay_idx * 6
            self.add(Particle(
                x, y, 0, 0, 0.55 + 0.15 * delay_idx, color,
                size=scale, kind="ring",
                extra={"grow_rate": 110.0 + delay_idx * 40},
            ))

    def loss_smoke(self, x, y) -> None:
        """Dark mist for losses / debuffs."""
        for _ in range(14):
            self.add(Particle(
                x + random.uniform(-30, 30), y + random.uniform(-10, 10),
                random.uniform(-30, 30), random.uniform(-60, -20),
                random.uniform(1.0, 1.8), (40, 14, 22),
                size=random.uniform(8, 12), drag=0.3, kind="smoke",
            ))
